package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.View;

import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link CollapsingToolbarLayout}. */
public class CollapsingToolbarCaller {

    public static void setTitle(View target, String value, Context context) {
        if (target instanceof CollapsingToolbarLayout) {
            ((CollapsingToolbarLayout) target).setTitle(value);
        }
    }

    public static void setTitleEnabled(View target, String value, Context context) {
        if (target instanceof CollapsingToolbarLayout) {
            ((CollapsingToolbarLayout) target).setTitleEnabled(value.equals("true"));
        }
    }

    public static void setExpandedTitleColor(View target, String value, Context context) {
        if (target instanceof CollapsingToolbarLayout) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((CollapsingToolbarLayout) target).setExpandedTitleColor(color);
        }
    }

    public static void setCollapsedTitleTextColor(View target, String value, Context context) {
        if (target instanceof CollapsingToolbarLayout) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((CollapsingToolbarLayout) target).setCollapsedTitleTextColor(color);
        }
    }

    public static void setContentScrimColor(View target, String value, Context context) {
        if (target instanceof CollapsingToolbarLayout) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((CollapsingToolbarLayout) target).setContentScrim(new ColorDrawable(color));
        }
    }
}
