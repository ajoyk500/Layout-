package com.itsvks.layouteditor.editor.callers.parentcallers;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.itsvks.layouteditor.utils.Constants;
import com.itsvks.layouteditor.utils.DimensionUtil;

/** Handles DrawerLayout.LayoutParams (child-of-DrawerLayout) attributes. */
public class DrawerLayoutCaller {

    public static void setLayoutGravity(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        int result = 0;
        for (String flag : value.split("\\|")) {
            Integer g = Constants.gravityMap.get(flag.trim());
            if (g != null) result |= g;
        }
        if (result == 0) return;
        try {
            // DrawerLayout.LayoutParams extends MarginLayoutParams and has a
            // public `gravity` field, accessed via reflection-safe direct field
            // set since the type itself isn't imported here to avoid a hard
            // dependency cycle on androidx.drawerlayout in this module.
            java.lang.reflect.Field gravityField = target.getLayoutParams().getClass().getField("gravity");
            gravityField.setInt(target.getLayoutParams(), result);
            target.setLayoutParams(target.getLayoutParams());
            target.requestLayout();
        } catch (Exception ignored) {}
    }

    public static void setLayoutMargin(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        int margin = (int) DimensionUtil.parse(value, context);
        ((ViewGroup.MarginLayoutParams) target.getLayoutParams()).setMargins(margin, margin, margin, margin);
        target.requestLayout();
    }

    public static void setLayoutMarginLeft(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        ((ViewGroup.MarginLayoutParams) target.getLayoutParams()).leftMargin =
            (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }

    public static void setLayoutMarginRight(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        ((ViewGroup.MarginLayoutParams) target.getLayoutParams()).rightMargin =
            (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }

    public static void setLayoutMarginTop(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        ((ViewGroup.MarginLayoutParams) target.getLayoutParams()).topMargin =
            (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }

    public static void setLayoutMarginBottom(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return;
        ((ViewGroup.MarginLayoutParams) target.getLayoutParams()).bottomMargin =
            (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }
}
