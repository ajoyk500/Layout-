package com.itsvks.layouteditor.editor.palette;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

import com.itsvks.layouteditor.utils.Constants;
import com.itsvks.layouteditor.utils.Utils;

/**
 * A generic placeholder widget for any view type the editor doesn't have a
 * dedicated Design class for. Renders as a plain View with the standard
 * stroke/blueprint behavior so it integrates with the rest of the canvas.
 */
public class UnknownViewDesign extends View {

    private boolean drawStrokeEnabled;
    private boolean isBlueprint;

    public UnknownViewDesign(Context context) {
        super(context);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (drawStrokeEnabled)
            Utils.drawDashPathStroke(
                this, canvas, isBlueprint ? Constants.BLUEPRINT_DASH_COLOR : Constants.DESIGN_DASH_COLOR);
    }

    public void setStrokeEnabled(boolean enabled) {
        drawStrokeEnabled = enabled;
        invalidate();
    }

    @Override
    public void draw(Canvas canvas) {
        if (isBlueprint) Utils.drawDashPathStroke(this, canvas, Constants.BLUEPRINT_DASH_COLOR);
        else super.draw(canvas);
    }

    public void setBlueprint(boolean isBlueprint) {
        this.isBlueprint = isBlueprint;
        invalidate();
    }
}
