package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link ExtendedFloatingActionButton}. */
public class ExtendedFABCaller {

    public static void setText(View target, String value, Context context) {
        ViewCaller.setText(target, value, context);
    }

    public static void setExtended(View target, String value, Context context) {
        if (!(target instanceof ExtendedFloatingActionButton)) return;
        ExtendedFloatingActionButton fab = (ExtendedFloatingActionButton) target;
        if (value.equals("true")) fab.extend();
        else fab.shrink();
    }

    public static void setBackgroundTintList(View target, String value, Context context) {
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) target.setBackgroundTintList(ColorStateList.valueOf(color));
    }
}
