package com.itsvks.layouteditor.managers

import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.itsvks.layouteditor.LayoutEditor.Companion.instance

object PreferencesManager {
    @JvmStatic
    val isEnableVibration: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_VIBRATION, false)

    @JvmStatic
    val isShowStroke: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_TOGGLE_STROKE, true)

    /** Whether the alignment/grid design canvas should draw a grid overlay. */
    @JvmStatic
    var isShowGrid: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_SHOW_GRID, false)
        set(value) = prefs.edit { putBoolean(SharedPreferencesKeys.KEY_SHOW_GRID, value) }

    /** Whether dimension values (margins/padding/etc.) should snap to the grid size. */
    @JvmStatic
    var isSnapToGrid: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_SNAP_TO_GRID, false)
        set(value) = prefs.edit { putBoolean(SharedPreferencesKeys.KEY_SNAP_TO_GRID, value) }

    /** Whether alignment guide lines should be shown while dragging widgets. */
    @JvmStatic
    var isShowAlignmentGuides: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_SHOW_ALIGNMENT_GUIDES, true)
        set(value) = prefs.edit { putBoolean(SharedPreferencesKeys.KEY_SHOW_ALIGNMENT_GUIDES, value) }

    /** The grid size in dp, used for both the grid overlay and snap-to-grid. */
    @JvmStatic
    var gridSize: Int
        get() = prefs.getInt(SharedPreferencesKeys.KEY_GRID_SIZE, 8)
        set(value) = prefs.edit { putInt(SharedPreferencesKeys.KEY_GRID_SIZE, value) }

    @JvmStatic
    val isApplyDynamicColors: Boolean
        get() = prefs.getBoolean(SharedPreferencesKeys.KEY_DYNAMIC_COLORS, false)

    @JvmStatic
    val currentTheme: Int
        get() = when (prefs.getString(SharedPreferencesKeys.KEY_APP_THEME, "Auto")) {
            "Light" -> AppCompatDelegate.MODE_NIGHT_NO
            "Dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }

    @JvmStatic
    val prefs: SharedPreferences
        get() = PreferenceManager.getDefaultSharedPreferences(instance!!.context)
}
