package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

/**
 * Caller for the design-time-only {@code tools:viewBehavior} attribute used
 * by {@link com.itsvks.layouteditor.editor.palette.UnknownViewDesign}. This
 * is purely a placeholder/documentation attribute — it has no runtime effect
 * (the "tools:" namespace is stripped at build time by the Android Gradle
 * Plugin), so this method intentionally does nothing.
 */
public class UnknownViewDesignCaller {
    public static void setBehavior(View target, String value, Context context) {
        // No-op: tools: namespace attributes are design-time only.
    }
}
