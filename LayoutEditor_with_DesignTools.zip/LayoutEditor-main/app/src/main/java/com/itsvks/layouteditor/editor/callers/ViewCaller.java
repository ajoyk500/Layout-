package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;

import com.itsvks.layouteditor.managers.IdManager;
import com.itsvks.layouteditor.utils.ArgumentUtil;
import com.itsvks.layouteditor.utils.Constants;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

public class ViewCaller {
    public static void setId(View target, String value, Context context) {
        IdManager.addNewId(target, value);
    }

    public static void setLayoutWidth(View target, String value, Context context) {
        target.getLayoutParams().width = (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }

    public static void setLayoutHeight(View target, String value, Context context) {
        target.getLayoutParams().height = (int) DimensionUtil.parse(value, context);
        target.requestLayout();
    }

    public static void setBackground(View target, String value, Context context) {
        if (ArgumentUtil.parseType(value, new String[]{"color", "drawable"})
            .equals(ArgumentUtil.COLOR)) {
            try {
                target.setBackgroundColor(Color.parseColor(value));
            } catch (Exception ignored) {}
        } else {
            // Resolves "@drawable/...", "@mipmap/...", AND "@android:drawable/..."
            Drawable d = ResourceResolver.resolveDrawable(context, value);
            if (d != null) target.setBackground(d);
        }
    }

    public static void setForeground(View target, String value, Context context) {
        if (ArgumentUtil.parseType(value, new String[]{"color", "drawable"})
            .equals(ArgumentUtil.COLOR)) {
            try {
                target.setForeground(new ColorDrawable(Color.parseColor(value)));
            } catch (Exception ignored) {}
        } else {
            Drawable d = ResourceResolver.resolveDrawable(context, value);
            if (d != null) target.setForeground(d);
        }
    }

    public static void setElevation(View target, String value, Context context) {
        target.setElevation(DimensionUtil.parse(value, context));
    }

    public static void setAlpha(View target, String value, Context context) {
        target.setAlpha(Float.valueOf(value));
    }

    public static void setRotation(View target, String value, Context context) {
        target.setRotation(Float.valueOf(value));
    }

    public static void setRotationX(View target, String value, Context context) {
        target.setRotationX(Float.valueOf(value));
    }

    public static void setRotationY(View target, String value, Context context) {
        target.setRotationY(Float.valueOf(value));
    }

    public static void setTranslationX(View target, String value, Context context) {
        target.setTranslationX(DimensionUtil.parse(value, context));
    }

    public static void setTranslationY(View target, String value, Context context) {
        target.setTranslationY(DimensionUtil.parse(value, context));
    }

    public static void setTranslationZ(View target, String value, Context context) {
        target.setTranslationZ(DimensionUtil.parse(value, context));
    }

    public static void setScaleX(View target, String value, Context context) {
        target.setScaleX(Float.valueOf(value));
    }

    public static void setScaleY(View target, String value, Context context) {
        target.setScaleY(Float.valueOf(value));
    }

    public static void setPadding(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPadding(pad, pad, pad, pad);
    }

    public static void setPaddingLeft(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPadding(
            pad, target.getPaddingTop(), target.getPaddingRight(), target.getPaddingBottom());
    }

    public static void setPaddingRight(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPadding(
            target.getPaddingLeft(), target.getPaddingTop(), pad, target.getPaddingBottom());
    }

    public static void setPaddingTop(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPadding(
            target.getPaddingLeft(), pad, target.getPaddingRight(), target.getPaddingBottom());
    }

    public static void setPaddingBottom(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPadding(
            target.getPaddingLeft(), target.getPaddingTop(), target.getPaddingRight(), pad);
    }

    public static void setEnabled(View target, String value, Context context) {
        target.setEnabled(value.equals("true"));
    }

    public static void setVisibility(View target, String value, Context context) {
        Integer visibility = Constants.visibilityMap.get(value);
        if (visibility != null) target.setVisibility(visibility);
    }

    public static void setPaddingStart(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPaddingRelative(pad, target.getPaddingTop(), target.getPaddingEnd(), target.getPaddingBottom());
    }

    public static void setPaddingEnd(View target, String value, Context context) {
        int pad = (int) DimensionUtil.parse(value, context);
        target.setPaddingRelative(target.getPaddingStart(), target.getPaddingTop(), pad, target.getPaddingBottom());
    }

    public static void setMinWidth(View target, String value, Context context) {
        target.setMinimumWidth((int) DimensionUtil.parse(value, context));
    }

    public static void setMinHeight(View target, String value, Context context) {
        target.setMinimumHeight((int) DimensionUtil.parse(value, context));
    }

    public static void setClickable(View target, String value, Context context) {
        target.setClickable(value.equals("true"));
    }

    public static void setFocusable(View target, String value, Context context) {
        target.setFocusable(value.equals("true"));
    }

    public static void setContentDescription(View target, String value, Context context) {
        target.setContentDescription(value);
    }

    public static void setTag(View target, String value, Context context) {
        target.setTag(value);
    }

    public static void setLayoutDirection(View target, String value, Context context) {
        switch (value) {
            case "ltr": target.setLayoutDirection(View.LAYOUT_DIRECTION_LTR); break;
            case "rtl": target.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); break;
            case "inherit": target.setLayoutDirection(View.LAYOUT_DIRECTION_INHERIT); break;
            case "locale": target.setLayoutDirection(View.LAYOUT_DIRECTION_LOCALE); break;
        }
    }

    /**
     * Universal text setter — works for any TextView-based widget (Button,
     * MaterialButton, MaterialCheckBox, MaterialRadioButton, SearchBar, etc.)
     * that doesn't have its own dedicated caller for android:text. Resolves
     * @string/ references the same way TextViewCaller.setText does.
     */
    public static void setText(View target, String value, Context context) {
        if (value.startsWith("@string/")) {
            com.itsvks.layouteditor.ProjectFile project =
                com.itsvks.layouteditor.managers.ProjectManager.getInstance().getOpenedProject();
            value = com.itsvks.layouteditor.managers.ValuesManager.getValueFromResources(
                com.itsvks.layouteditor.tools.ValuesResourceParser.TAG_STRING,
                value, project.getStringsPath());
        }
        if (target instanceof android.widget.TextView) {
            ((android.widget.TextView) target).setText(value);
        }
    }

    /**
     * Universal checked-state setter — works for any Checkable widget
     * (MaterialCheckBox, MaterialRadioButton, MaterialSwitch fallback, etc.).
     */
    public static void setChecked(View target, String value, Context context) {
        if (target instanceof android.widget.Checkable) {
            ((android.widget.Checkable) target).setChecked(value.equals("true"));
        }
    }

    /**
     * Universal hint setter — works for any TextView-based widget that
     * supports hints (EditText, AutoCompleteTextView, MaterialAutoCompleteTextView).
     */
    public static void setHint(View target, String value, Context context) {
        if (target instanceof android.widget.TextView) {
            ((android.widget.TextView) target).setHint(value);
        }
    }
}
