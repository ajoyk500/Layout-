package com.itsvks.layouteditor.editor.callers.layouts;

import android.content.Context;
import android.view.View;
import android.widget.GridLayout;

/** Attribute caller for {@link GridLayout} widget-level (non-child) attributes. */
public class GridLayoutCaller {

    public static void setRowCount(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            try { ((GridLayout) target).setRowCount(Integer.parseInt(value)); } catch (Exception ignored) {}
        }
    }

    public static void setColumnCount(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            try { ((GridLayout) target).setColumnCount(Integer.parseInt(value)); } catch (Exception ignored) {}
        }
    }

    public static void setOrientation(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            int orientation = value.equals("horizontal") ? GridLayout.HORIZONTAL : GridLayout.VERTICAL;
            ((GridLayout) target).setOrientation(orientation);
        }
    }

    public static void setUseDefaultMargins(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            ((GridLayout) target).setUseDefaultMargins(value.equals("true"));
        }
    }

    public static void setGravity(View target, String value, Context context) {
        // GridLayout itself has no public setGravity(int) API at the widget
        // level (gravity only applies per-child via layout_gravity). Kept as
        // a safe no-op so the attribute doesn't crash if present in XML.
    }

    public static void setAlignmentMode(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            int mode = value.equals("alignBounds") ? GridLayout.ALIGN_BOUNDS : GridLayout.ALIGN_MARGINS;
            ((GridLayout) target).setAlignmentMode(mode);
        }
    }

    public static void setColumnOrderPreserved(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            ((GridLayout) target).setColumnOrderPreserved(value.equals("true"));
        }
    }

    public static void setRowOrderPreserved(View target, String value, Context context) {
        if (target instanceof GridLayout) {
            ((GridLayout) target).setRowOrderPreserved(value.equals("true"));
        }
    }
}
