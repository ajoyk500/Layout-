package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link LinearProgressIndicator}. */
public class LinearProgressCaller {

    public static void setProgressCompat(View target, String value, Context context) {
        if (target instanceof LinearProgressIndicator) {
            try {
                ((LinearProgressIndicator) target).setProgressCompat(Integer.parseInt(value), true);
            } catch (Exception ignored) {}
        }
    }

    public static void setIndeterminate(View target, String value, Context context) {
        if (target instanceof LinearProgressIndicator) {
            ((LinearProgressIndicator) target).setIndeterminate(value.equals("true"));
        }
    }

    public static void setIndicatorColor(View target, String value, Context context) {
        if (target instanceof LinearProgressIndicator) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((LinearProgressIndicator) target).setIndicatorColor(color);
        }
    }

    public static void setTrackColor(View target, String value, Context context) {
        if (target instanceof LinearProgressIndicator) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((LinearProgressIndicator) target).setTrackColor(color);
        }
    }

    public static void setTrackThickness(View target, String value, Context context) {
        if (target instanceof LinearProgressIndicator) {
            try {
                ((LinearProgressIndicator) target).setTrackThickness((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }
}
