package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.divider.MaterialDivider;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link MaterialDivider}. */
public class MaterialDividerCaller {

    public static void setDividerColor(View target, String value, Context context) {
        if (target instanceof MaterialDivider) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((MaterialDivider) target).setDividerColor(color);
        }
    }

    public static void setDividerThickness(View target, String value, Context context) {
        if (target instanceof MaterialDivider) {
            try {
                ((MaterialDivider) target).setDividerThickness((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }

    public static void setDividerInsetStart(View target, String value, Context context) {
        if (target instanceof MaterialDivider) {
            try {
                ((MaterialDivider) target).setDividerInsetStart((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }

    public static void setDividerInsetEnd(View target, String value, Context context) {
        if (target instanceof MaterialDivider) {
            try {
                ((MaterialDivider) target).setDividerInsetEnd((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }
}
