package com.itsvks.layouteditor.activities

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.core.content.res.ResourcesCompat
import com.blankj.utilcode.util.ClipboardUtils
import com.blankj.utilcode.util.ToastUtils
import com.itsvks.layouteditor.BaseActivity
import com.itsvks.layouteditor.LayoutFile
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.databinding.ActivityShowXMLBinding
import com.itsvks.layouteditor.utils.SBUtils.Companion.make
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver
import org.eclipse.tm4e.core.registry.IThemeSource

class ShowXMLActivity : BaseActivity() {
    private var binding: ActivityShowXMLBinding? = null

    /** The layout file path passed from EditorActivity — used to save directly. */
    private var layoutFilePath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowXMLBinding.inflate(layoutInflater)

        setContentView(binding!!.root)
        setSupportActionBar(binding!!.topAppBar)
        supportActionBar!!.setTitle(R.string.xml_editor)
        supportActionBar!!.setDisplayHomeAsUpEnabled(false)

        binding!!.topAppBar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        layoutFilePath = intent.getStringExtra(EXTRA_KEY_LAYOUT_PATH)

        binding!!.editor.apply {
            setText(intent.getStringExtra(EXTRA_KEY_XML))
            typefaceText = jetBrainsMono()
            typefaceLineNumber = jetBrainsMono()
            // NOW EDITABLE — user can type and modify XML
            isEditable = true
        }

        try {
            loadDefaultThemes()
            ThemeRegistry.getInstance().setTheme("darcula")
            loadDefaultLanguages()
            ensureTextmateTheme()
            val language = TextMateLanguage.create("text.xml", true)
            binding!!.editor.setEditorLanguage(language)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // FAB = Copy to clipboard (existing behavior)
        binding!!.fab.setOnClickListener {
            ClipboardUtils.copyText(binding!!.editor.text.toString())
            make(binding!!.root, getString(R.string.copied))
                .setAnchorView(binding!!.fab)
                .setSlideAnimation()
                .show()
        }

        binding!!.editor.setOnScrollChangeListener { _, _, y, _, oldY ->
            if (y > oldY + 20 && binding!!.fab.isExtended) binding!!.fab.shrink()
            if (y < oldY - 20 && !binding!!.fab.isExtended) binding!!.fab.extend()
            if (y == 0) binding!!.fab.extend()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_xml_editor, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save_xml -> {
                saveXmlAndReturn()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    /**
     * Saves the edited XML:
     * 1. Writes directly to the layout file on disk (if path was provided).
     * 2. Sends the new XML back to EditorActivity via setResult so the canvas reloads.
     */
    private fun saveXmlAndReturn() {
        val newXml = binding!!.editor.text.toString().trim()

        // Save to disk if we know the file path
        layoutFilePath?.let { path ->
            try {
                LayoutFile(path).saveLayout(newXml)
                ToastUtils.showShort(getString(R.string.layout_saved))
            } catch (e: Exception) {
                e.printStackTrace()
                ToastUtils.showShort(getString(R.string.error_saving_xml))
            }
        }

        // Return updated XML to EditorActivity
        val resultIntent = Intent().putExtra(EXTRA_KEY_XML, newXml)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    override fun onDestroy() {
        binding = null
        super.onDestroy()
    }

    @Throws(Exception::class)
    private fun loadDefaultThemes() {
        FileProviderRegistry.getInstance()
            .addFileProvider(AssetsFileResolver(applicationContext.assets))

        val themeRegistry = ThemeRegistry.getInstance()
        val path = "editor/textmate/darcula.json"
        themeRegistry.loadTheme(
            ThemeModel(
                IThemeSource.fromInputStream(
                    FileProviderRegistry.getInstance().tryGetInputStream(path), path, null
                ), "darcula"
            )
        )
        themeRegistry.setTheme("darcula")
    }

    private fun loadDefaultLanguages() {
        GrammarRegistry.getInstance().loadGrammars("editor/textmate/languages.json")
    }

    @Throws(Exception::class)
    private fun ensureTextmateTheme() {
        val editor = binding!!.editor
        var editorColorScheme = editor.colorScheme
        if (editorColorScheme !is TextMateColorScheme) {
            editorColorScheme = TextMateColorScheme.create(ThemeRegistry.getInstance())
            editor.colorScheme = editorColorScheme
        }
    }

    private fun jetBrainsMono(): Typeface? {
        return ResourcesCompat.getFont(this, R.font.jetbrains_mono_regular)
    }

    companion object {
        const val EXTRA_KEY_XML: String = "xml"
        /** Path of the LayoutFile — so ShowXMLActivity can save directly to disk. */
        const val EXTRA_KEY_LAYOUT_PATH: String = "layout_path"
        /** Result code when user saves XML from editor. */
        const val RESULT_XML_SAVED: Int = 1001
    }
}
