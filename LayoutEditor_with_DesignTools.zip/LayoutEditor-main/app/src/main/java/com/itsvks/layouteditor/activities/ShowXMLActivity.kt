package com.itsvks.layouteditor.activities

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.addCallback
import androidx.core.content.res.ResourcesCompat
import com.blankj.utilcode.util.ClipboardUtils
import com.itsvks.layouteditor.BaseActivity
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.databinding.ActivityShowXMLBinding
import com.itsvks.layouteditor.utils.SBUtils
import com.itsvks.layouteditor.utils.SBUtils.Companion.make
import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver
import org.eclipse.tm4e.core.registry.IThemeSource

class ShowXMLActivity : BaseActivity() {

    private var binding: ActivityShowXMLBinding? = null

    /** Whether the XML was modified and saved — used to decide result code. */
    private var xmlChanged = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShowXMLBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        setSupportActionBar(binding!!.topAppBar)
        supportActionBar!!.setTitle(R.string.xml_preview)

        // Back arrow — same as back press
        binding!!.topAppBar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // Load XML into editor — NOW EDITABLE
        binding!!.editor.apply {
            setText(intent.getStringExtra(EXTRA_KEY_XML) ?: "")
            typefaceText = jetBrainsMono()
            typefaceLineNumber = jetBrainsMono()
            isEditable = true          // <-- key change: allow editing
        }

        // Setup syntax highlighting
        try {
            loadDefaultThemes()
            ThemeRegistry.getInstance().setTheme("darcula")
            loadDefaultLanguages()
            ensureTextmateTheme()
            binding!!.editor.setEditorLanguage(TextMateLanguage.create("text.xml", true))
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Copy FAB — copies current editor content
        binding!!.fab.setOnClickListener {
            ClipboardUtils.copyText(binding!!.editor.text.toString())
            make(binding!!.root, getString(R.string.copied))
                .setAnchorView(binding!!.fab)
                .setSlideAnimation()
                .show()
        }

        // Shrink/extend FAB on scroll
        binding!!.editor.setOnScrollChangeListener { _, _, y, _, oldY ->
            if (y > oldY + 20 && binding!!.fab.isExtended) binding!!.fab.shrink()
            if (y < oldY - 20 && !binding!!.fab.isExtended) binding!!.fab.extend()
            if (y == 0) binding!!.fab.extend()
        }

        // Back press — if xml was changed and saved, return RESULT_OK
        onBackPressedDispatcher.addCallback(this) {
            finishWithResult()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_show_xml, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.save_xml_changes) {
            saveXmlAndReturn()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    /**
     * Validates the edited XML, then sends it back to EditorActivity
     * via setResult so the canvas reloads instantly.
     */
    private fun saveXmlAndReturn() {
        val editedXml = binding!!.editor.text.toString().trim()

        if (editedXml.isEmpty()) {
            make(binding!!.root, "XML is empty — nothing to save")
                .setType(SBUtils.Type.INFO)
                .setFadeAnimation()
                .show()
            return
        }

        // Quick XML well-formedness check
        try {
            val factory = org.xmlpull.v1.XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setInput(java.io.StringReader(editedXml))
            while (parser.eventType != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                parser.next()
            }
        } catch (e: Exception) {
            // Show exact error — line + column from the parser
            make(binding!!.root, "XML Error: ${e.message ?: "Invalid XML"}")
                .setType(SBUtils.Type.ERROR)
                .setSlideAnimation()
                .show()
            return   // stay on screen, let user fix the error
        }

        // XML is valid — send back to EditorActivity
        xmlChanged = true
        val result = Intent().apply {
            putExtra(EXTRA_KEY_XML, editedXml)
        }
        setResult(RESULT_OK, result)

        make(binding!!.root, "Saved — returning to editor…")
            .setType(SBUtils.Type.SUCCESS)
            .setFadeAnimation()
            .show()

        // Small delay so the snackbar is visible, then close
        binding!!.root.postDelayed({ finish() }, 700)
    }

    /** Called on back press — returns RESULT_CANCELED if nothing was saved. */
    private fun finishWithResult() {
        if (!xmlChanged) {
            setResult(RESULT_CANCELED)
        }
        finish()
    }

    override fun onDestroy() {
        binding = null
        super.onDestroy()
    }

    // ── TextMate / Sora setup (unchanged from original) ──────────────────────

    @Throws(Exception::class)
    private fun loadDefaultThemes() {
        FileProviderRegistry.getInstance()
            .addFileProvider(AssetsFileResolver(applicationContext.assets))

        val themeRegistry = ThemeRegistry.getInstance()
        val path = "editor/textmate/darcula.json"
        themeRegistry.loadTheme(
            ThemeModel(
                IThemeSource.fromInputStream(
                    FileProviderRegistry.getInstance().tryGetInputStream(path), path, null
                ), "darcula"
            )
        )
        themeRegistry.setTheme("darcula")
    }

    private fun loadDefaultLanguages() {
        GrammarRegistry.getInstance().loadGrammars("editor/textmate/languages.json")
    }

    @Throws(Exception::class)
    private fun ensureTextmateTheme() {
        val editor = binding!!.editor
        var scheme = editor.colorScheme
        if (scheme !is TextMateColorScheme) {
            scheme = TextMateColorScheme.create(ThemeRegistry.getInstance())
            editor.colorScheme = scheme
        }
    }

    private fun jetBrainsMono(): Typeface? =
        ResourcesCompat.getFont(this, R.font.jetbrains_mono_regular)

    companion object {
        const val EXTRA_KEY_XML: String = "xml"
    }
}
