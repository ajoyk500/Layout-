package com.itsvks.layouteditor.editor.callers.text;

import android.content.Context;
import android.graphics.Color;
import android.view.View;
import android.widget.CheckedTextView;
import android.widget.TextView;

import com.itsvks.layouteditor.ProjectFile;
import com.itsvks.layouteditor.managers.DrawableManager;
import com.itsvks.layouteditor.managers.ProjectManager;
import com.itsvks.layouteditor.managers.ValuesManager;
import com.itsvks.layouteditor.tools.ValuesResourceParser;
import com.itsvks.layouteditor.utils.Constants;
import com.itsvks.layouteditor.utils.DimensionUtil;

public class TextViewCaller {
    public static void setText(View target, String value, Context context) {
        if (value.startsWith("@string/")) {
            ProjectFile project = ProjectManager.getInstance().getOpenedProject();

            value =
                ValuesManager.getValueFromResources(
                    ValuesResourceParser.TAG_STRING, value, project.getStringsPath());
        }
        ((TextView) target).setText(value);
    }

    public static void setTextSize(View target, String value, Context context) {
        ((TextView) target).setTextSize(DimensionUtil.parse(value, context));
    }

    public static void setTextColor(View target, String value, Context context) {
        ((TextView) target).setTextColor(Color.parseColor(value));
    }

    public static void setGravity(View target, String value, Context context) {
        String[] flags = value.split("\\|");
        int result = 0;

        for (String flag : flags) {
            result |= Constants.gravityMap.get(flag);
        }

        ((TextView) target).setGravity(result);
    }

    public static void setCheckMark(View target, String value, Context context) {
        String name = value.replace("@drawable/", "");
        if (target instanceof CheckedTextView)
            ((CheckedTextView) target).setCheckMarkDrawable(DrawableManager.getDrawable(context, name));
    }

    public static void setChecked(View target, String value, Context context) {
        if (target instanceof CheckedTextView) {
            if (value.equals("true")) ((CheckedTextView) target).setChecked(true);
            else if (value.equals("false")) ((CheckedTextView) target).setChecked(false);
        }
    }

    public static void setTextStyle(View target, String value, Context context) {
        ((TextView) target).setTypeface(null, Constants.textStyleMap.get(value));
    }

    public static void setMaxLines(View target, String value, Context context) {
        try { ((TextView) target).setMaxLines(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setMinLines(View target, String value, Context context) {
        try { ((TextView) target).setMinLines(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setLines(View target, String value, Context context) {
        try { ((TextView) target).setLines(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setMaxLength(View target, String value, Context context) {
        try {
            int max = Integer.parseInt(value);
            ((TextView) target).setFilters(new android.text.InputFilter[]{
                new android.text.InputFilter.LengthFilter(max)
            });
        } catch (Exception ignored) {}
    }

    public static void setEllipsize(View target, String value, Context context) {
        android.text.TextUtils.TruncateAt where;
        switch (value) {
            case "start":   where = android.text.TextUtils.TruncateAt.START; break;
            case "middle":  where = android.text.TextUtils.TruncateAt.MIDDLE; break;
            case "end":     where = android.text.TextUtils.TruncateAt.END; break;
            case "marquee": where = android.text.TextUtils.TruncateAt.MARQUEE; break;
            default:        ((TextView) target).setEllipsize(null); return;
        }
        ((TextView) target).setEllipsize(where);
    }

    public static void setLetterSpacing(View target, String value, Context context) {
        try { ((TextView) target).setLetterSpacing(Float.parseFloat(value)); } catch (Exception ignored) {}
    }

    public static void setLineSpacingExtra(View target, String value, Context context) {
        TextView tv = (TextView) target;
        tv.setLineSpacing(DimensionUtil.parse(value, context), tv.getLineSpacingMultiplier());
    }

    public static void setLineSpacingMultiplier(View target, String value, Context context) {
        try {
            TextView tv = (TextView) target;
            tv.setLineSpacing(tv.getLineSpacingExtra(), Float.parseFloat(value));
        } catch (Exception ignored) {}
    }

    public static void setFontFamily(View target, String value, Context context) {
        try {
            android.graphics.Typeface tf = android.graphics.Typeface.create(value, android.graphics.Typeface.NORMAL);
            ((TextView) target).setTypeface(tf);
        } catch (Exception ignored) {}
    }

    public static void setTextAllCaps(View target, String value, Context context) {
        ((TextView) target).setAllCaps(value.equals("true"));
    }

    public static void setDrawableLeft(View target, String value, Context context) {
        String name = value.replace("@drawable/", "");
        android.graphics.drawable.Drawable d = com.itsvks.layouteditor.managers.DrawableManager.getDrawable(context, name);
        TextView tv = (TextView) target;
        android.graphics.drawable.Drawable[] cmp = tv.getCompoundDrawables();
        tv.setCompoundDrawablesWithIntrinsicBounds(d, cmp[1], cmp[2], cmp[3]);
    }

    public static void setDrawableRight(View target, String value, Context context) {
        String name = value.replace("@drawable/", "");
        android.graphics.drawable.Drawable d = com.itsvks.layouteditor.managers.DrawableManager.getDrawable(context, name);
        TextView tv = (TextView) target;
        android.graphics.drawable.Drawable[] cmp = tv.getCompoundDrawables();
        tv.setCompoundDrawablesWithIntrinsicBounds(cmp[0], cmp[1], d, cmp[3]);
    }

    public static void setDrawableTop(View target, String value, Context context) {
        String name = value.replace("@drawable/", "");
        android.graphics.drawable.Drawable d = com.itsvks.layouteditor.managers.DrawableManager.getDrawable(context, name);
        TextView tv = (TextView) target;
        android.graphics.drawable.Drawable[] cmp = tv.getCompoundDrawables();
        tv.setCompoundDrawablesWithIntrinsicBounds(cmp[0], d, cmp[2], cmp[3]);
    }

    public static void setDrawableBottom(View target, String value, Context context) {
        String name = value.replace("@drawable/", "");
        android.graphics.drawable.Drawable d = com.itsvks.layouteditor.managers.DrawableManager.getDrawable(context, name);
        TextView tv = (TextView) target;
        android.graphics.drawable.Drawable[] cmp = tv.getCompoundDrawables();
        tv.setCompoundDrawablesWithIntrinsicBounds(cmp[0], cmp[1], cmp[2], d);
    }

    public static void setDrawablePadding(View target, String value, Context context) {
        ((TextView) target).setCompoundDrawablePadding((int) DimensionUtil.parse(value, context));
    }

    public static void setTextColorLink(View target, String value, Context context) {
        try { ((TextView) target).setLinkTextColor(android.graphics.Color.parseColor(value)); } catch (Exception ignored) {}
    }

    public static void setTextColorHighlight(View target, String value, Context context) {
        try { ((TextView) target).setHighlightColor(android.graphics.Color.parseColor(value)); } catch (Exception ignored) {}
    }

    public static void setAutoLink(View target, String value, Context context) {
        int mask = 0;
        for (String flag : value.split("\\|")) {
            switch (flag.trim()) {
                case "web":   mask |= android.text.util.Linkify.WEB_URLS; break;
                case "email": mask |= android.text.util.Linkify.EMAIL_ADDRESSES; break;
                case "phone": mask |= android.text.util.Linkify.PHONE_NUMBERS; break;
                case "map":   mask |= android.text.util.Linkify.MAP_ADDRESSES; break;
                case "all":   mask |= android.text.util.Linkify.ALL; break;
            }
        }
        ((TextView) target).setAutoLinkMask(mask);
    }

    public static void setEms(View target, String value, Context context) {
        try { ((TextView) target).setEms(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setMaxEms(View target, String value, Context context) {
        try { ((TextView) target).setMaxEms(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setMinEms(View target, String value, Context context) {
        try { ((TextView) target).setMinEms(Integer.parseInt(value)); } catch (Exception ignored) {}
    }

    public static void setCapitalize(View target, String value, Context context) {
        // capitalize is deprecated but still functional via inputType flags
        int inputType = ((TextView) target).getInputType();
        switch (value) {
            case "sentences": inputType |= android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES; break;
            case "words":     inputType |= android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS; break;
            case "characters":inputType |= android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS; break;
            default: break;
        }
        ((TextView) target).setInputType(inputType);
    }
}
