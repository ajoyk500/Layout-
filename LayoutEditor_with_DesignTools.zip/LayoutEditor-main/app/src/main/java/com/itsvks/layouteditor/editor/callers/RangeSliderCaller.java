package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.slider.RangeSlider;

/** Attribute caller for {@link RangeSlider}. */
public class RangeSliderCaller {

    public static void setValueFrom(View target, String value, Context context) {
        if (target instanceof RangeSlider) {
            try { ((RangeSlider) target).setValueFrom(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }

    public static void setValueTo(View target, String value, Context context) {
        if (target instanceof RangeSlider) {
            try { ((RangeSlider) target).setValueTo(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }

    public static void setStepSize(View target, String value, Context context) {
        if (target instanceof RangeSlider) {
            try { ((RangeSlider) target).setStepSize(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }
}
