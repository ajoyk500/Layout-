package com.itsvks.layouteditor.editor.callers.parentcallers;

import android.content.Context;
import android.view.View;
import android.widget.GridLayout;

/** Handles GridLayout.LayoutParams (child-of-GridLayout) attributes. */
public class GridLayoutCaller {

    public static void setLayoutRow(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.rowSpec = GridLayout.spec(Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutColumn(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.columnSpec = GridLayout.spec(Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutRowSpan(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            int row = lp.rowSpec.span.min == Integer.MIN_VALUE ? 0 : lp.rowSpec.span.min;
            lp.rowSpec = GridLayout.spec(row, Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutColumnSpan(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            int col = lp.columnSpec.span.min == Integer.MIN_VALUE ? 0 : lp.columnSpec.span.min;
            lp.columnSpec = GridLayout.spec(col, Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutGravity(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        int result = 0;
        for (String flag : value.split("\\|")) {
            Integer g = com.itsvks.layouteditor.utils.Constants.gravityMap.get(flag.trim());
            if (g != null) result |= g;
        }
        if (result == 0) return;
        GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
        lp.setGravity(result);
        target.setLayoutParams(lp);
    }
}
