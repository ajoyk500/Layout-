package com.itsvks.layouteditor.editor.callers.parentcallers;

import android.content.Context;
import android.view.View;
import android.widget.GridLayout;

import java.util.WeakHashMap;

/**
 * Handles GridLayout.LayoutParams (child-of-GridLayout) attributes.
 *
 * GridLayout.Spec's internal "span" field is package-private, so it can't be
 * read back to combine an existing row/column index with a new span size.
 * Instead, we remember the last-set row/column index per view in a
 * WeakHashMap (so it never leaks views) so setLayoutRowSpan/
 * setLayoutColumnSpan work correctly regardless of the order the attributes
 * appear in the XML.
 */
public class GridLayoutCaller {

    private static final WeakHashMap<View, Integer> rowIndices = new WeakHashMap<>();
    private static final WeakHashMap<View, Integer> columnIndices = new WeakHashMap<>();

    public static void setLayoutRow(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            int row = Integer.parseInt(value);
            rowIndices.put(target, row);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.rowSpec = GridLayout.spec(row);
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutColumn(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            int col = Integer.parseInt(value);
            columnIndices.put(target, col);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.columnSpec = GridLayout.spec(col);
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutRowSpan(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            int row = rowIndices.getOrDefault(target, 0);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.rowSpec = GridLayout.spec(row, Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutColumnSpan(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        try {
            int col = columnIndices.getOrDefault(target, 0);
            GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
            lp.columnSpec = GridLayout.spec(col, Integer.parseInt(value));
            target.setLayoutParams(lp);
        } catch (Exception ignored) {}
    }

    public static void setLayoutGravity(View target, String value, Context context) {
        if (!(target.getLayoutParams() instanceof GridLayout.LayoutParams)) return;
        int result = 0;
        for (String flag : value.split("\\|")) {
            Integer g = com.itsvks.layouteditor.utils.Constants.gravityMap.get(flag.trim());
            if (g != null) result |= g;
        }
        if (result == 0) return;
        GridLayout.LayoutParams lp = (GridLayout.LayoutParams) target.getLayoutParams();
        lp.setGravity(result);
        target.setLayoutParams(lp);
    }
}
