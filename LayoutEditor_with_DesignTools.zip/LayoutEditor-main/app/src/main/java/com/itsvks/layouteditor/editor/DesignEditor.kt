package com.itsvks.layouteditor.editor

import android.animation.LayoutTransition
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.DragEvent
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.View
import android.view.View.OnDragListener
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.widget.TooltipCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.VibrateUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.adapters.AppliedAttributesAdapter
import com.itsvks.layouteditor.databinding.ShowAttributesDialogBinding
import com.itsvks.layouteditor.editor.dialogs.AttributeDialog
import com.itsvks.layouteditor.editor.dialogs.BooleanDialog
import com.itsvks.layouteditor.editor.dialogs.ColorDialog
import com.itsvks.layouteditor.editor.dialogs.DimensionDialog
import com.itsvks.layouteditor.editor.dialogs.EnumDialog
import com.itsvks.layouteditor.editor.dialogs.FlagDialog
import com.itsvks.layouteditor.editor.dialogs.IdDialog
import com.itsvks.layouteditor.editor.dialogs.NumberDialog
import com.itsvks.layouteditor.editor.dialogs.SizeDialog
import com.itsvks.layouteditor.editor.dialogs.StringDialog
import com.itsvks.layouteditor.editor.dialogs.ViewDialog
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager
import com.itsvks.layouteditor.managers.IdManager.addId
import com.itsvks.layouteditor.managers.IdManager.getViewId
import com.itsvks.layouteditor.managers.IdManager.removeId
import com.itsvks.layouteditor.managers.PreferencesManager.isEnableVibration
import com.itsvks.layouteditor.managers.PreferencesManager.isShowAlignmentGuides
import com.itsvks.layouteditor.managers.PreferencesManager.isShowGrid
import com.itsvks.layouteditor.managers.PreferencesManager.isShowStroke
import com.itsvks.layouteditor.managers.UndoRedoManager
import com.itsvks.layouteditor.tools.XmlLayoutGenerator
import com.itsvks.layouteditor.tools.XmlLayoutParser
import com.itsvks.layouteditor.utils.ArgumentUtil.parseType
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil
import com.itsvks.layouteditor.utils.Utils
import com.itsvks.layouteditor.views.StructureView
import kotlin.math.abs
import kotlin.math.round
import androidx.core.view.isEmpty

class DesignEditor : LinearLayout {
    var viewType: ViewType? = null
        set(value) {
            isBlueprint = viewType == ViewType.BLUEPRINT
            setBlueprintOnChildren()
            invalidate()
            field = value
        }
    var deviceConfiguration: DeviceConfiguration? = null
    var apiLevel: APILevel? = null

    lateinit var viewAttributeMap: HashMap<View, AttributeMap>
        private set

    private lateinit var paint: Paint
    private lateinit var shadow: View

    /** Paint used to draw the snap/alignment grid on the canvas.  */
    private lateinit var gridPaint: Paint

    /** Paint used to draw alignment guide lines between the dragged view and its siblings.  */
    private lateinit var guidePaint: Paint

    /** Paint used to draw grid-snap guide lines.  */
    private lateinit var gridSnapPaint: Paint

    /** Paint for constraint connection lines (solid green like Android Studio).  */
    private lateinit var constraintLinePaint: Paint

    /** Paint for the blue anchor dot on view edges.  */
    private lateinit var anchorDotPaint: Paint

    /** Paint for zigzag spring lines (match_constraint / 0dp).  */
    private lateinit var springPaint: Paint

    /** Currently visible alignment/grid guide lines, recomputed while dragging.  */
    private val alignmentGuides = ArrayList<GuideLine>()

    /**
     * A single alignment/snap guide line drawn on top of the canvas.
     *
     * @param vertical `true` for a vertical line (constant x = [position]),
     *   `false` for a horizontal line (constant y = [position]).
     * @param position the coordinate, in px relative to this view, where the line is drawn.
     * @param isGrid `true` if this guide comes from grid-snap alignment rather than from
     *   aligning with a sibling view's edge/center.
     */
    private data class GuideLine(val vertical: Boolean, val position: Float, val isGrid: Boolean)

    private lateinit var attributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var parentAttributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var initializer: AttributeInitializer

    private var isBlueprint = false
    private var structureView: StructureView? = null
    private var undoRedoManager: UndoRedoManager? = null

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context)
    }

    private fun init(context: Context) {
        viewType = ViewType.DESIGN
        isBlueprint = false
        deviceConfiguration = DeviceConfiguration(DeviceSize.LARGE)
        initAttributes()
        shadow = View(context)
        paint = Paint()

        shadow.setBackgroundColor(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutline)
        )
        shadow.layoutParams = ViewGroup.LayoutParams(
            Utils.pxToDp(context, 50),
            Utils.pxToDp(context, 35)
        )
        paint.strokeWidth = Utils.pxToDp(context, 3).toFloat()

        gridPaint = Paint().apply {
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        guidePaint = Paint().apply {
            color = Constants.ALIGNMENT_GUIDE_COLOR
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f, 4f), 0f)
        }
        gridSnapPaint = Paint().apply {
            color = Constants.GRID_SNAP_GUIDE_COLOR
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f, 4f), 0f)
        }
        constraintLinePaint = Paint().apply {
            color = Color.parseColor("#4CAF50")   // green — same as Android Studio
            strokeWidth = Utils.pxToDp(context, 2).toFloat()
            style = Paint.Style.STROKE
            isAntiAlias = true
        }
        anchorDotPaint = Paint().apply {
            color = Color.parseColor("#2196F3")   // blue dots on view edges
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        springPaint = Paint().apply {
            color = Color.parseColor("#4CAF50")
            strokeWidth = Utils.pxToDp(context, 2).toFloat()
            style = Paint.Style.STROKE
            isAntiAlias = true
        }

        orientation = VERTICAL
        setTransition(this)
        setDragListener(this)

        toggleStrokeWidgets()
        setBlueprintOnChildren()
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (isShowGrid) drawGrid(canvas)
        super.dispatchDraw(canvas)
        when (viewType) {
            ViewType.BLUEPRINT -> drawBlueprint(canvas)
            ViewType.DESIGN -> drawDesign(canvas)
            else -> drawDesign(canvas)
        }
        if (alignmentGuides.isNotEmpty()) drawAlignmentGuides(canvas)
        drawConstraintLines(canvas)
        when (deviceConfiguration!!.size) {
            DeviceSize.SMALL -> {
                scaleX = 0.75f
                scaleY = 0.75f
            }

            DeviceSize.MEDIUM -> {
                scaleX = 0.85f
                scaleY = 0.85f
            }

            DeviceSize.LARGE -> {
                scaleX = 0.95f
                scaleY = 0.95f
            }
        }
    }

    private fun drawBlueprint(canvas: Canvas) {
        paint.color = Constants.BLUEPRINT_DASH_COLOR
        setBackgroundColor(Constants.BLUEPRINT_BACKGROUND_COLOR)
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    private fun drawDesign(canvas: Canvas) {
        paint.color = Constants.DESIGN_DASH_COLOR
        setBackgroundColor(Utils.getSurfaceColor(context))
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    /**
     * Draws a faint reference grid across the whole editor canvas. The grid size is
     * [Constants.GRID_SIZE_DP] and is shown behind every view so it acts purely as a visual
     * alignment aid (the "snap to grid" feature also snaps the edges of the dragged view to
     * these lines, see [updateAlignmentGuides]).
     */
    private fun drawGrid(canvas: Canvas) {
        val gridSize = Utils.pxToDp(context, Constants.GRID_SIZE_DP).toFloat()
        if (gridSize <= 0f || width <= 0 || height <= 0) return

        gridPaint.color = if (isBlueprint) Constants.BLUEPRINT_DASH_COLOR else Constants.DESIGN_DASH_COLOR
        gridPaint.alpha = Constants.GRID_LINE_ALPHA

        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += gridSize
        }

        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += gridSize
        }
    }

    /** Draws every guide line currently stored in [alignmentGuides] on top of the editor.  */
    private fun drawAlignmentGuides(canvas: Canvas) {
        for (guide in alignmentGuides) {
            val guidePaintToUse = if (guide.isGrid) gridSnapPaint else guidePaint
            if (guide.vertical) {
                canvas.drawLine(guide.position, 0f, guide.position, height.toFloat(), guidePaintToUse)
            } else {
                canvas.drawLine(0f, guide.position, width.toFloat(), guide.position, guidePaintToUse)
            }
        }
    }

    /**
     * Recomputes the alignment/grid guide lines for the [shadow] view, which represents the
     * position the dragged widget will be dropped at inside [parent].
     *
     * For every sibling view inside [parent], the shadow's left/right/top/bottom edges and
     * its center are compared against the sibling's edges/center; if any pair is within
     * [Constants.ALIGNMENT_THRESHOLD_DP] of each other, a guide line is drawn at that position
     * (Alignment Guides). Separately, the shadow's edges are compared against the editor's
     * grid lines, highlighting any near-grid edge with a snap guide (Snap to Grid).
     *
     * This function only draws visual feedback - it never changes where the widget is
     * actually inserted, so the existing index-based drop logic is left untouched.
     */
    private fun updateAlignmentGuides(parent: ViewGroup) {
        if (shadow.parent == null) {
            clearAlignmentGuides()
            return
        }

        val newGuides = ArrayList<GuideLine>()

        if (isShowAlignmentGuides || isShowGrid) {
            val offset = getOffsetFromRoot(parent)
            val threshold = Utils.pxToDp(context, Constants.ALIGNMENT_THRESHOLD_DP).toFloat()

            val shadowLeft = (shadow.left + offset[0]).toFloat()
            val shadowRight = (shadow.right + offset[0]).toFloat()
            val shadowTop = (shadow.top + offset[1]).toFloat()
            val shadowBottom = (shadow.bottom + offset[1]).toFloat()
            val shadowCenterX = (shadowLeft + shadowRight) / 2f
            val shadowCenterY = (shadowTop + shadowBottom) / 2f

            val seenX = HashSet<Int>()
            val seenY = HashSet<Int>()

            if (isShowAlignmentGuides) {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child === shadow) continue

                    val childLeft = (child.left + offset[0]).toFloat()
                    val childRight = (child.right + offset[0]).toFloat()
                    val childTop = (child.top + offset[1]).toFloat()
                    val childBottom = (child.bottom + offset[1]).toFloat()
                    val childCenterX = (childLeft + childRight) / 2f
                    val childCenterY = (childTop + childBottom) / 2f

                    addGuideIfClose(newGuides, seenX, true, false, shadowLeft, childLeft, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowRight, childRight, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowLeft, childRight, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowRight, childLeft, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowCenterX, childCenterX, threshold)

                    addGuideIfClose(newGuides, seenY, false, false, shadowTop, childTop, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowBottom, childBottom, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowTop, childBottom, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowBottom, childTop, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowCenterY, childCenterY, threshold)
                }
            }

            if (isShowGrid) {
                val gridSize = Utils.pxToDp(context, Constants.GRID_SIZE_DP).toFloat()
                if (gridSize > 0f) {
                    addGridGuideIfClose(newGuides, seenX, true, shadowLeft, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenX, true, shadowRight, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenY, false, shadowTop, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenY, false, shadowBottom, gridSize, threshold)
                }
            }
        }

        if (newGuides != alignmentGuides) {
            alignmentGuides.clear()
            alignmentGuides.addAll(newGuides)
            invalidate()
        }
    }

    /**
     * If [a] and [b] are within [threshold] of each other, adds a guide line at position
     * [b] to [target] (deduplicated via [seen] so multiple sibling edges at the same
     * position only draw a single line).
     */
    private fun addGuideIfClose(
        target: MutableList<GuideLine>,
        seen: MutableSet<Int>,
        vertical: Boolean,
        isGrid: Boolean,
        a: Float,
        b: Float,
        threshold: Float
    ) {
        if (abs(a - b) <= threshold) {
            val key = round(b).toInt()
            if (seen.add(key)) target.add(GuideLine(vertical, b, isGrid))
        }
    }

    /** Snaps [value] to the nearest multiple of [gridSize] and, if close enough, adds a grid guide.  */
    private fun addGridGuideIfClose(
        target: MutableList<GuideLine>,
        seen: MutableSet<Int>,
        vertical: Boolean,
        value: Float,
        gridSize: Float,
        threshold: Float
    ) {
        val nearest = round(value / gridSize) * gridSize
        addGuideIfClose(target, seen, vertical, true, value, nearest, threshold)
    }

    /** Clears any currently displayed alignment/grid guides and redraws if needed.  */
    private fun clearAlignmentGuides() {
        if (alignmentGuides.isNotEmpty()) {
            alignmentGuides.clear()
            invalidate()
        }
    }

    // ── Constraint connection line drawing ────────────────────────────────────

    /**
     * Draws Android-Studio-style constraint connection lines for every view inside a
     * ConstraintLayout that is a direct or nested child of this editor.
     *
     * For each constrained edge the method draws:
     *   • A **curved bezier line** from the view's edge anchor-dot to the target edge
     *     (parent edge or another view's edge).
     *   • A **zigzag "spring"** instead of a straight line when the dimension on that
     *     axis is set to `match_constraint` (0dp), mirroring the Android Studio visual.
     *   • A filled **blue dot** (anchor handle) on each constrained edge of the view.
     *
     * The function is called from [dispatchDraw] so it renders on top of all children
     * but still inside this canvas, meaning coordinates are relative to this editor.
     */
    private fun drawConstraintLines(canvas: Canvas) {
        if (!::viewAttributeMap.isInitialized) return
        drawConstraintLinesInGroup(canvas, this)
    }

    /** Recursively visits every ViewGroup child looking for ConstraintLayouts. */
    private fun drawConstraintLinesInGroup(canvas: Canvas, group: ViewGroup) {
        for (i in 0 until group.childCount) {
            val child = group.getChildAt(i)
            if (child is androidx.constraintlayout.widget.ConstraintLayout) {
                drawConstraintsForLayout(canvas, child)
            }
            if (child is ViewGroup) {
                drawConstraintLinesInGroup(canvas, child)
            }
        }
        // Also handle if the root DesignEditor itself wraps a ConstraintLayout
        if (group is androidx.constraintlayout.widget.ConstraintLayout) {
            drawConstraintsForLayout(canvas, group)
        }
    }

    /**
     * Draws constraint lines for all children of a single [ConstraintLayout].
     * Coordinates are converted to be relative to this [DesignEditor] canvas.
     */
    private fun drawConstraintsForLayout(
        canvas: Canvas,
        constraintLayout: androidx.constraintlayout.widget.ConstraintLayout
    ) {
        // Use getLocationOnScreen for settled, layout-complete coordinates
        val editorLoc = IntArray(2)
        val clLoc = IntArray(2)
        this.getLocationOnScreen(editorLoc)
        constraintLayout.getLocationOnScreen(clLoc)

        val clLeft   = (clLoc[0] - editorLoc[0]).toFloat()
        val clTop    = (clLoc[1] - editorLoc[1]).toFloat()
        val clRight  = clLeft + constraintLayout.width
        val clBottom = clTop  + constraintLayout.height

        val dotRadius = Utils.pxToDp(context, 4).toFloat()

        for (i in 0 until constraintLayout.childCount) {
            val child = constraintLayout.getChildAt(i)
            val map = viewAttributeMap[child] ?: continue

            // Always use settled screen coords — accurate immediately after layout pass
            val childLoc = IntArray(2)
            child.getLocationOnScreen(childLoc)
            val cL  = (childLoc[0] - editorLoc[0]).toFloat()
            val cT  = (childLoc[1] - editorLoc[1]).toFloat()
            val cR  = cL + child.width
            val cB  = cT + child.height
            val cCX = (cL + cR) / 2f
            val cCY = (cT + cB) / 2f

            // Check if this dimension is match_constraint (0dp) → draw spring
            val widthIsSpring  = map.contains("android:layout_width") &&
                    map.getValue("android:layout_width") == "0dp"
            val heightIsSpring = map.contains("android:layout_height") &&
                    map.getValue("android:layout_height") == "0dp"

            // ── LEFT constraints ──────────────────────────────────────────
            val leftToLeft  = getConstraintTarget(map, "app:layout_constraintLeft_toLeftOf")
            val leftToRight = getConstraintTarget(map, "app:layout_constraintLeft_toRightOf")
            val startToStart = getConstraintTarget(map, "app:layout_constraintStart_toStartOf")
            val startToEnd   = getConstraintTarget(map, "app:layout_constraintStart_toEndOf")

            val leftTarget: Float? = when {
                leftToLeft  == "parent" || startToStart == "parent" -> clLeft
                leftToRight == "parent" -> clRight
                startToEnd  == "parent" -> clRight
                leftToLeft  != null -> findViewRight(leftToLeft, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[0] - editorLoc[0]).toFloat()
                }
                leftToRight != null -> findViewRight(leftToRight, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[0] - editorLoc[0]).toFloat() + it.width
                }
                else -> null
            }

            // ── RIGHT constraints ─────────────────────────────────────────
            val rightToRight = getConstraintTarget(map, "app:layout_constraintRight_toRightOf")
            val rightToLeft  = getConstraintTarget(map, "app:layout_constraintRight_toLeftOf")
            val endToEnd   = getConstraintTarget(map, "app:layout_constraintEnd_toEndOf")
            val endToStart = getConstraintTarget(map, "app:layout_constraintEnd_toStartOf")

            val rightTarget: Float? = when {
                rightToRight == "parent" || endToEnd == "parent" -> clRight
                rightToLeft  == "parent" -> clLeft
                endToStart   == "parent" -> clLeft
                rightToRight != null -> findViewRight(rightToRight, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[0] - editorLoc[0]).toFloat() + it.width
                }
                rightToLeft != null -> findViewRight(rightToLeft, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[0] - editorLoc[0]).toFloat()
                }
                else -> null
            }

            // ── TOP constraints ───────────────────────────────────────────
            val topToTop    = getConstraintTarget(map, "app:layout_constraintTop_toTopOf")
            val topToBottom = getConstraintTarget(map, "app:layout_constraintTop_toBottomOf")

            val topTarget: Float? = when {
                topToTop    == "parent" -> clTop
                topToBottom == "parent" -> clBottom
                topToTop    != null -> findViewRight(topToTop, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[1] - editorLoc[1]).toFloat()
                }
                topToBottom != null -> findViewRight(topToBottom, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[1] - editorLoc[1]).toFloat() + it.height
                }
                else -> null
            }

            // ── BOTTOM constraints ────────────────────────────────────────
            val bottomToBottom = getConstraintTarget(map, "app:layout_constraintBottom_toBottomOf")
            val bottomToTop    = getConstraintTarget(map, "app:layout_constraintBottom_toTopOf")

            val bottomTarget: Float? = when {
                bottomToBottom == "parent" -> clBottom
                bottomToTop    == "parent" -> clTop
                bottomToBottom != null -> findViewRight(bottomToBottom, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[1] - editorLoc[1]).toFloat() + it.height
                }
                bottomToTop != null -> findViewRight(bottomToTop, constraintLayout)?.let {
                    val loc = IntArray(2); it.getLocationOnScreen(loc)
                    (loc[1] - editorLoc[1]).toFloat()
                }
                else -> null
            }

            // ── BASELINE constraint ───────────────────────────────────────
            val baselineOf = getConstraintTarget(map, "app:layout_constraintBaseline_toBaselineOf")
            if (baselineOf != null) {
                val baselineY = cT + child.baseline
                val targetX: Float = if (baselineOf == "parent") clLeft else {
                    findViewRight(baselineOf, constraintLayout)?.let {
                        val loc = IntArray(2); it.getLocationOnScreen(loc)
                        (loc[0] - editorLoc[0]).toFloat()
                    } ?: clLeft
                }
                canvas.drawLine(cL, baselineY, targetX, baselineY, constraintLinePaint)
                canvas.drawCircle(cL, baselineY, dotRadius, anchorDotPaint)
            }

            // ── Draw LEFT line (spring or bezier) ─────────────────────────
            if (leftTarget != null) {
                if (widthIsSpring && rightTarget != null) {
                    drawSpring(canvas, leftTarget, cCY, cL, cCY)
                } else {
                    drawCurvedLine(canvas, cL, cCY, leftTarget, cCY, true)
                }
                canvas.drawCircle(cL, cCY, dotRadius, anchorDotPaint)
            }

            // ── Draw RIGHT line (spring or bezier) ────────────────────────
            if (rightTarget != null) {
                if (widthIsSpring && leftTarget != null) {
                    drawSpring(canvas, cR, cCY, rightTarget, cCY)
                } else {
                    drawCurvedLine(canvas, cR, cCY, rightTarget, cCY, true)
                }
                canvas.drawCircle(cR, cCY, dotRadius, anchorDotPaint)
            }

            // ── Draw TOP line (spring or bezier) ──────────────────────────
            if (topTarget != null) {
                if (heightIsSpring && bottomTarget != null) {
                    drawSpring(canvas, cCX, topTarget, cCX, cT)
                } else {
                    drawCurvedLine(canvas, cCX, cT, cCX, topTarget, false)
                }
                canvas.drawCircle(cCX, cT, dotRadius, anchorDotPaint)
            }

            // ── Draw BOTTOM line (spring or bezier) ───────────────────────
            if (bottomTarget != null) {
                if (heightIsSpring && topTarget != null) {
                    drawSpring(canvas, cCX, cB, cCX, bottomTarget)
                } else {
                    drawCurvedLine(canvas, cCX, cB, cCX, bottomTarget, false)
                }
                canvas.drawCircle(cCX, cB, dotRadius, anchorDotPaint)
            }
        }
    }

    /**
     * Returns the constraint target value string from [map] for the given [attrKey],
     * stripping the `@id/` / `@+id/` prefix so callers get just `"parent"` or the ID name.
     */
    private fun getConstraintTarget(map: AttributeMap, attrKey: String): String? {
        if (!map.contains(attrKey)) return null
        val raw = map.getValue(attrKey)
        return raw.removePrefix("@+id/").removePrefix("@id/").ifEmpty { null }
    }

    /**
     * Finds the child [View] inside [layout] whose ID name (as tracked by [IdManager.idMap])
     * matches [idName].  Returns `null` if no match is found.
     */
    private fun findViewRight(idName: String, layout: androidx.constraintlayout.widget.ConstraintLayout): View? {
        val cleanName = idName.removePrefix("@+id/").removePrefix("@id/")
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            val childIdName = IdManager.idMap[child]
            if (childIdName == cleanName) return child
        }
        return null
    }

    /**
     * Draws a smooth cubic bezier curve between two points.
     * [horizontal] controls whether the control points are offset horizontally (left/right
     * constraints) or vertically (top/bottom constraints).
     */
    private fun drawCurvedLine(
        canvas: Canvas,
        x1: Float, y1: Float,
        x2: Float, y2: Float,
        horizontal: Boolean
    ) {
        val path = Path()
        path.moveTo(x1, y1)
        val ctrl = if (horizontal) {
            val dx = (x2 - x1) / 2f
            Pair(x1 + dx, y1) to Pair(x2 - dx, y2)
        } else {
            val dy = (y2 - y1) / 2f
            Pair(x1, y1 + dy) to Pair(x2, y2 - dy)
        }
        path.cubicTo(ctrl.first.first, ctrl.first.second, ctrl.second.first, ctrl.second.second, x2, y2)
        canvas.drawPath(path, constraintLinePaint)
    }

    /**
     * Draws a zigzag "spring" line between (x1,y1) and (x2,y2), exactly like Android Studio
     * shows for views with `match_constraint` (0dp) dimensions. The zigzag amplitude is
     * fixed at 5dp and each tooth is 6dp wide.
     */
    private fun drawSpring(
        canvas: Canvas,
        x1: Float, y1: Float,
        x2: Float, y2: Float
    ) {
        val amp   = Utils.pxToDp(context, 5).toFloat()
        val tooth = Utils.pxToDp(context, 6).toFloat()
        if (tooth <= 0f) return

        val horizontal = abs(x2 - x1) > abs(y2 - y1)
        val path = Path()
        path.moveTo(x1, y1)

        if (horizontal) {
            val length = x2 - x1
            if (abs(length) < 2 * tooth) {
                canvas.drawLine(x1, y1, x2, y2, springPaint)
                return
            }
            // Small straight lead-in
            path.lineTo(x1 + tooth, y1)
            var cur = x1 + tooth
            var up = true
            while (cur + tooth <= x2 - tooth) {
                path.lineTo(cur + tooth / 2f, y1 + if (up) -amp else amp)
                path.lineTo(cur + tooth, y1)
                cur += tooth
                up = !up
            }
            path.lineTo(x2, y2)
        } else {
            val length = y2 - y1
            if (abs(length) < 2 * tooth) {
                canvas.drawLine(x1, y1, x2, y2, springPaint)
                return
            }
            path.lineTo(x1, y1 + tooth)
            var cur = y1 + tooth
            var left = true
            while (cur + tooth <= y2 - tooth) {
                path.lineTo(x1 + if (left) -amp else amp, cur + tooth / 2f)
                path.lineTo(x1, cur + tooth)
                cur += tooth
                left = !left
            }
            path.lineTo(x2, y2)
        }
        canvas.drawPath(path, springPaint)
    }

    /**
     * Returns the [view]'s top-left corner in **this DesignEditor's coordinate space**,
     * using [View.getLocationOnScreen] so the values are always taken from the most recent
     * completed layout pass — never from a partially-laid-out frame.
     *
     * Falls back to the walk-up-the-tree approach when the screen location is not yet
     * available (i.e. before the first layout pass completes).
     */
    private fun getOffsetFromRoot(view: View): IntArray {
        val editorLoc = IntArray(2)
        val childLoc  = IntArray(2)
        this.getLocationOnScreen(editorLoc)
        view.getLocationOnScreen(childLoc)
        // If both are (0,0) the view hasn't been laid out yet — fall back to walk-up
        if (editorLoc[0] == 0 && editorLoc[1] == 0 && childLoc[0] == 0 && childLoc[1] == 0) {
            var x = 0; var y = 0; var current: View = view
            while (current !== this) {
                x += current.left; y += current.top
                val p = current.parent; if (p !is View) break; current = p
            }
            return intArrayOf(x, y)
        }
        return intArrayOf(childLoc[0] - editorLoc[0], childLoc[1] - editorLoc[1])
    }

    fun previewLayout(deviceConfiguration: DeviceConfiguration?, apiLevel: APILevel?) {
        this.deviceConfiguration = deviceConfiguration
        this.apiLevel = apiLevel
    }

    /**
     * After every layout pass all child positions are final — invalidate so
     * [drawConstraintLines] redraws with settled coordinates instead of the
     * stale values that were present during the *previous* draw pass.
     */
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        invalidate()
    }

    fun resizeLayout(deviceConfiguration: DeviceConfiguration?) {
        this.deviceConfiguration = deviceConfiguration
        invalidate()
    }

    private fun setTransition(group: ViewGroup) {
        if (group is RecyclerView) return
        LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
            enableTransitionType(LayoutTransition.CHANGING)
            setDuration(150)
        }.also { group.layoutTransition = it }
    }

    private fun toggleStrokeWidgets() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                method.invoke(view, isShowStroke)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setBlueprintOnChildren() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                method.invoke(view, isBlueprint)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setDragListener(group: ViewGroup) {
        group.setOnDragListener(
            OnDragListener { host, event ->
                var parent = host as ViewGroup
                val draggedView =
                    if (event.localState is View) event.localState as View else null

                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED -> {
                        if (isEnableVibration) VibrateUtils.vibrate(100)
                        if ((draggedView != null
                                    && !(draggedView is AdapterView<*> && parent is AdapterView<*>))
                        ) parent.removeView(draggedView)
                    }

                    DragEvent.ACTION_DRAG_EXITED -> {
                        removeWidget(shadow)
                        updateUndoRedoHistory()
                        clearAlignmentGuides()
                    }

                    DragEvent.ACTION_DRAG_ENDED -> {
                        clearAlignmentGuides()
                        if (!event.result && draggedView != null) {
                            removeId(draggedView, draggedView is ViewGroup)
                            removeViewAttributes(draggedView)
                            viewAttributeMap.remove(draggedView)
                            updateStructure()
                        }
                    }

                    DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_ENTERED -> if (shadow.parent == null) addWidget(
                        shadow,
                        parent,
                        event
                    )
                    else {
                        if (parent is LinearLayout) {
                            val index = parent.indexOfChild(shadow)
                            val newIndex = getIndexForNewChildOfLinear(parent, event)

                            if (index != newIndex) {
                                parent.removeView(shadow)
                                try {
                                    parent.addView(shadow, newIndex)
                                } catch (_: IllegalStateException) {
                                }
                            }
                        } else {
                            if (shadow.parent !== parent) addWidget(shadow, parent, event)
                        }
                        updateAlignmentGuides(parent)
                    }

                    DragEvent.ACTION_DROP -> {
                        clearAlignmentGuides()
                        removeWidget(shadow)
                        if (childCount >= 1) {
                            if (getChildAt(0) !is ViewGroup) {
                                Toast.makeText(
                                    context,
                                    "Can\'t add more than one widget in the editor.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@OnDragListener true
                            } else {
                                if (parent is DesignEditor) parent = getChildAt(0) as ViewGroup
                            }
                        }
                        if (draggedView == null) {
                            @Suppress("UNCHECKED_CAST")
                            val data = event.localState as HashMap<String, Any>
                            val newView =
                                InvokeUtil.createView(
                                    data[Constants.KEY_CLASS_NAME].toString(), context
                                ) as View

                            newView.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            )
                            rearrangeListeners(newView)

                            if (newView is ViewGroup) {
                                setDragListener(newView)
                                setTransition(newView)
                            }
                            newView.minimumWidth = Utils.pxToDp(context, 20)
                            newView.minimumHeight = Utils.pxToDp(context, 20)

                            if (newView is EditText) newView.isFocusable = false

                            val map = AttributeMap()
                            val id = getIdForNewView(
                                newView.javaClass.superclass.simpleName
                                    .replace(" ".toRegex(), "_")
                                    .lowercase()
                            )
                            IdManager.addNewId(newView, id)
                            map.putValue("android:id", "@+id/$id")
                            map.putValue("android:layout_width", "wrap_content")
                            map.putValue("android:layout_height", "wrap_content")
                            viewAttributeMap[newView] = map

                            addWidget(newView, parent, event)

                            try {
                                val cls: Class<*> = newView.javaClass
                                val setStrokeEnabled =
                                    cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                                val setBlueprint = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                                setStrokeEnabled.invoke(newView, isShowStroke)
                                setBlueprint.invoke(newView, isBlueprint)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            if (data.containsKey(Constants.KEY_DEFAULT_ATTRS)) {
                                @Suppress("UNCHECKED_CAST")
                                initializer.applyDefaultAttributes(
                                    newView, data[Constants.KEY_DEFAULT_ATTRS] as MutableMap<String, String>
                                )
                            }
                        } else addWidget(draggedView, parent, event)
                        updateStructure()
                        updateUndoRedoHistory()
                    }
                }
                true
            })
    }

    private fun getIdForNewView(name: String): String {
        var id = name
        var n = 0
        var firstTime = true
        while (IdManager.containsId(id)) {
            n++
            id = if (firstTime) "$name$n" else id.replace(
                id.elementAt(id.lastIndex).toString().toRegex(), n.toString()
            )
            firstTime = false
        }
        return id
    }

    fun loadLayoutFromParser(xml: String) {
        clearAll()

        if (xml.isEmpty()) return

        val parser = XmlLayoutParser(context)
        parser.parseFromXml(xml, context)

        addView(parser.root)
        viewAttributeMap = parser.viewAttributeMap

        for (view in (viewAttributeMap as HashMap<View, *>?)!!.keys) {
            rearrangeListeners(view)

            if (view is ViewGroup) {
                setDragListener(view)
                setTransition(view)
            }
            view.minimumWidth = Utils.pxToDp(context, 20)
            view.minimumHeight = Utils.pxToDp(context, 20)
        }

        updateStructure()
        toggleStrokeWidgets()

        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    fun undo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isUndoEnabled) loadLayoutFromParser(undoRedoManager!!.undo())
    }

    fun redo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isRedoEnabled) loadLayoutFromParser(undoRedoManager!!.redo())
    }

    private fun clearAll() {
        removeAllViews()
        structureView!!.clear()
        viewAttributeMap.clear()
    }

    fun setStructureView(view: StructureView?) {
        structureView = view
    }

    fun bindUndoRedoManager(manager: UndoRedoManager?) {
        undoRedoManager = manager
    }

    private fun updateStructure() {
        if (this.isEmpty()) structureView!!.clear()
        else structureView!!.setView(getChildAt(0))
    }

    fun updateUndoRedoHistory() {
        if (undoRedoManager == null) return
        val result = XmlLayoutGenerator().generate(this, false)
        undoRedoManager!!.addToHistory(result)
    }

    private fun rearrangeListeners(view: View) {
        val gestureDetector =
            GestureDetector(
                context,
                object : SimpleOnGestureListener() {
                    override fun onLongPress(event: MotionEvent) {
                        view.startDragAndDrop(null, DragShadowBuilder(view), view, 0)
                    }
                })

        view.setOnTouchListener(
            object : OnTouchListener {
                var bClick: Boolean = true
                var startX: Float = 0f
                var startY: Float = 0f
                var endX: Float = 0f
                var endY: Float = 0f
                var diffX: Float = 0f
                var diffY: Float = 0f

                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.x
                            startY = event.y
                            bClick = true
                        }

                        MotionEvent.ACTION_UP -> {
                            endX = event.x
                            endY = event.y
                            diffX = abs((startX - endX).toDouble()).toFloat()
                            diffY = abs((startY - endY).toDouble()).toFloat()

                            if ((diffX <= 5) && (diffY <= 5) && bClick) showDefinedAttributes(v)

                            bClick = false
                        }
                    }
                    gestureDetector.onTouchEvent(event)
                    return true
                }
            })
    }

    private fun addWidget(view: View, newParent: ViewGroup, event: DragEvent) {
        removeWidget(view)
        if (newParent is LinearLayout) {
            val index = getIndexForNewChildOfLinear(newParent, event)
            newParent.addView(view, index)
        } else {
            try {
                newParent.addView(view, newParent.childCount)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun removeWidget(view: View) {
        (view.parent as ViewGroup?)?.removeView(view)
    }

    private fun getIndexForNewChildOfLinear(layout: LinearLayout, event: DragEvent): Int {
        val orientation = layout.orientation
        if (orientation == HORIZONTAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.right < event.x) index++
            }
            return index
        }
        if (orientation == VERTICAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.bottom < event.y) index++
            }
            return index
        }
        return -1
    }

    fun showDefinedAttributes(target: View) {
        val keys = viewAttributeMap[target]!!.keySet()
        val values = viewAttributeMap[target]!!.values()

        val attrs: MutableList<HashMap<String, Any>> = ArrayList()
        val allAttrs = initializer.getAllAttributesForView(target)

        val dialog = BottomSheetDialog(context)
        val binding =
            ShowAttributesDialogBinding.inflate(dialog.layoutInflater)

        dialog.setContentView(binding.root)
        TooltipCompat.setTooltipText(binding.btnAdd, "Add attribute")
        TooltipCompat.setTooltipText(binding.btnDelete, "Delete")

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        val appliedAttributesAdapter = AppliedAttributesAdapter(attrs, values)

        appliedAttributesAdapter.onClick = {
            showAttributeEdit(target, keys[it])
            dialog.dismiss()
        }

        appliedAttributesAdapter.onRemoveButtonClick = {
            dialog.dismiss()

            val view = removeAttribute(target, keys[it])
            showDefinedAttributes(view)
        }

        binding.attributesList.adapter = appliedAttributesAdapter
        binding.attributesList.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.viewName.text = target.javaClass.superclass.simpleName
        binding.viewFullName.text = target.javaClass.superclass.name
        binding.btnAdd.setOnClickListener {
            showAvailableAttributes(target)
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            MaterialAlertDialogBuilder(context)
                .setTitle(R.string.delete_view)
                .setMessage(R.string.msg_delete_view)
                .setNegativeButton(
                    R.string.no
                ) { d, _ ->
                    d.dismiss()
                }
                .setPositiveButton(
                    R.string.yes
                ) { _, _ ->
                    removeId(target, target is ViewGroup)
                    removeViewAttributes(target)
                    removeWidget(target)
                    updateStructure()
                    updateUndoRedoHistory()
                    dialog.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun showAvailableAttributes(target: View) {
        val availableAttrs =
            initializer.getAvailableAttributesForView(target)
        val names: MutableList<String> = ArrayList()

        for (attr: HashMap<String, Any> in availableAttrs) {
            names.add(attr["name"].toString())
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Available attributes")
            .setAdapter(
                ArrayAdapter(context, android.R.layout.simple_list_item_1, names)
            ) { _, w ->
                /*
                          if (getChildAt(0) instanceof ConstraintLayout) {
                            final List<String> keys = VIEW_ATTRIBUTE_MAP.get(target).keySet();

                            final List<HashMap<String, Object>> attrs = new ArrayList<>();
                            final List<HashMap<String, Object>> allAttrs =
                                INITIALIZER.getAllAttributesForView(target);

                            for (String key : keys) {
                              for (HashMap<String, Object> map : allAttrs) {
                                if (map.get(Constants.KEY_ATTRIBUTE_NAME).toString().equals(key)) {
                                  attrs.add(map);
                                  break;
                                }
                              }
                            }

                            for(HashMap<String, Object> attr : attrs) {

                            }
                          }
                    */
                showAttributeEdit(
                    target, availableAttrs[w][Constants.KEY_ATTRIBUTE_NAME].toString()
                )
            }
            .show()
    }

    private fun showAttributeEdit(target: View, attributeKey: String) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        val argumentTypes =
            currentAttr?.get(Constants.KEY_ARGUMENT_TYPE)?.toString()?.split("\\|".toRegex())
                ?.dropLastWhile { it.isEmpty() }
                ?.toTypedArray()

        if (argumentTypes != null) {
            if (argumentTypes.size > 1) {
                if (attributeMap!!.contains(attributeKey)) {
                    val argumentType =
                        parseType(attributeMap.getValue(attributeKey), argumentTypes)
                    showAttributeEdit(target, attributeKey, argumentType)
                    return
                }
                MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.select_arg_type)
                    .setAdapter(
                        ArrayAdapter(
                            context, android.R.layout.simple_list_item_1, argumentTypes
                        )
                    ) { _, w ->
                        showAttributeEdit(target, attributeKey, argumentTypes[w])
                    }
                    .show()

                return
            }
        }
        showAttributeEdit(target, attributeKey, argumentTypes?.get(0))
    }

    @Suppress("UNCHECKED_CAST")
    private fun showAttributeEdit(
        target: View, attributeKey: String, argumentType: String?
    ) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        var savedValue =
            if (attributeMap!!.contains(attributeKey)) attributeMap.getValue(attributeKey) else ""
        val defaultValue =
            if (currentAttr?.containsKey(Constants.KEY_DEFAULT_VALUE) == true)
                currentAttr[Constants.KEY_DEFAULT_VALUE].toString()
            else null
        val constant =
            if (currentAttr?.containsKey(Constants.KEY_CONSTANT) == true
            ) currentAttr[Constants.KEY_CONSTANT].toString()
            else null

        val context = context

        var dialog: AttributeDialog? = null

        when (argumentType) {
            Constants.ARGUMENT_TYPE_SIZE -> dialog = SizeDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DIMENSION -> dialog =
                DimensionDialog(context, savedValue, currentAttr?.get("dimensionUnit")?.toString())

            Constants.ARGUMENT_TYPE_ID -> dialog = IdDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_VIEW -> dialog = ViewDialog(context, savedValue, constant)
            Constants.ARGUMENT_TYPE_BOOLEAN -> dialog = BooleanDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DRAWABLE -> {
                if (savedValue.startsWith("@drawable/")) {
                    savedValue = savedValue.replace("@drawable/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_DRAWABLE)
            }

            Constants.ARGUMENT_TYPE_STRING -> {
                if (savedValue.startsWith("@string/")) {
                    savedValue = savedValue.replace("@string/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_STRING)
            }

            Constants.ARGUMENT_TYPE_TEXT -> dialog =
                StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_TEXT)

            Constants.ARGUMENT_TYPE_INT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_INT)

            Constants.ARGUMENT_TYPE_FLOAT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_FLOAT)

            Constants.ARGUMENT_TYPE_FLAG -> dialog =
                FlagDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_ENUM -> dialog =
                EnumDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_COLOR -> dialog = ColorDialog(context, savedValue)
        }
        if (dialog == null) return

        dialog.setTitle(currentAttr?.get("name")?.toString())
        dialog.setOnSaveValueListener {
            if (defaultValue != null && (defaultValue == it)) {
                if (attributeMap.contains(attributeKey)) removeAttribute(target, attributeKey)
            } else {
                if (currentAttr != null) {
                    initializer.applyAttribute(target, it!!, currentAttr)
                }
                showDefinedAttributes(target)
                updateUndoRedoHistory()
                updateStructure()
                invalidate() // redraw constraint lines after attribute change
            }
        }

        dialog.show()
    }

    private fun removeViewAttributes(view: View) {
        viewAttributeMap.remove(view)
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                removeViewAttributes(view.getChildAt(i))
            }
        }
    }

    private fun removeAttribute(target: View, attributeKey: String): View {
        @Suppress("NAME_SHADOWING")
        var target = target
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)

        val attributeMap = viewAttributeMap[target]

        if (currentAttr != null) {
            if (currentAttr.containsKey(Constants.KEY_CAN_DELETE)) return target
        }

        val name =
            if (attributeMap!!.contains("android:id")) attributeMap.getValue("android:id") else null
        val id = if (name != null) getViewId(name.replace("@+id/", "")) else -1
        attributeMap.removeValue(attributeKey)

        if ((attributeKey == "android:id")) {
            removeId(target, false)
            target.id = -1
            target.requestLayout()

            // delete all id attributes for views
            for (view: View in viewAttributeMap.keys) {
                val map = viewAttributeMap[view]

                for (key: String in map!!.keySet()) {
                    val value = map.getValue(key)

                    if (value.startsWith("@id/") && (value == name!!.replace("+", ""))) map.removeValue(key)
                }
            }
            updateStructure()
            return target
        }

        viewAttributeMap.remove(target)

        val parent = target.parent as ViewGroup
        val indexOfView = parent.indexOfChild(target)

        parent.removeView(target)

        val childs: MutableList<View> = ArrayList()

        if (target is ViewGroup) {
            val group = target

            if (group.childCount > 0) {
                for (i in 0 until group.childCount) {
                    childs.add(group.getChildAt(i))
                }
            }

            group.removeAllViews()
        }

        if (name != null) removeId(target, false)

        target = InvokeUtil.createView(target.javaClass.name, context) as View
        rearrangeListeners(target)

        if (target is ViewGroup) {
            target.setMinimumWidth(Utils.pxToDp(context, 20))
            target.setMinimumHeight(Utils.pxToDp(context, 20))
            val group = target
            if (childs.size > 0) {
                for (i in childs.indices) {
                    group.addView(childs[i])
                }
            }
            setTransition(group)
        }

        parent.addView(target, indexOfView)
        viewAttributeMap[target] = attributeMap

        if (name != null) {
            addId(target, name, id)
            target.requestLayout()
        }

        val keys = attributeMap.keySet()
        val values = attributeMap.values()
        val attrs: MutableList<HashMap<String, Any>> = ArrayList()

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        for (i in keys.indices) {
            val key = keys[i]
            if ((key == "android:id")) continue
            initializer.applyAttribute(target, values[i], attrs[i])
        }

        try {
            val cls: Class<*> = target.javaClass
            val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
            method.invoke(target, isShowStroke)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        updateStructure()
        updateUndoRedoHistory()
        return target
    }

    private fun initAttributes() {
        attributes = convertJsonToJavaObject(Constants.ATTRIBUTES_FILE)
        parentAttributes = convertJsonToJavaObject(Constants.PARENT_ATTRIBUTES_FILE)
        viewAttributeMap = HashMap()
        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    private fun convertJsonToJavaObject(filePath: String): HashMap<String, List<HashMap<String, Any>>> {
        return Gson()
            .fromJson(
                FileUtil.readFromAsset(filePath, context),
                object : TypeToken<HashMap<String?, ArrayList<HashMap<String?, Any?>?>?>?>() {}.type
            )
    }

    enum class ViewType {
        DESIGN,
        BLUEPRINT
    }
}
