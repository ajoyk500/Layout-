package com.itsvks.layouteditor.editor

import android.animation.LayoutTransition
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.DragEvent
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.View
import android.view.View.OnDragListener
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.widget.TooltipCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.VibrateUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.adapters.AppliedAttributesAdapter
import com.itsvks.layouteditor.databinding.ShowAttributesDialogBinding
import com.itsvks.layouteditor.editor.dialogs.AttributeDialog
import com.itsvks.layouteditor.editor.dialogs.BooleanDialog
import com.itsvks.layouteditor.editor.dialogs.ColorDialog
import com.itsvks.layouteditor.editor.dialogs.DimensionDialog
import com.itsvks.layouteditor.editor.dialogs.EnumDialog
import com.itsvks.layouteditor.editor.dialogs.FlagDialog
import com.itsvks.layouteditor.editor.dialogs.IdDialog
import com.itsvks.layouteditor.editor.dialogs.NumberDialog
import com.itsvks.layouteditor.editor.dialogs.SizeDialog
import com.itsvks.layouteditor.editor.dialogs.StringDialog
import com.itsvks.layouteditor.editor.dialogs.ViewDialog
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager
import com.itsvks.layouteditor.managers.IdManager.addId
import com.itsvks.layouteditor.managers.IdManager.getViewId
import com.itsvks.layouteditor.managers.IdManager.removeId
import com.itsvks.layouteditor.managers.PreferencesManager
import com.itsvks.layouteditor.managers.PreferencesManager.isEnableVibration
import com.itsvks.layouteditor.managers.PreferencesManager.isShowStroke
import com.itsvks.layouteditor.managers.UndoRedoManager
import com.itsvks.layouteditor.tools.XmlLayoutGenerator
import com.itsvks.layouteditor.tools.XmlLayoutParser
import com.itsvks.layouteditor.utils.ArgumentUtil.parseType
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil
import com.itsvks.layouteditor.utils.Utils
import com.itsvks.layouteditor.views.StructureView
import kotlin.math.abs
import androidx.core.view.isEmpty

class DesignEditor : LinearLayout {
    var viewType: ViewType? = null
        set(value) {
            isBlueprint = viewType == ViewType.BLUEPRINT
            setBlueprintOnChildren()
            invalidate()
            field = value
        }
    var deviceConfiguration: DeviceConfiguration? = null
    var apiLevel: APILevel? = null

    lateinit var viewAttributeMap: HashMap<View, AttributeMap>
        private set

    private lateinit var paint: Paint
    private lateinit var shadow: View

    private lateinit var attributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var parentAttributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var initializer: AttributeInitializer

    private var isBlueprint = false
    private var structureView: StructureView? = null
    private var undoRedoManager: UndoRedoManager? = null

    // ----- Design tools: grid overlay & alignment guides -----

    /** Paint used to draw the grid overlay dots/lines on the canvas. */
    private lateinit var gridPaint: Paint

    /** Paint used to draw alignment guide lines while dragging a widget. */
    private lateinit var guidePaint: Paint

    /** Active alignment guide lines computed during the current drag, in editor-local coordinates. */
    private val alignmentGuides: MutableList<GuideLine> = ArrayList()

    /**
     * Represents a single alignment guide line drawn on top of the canvas while
     * dragging a widget. [vertical] lines run along the y-axis (used for horizontal
     * center/edge alignment), horizontal lines run along the x-axis.
     */
    private data class GuideLine(val vertical: Boolean, val position: Float)

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context)
    }

    private fun init(context: Context) {
        viewType = ViewType.DESIGN
        isBlueprint = false
        deviceConfiguration = DeviceConfiguration(DeviceSize.LARGE)
        initAttributes()
        shadow = View(context)
        paint = Paint()

        shadow.setBackgroundColor(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutline)
        )
        shadow.layoutParams = ViewGroup.LayoutParams(
            Utils.pxToDp(context, 50),
            Utils.pxToDp(context, 35)
        )
        paint.strokeWidth = Utils.pxToDp(context, 3).toFloat()

        gridPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            color = MaterialColors.getColor(
                this@DesignEditor, com.google.android.material.R.attr.colorOutlineVariant
            )
            alpha = 90
        }

        guidePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            color = Color.parseColor("#FF4081")
        }

        orientation = VERTICAL
        setTransition(this)
        setDragListener(this)

        toggleStrokeWidgets()
        setBlueprintOnChildren()
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        when (viewType) {
            ViewType.BLUEPRINT -> drawBlueprint(canvas)
            ViewType.DESIGN -> drawDesign(canvas)
            else -> drawDesign(canvas)
        }
        if (PreferencesManager.isShowGrid) drawGridOverlay(canvas)
        if (alignmentGuides.isNotEmpty()) drawAlignmentGuides(canvas)
        when (deviceConfiguration!!.size) {
            DeviceSize.SMALL -> {
                scaleX = 0.75f
                scaleY = 0.75f
            }

            DeviceSize.MEDIUM -> {
                scaleX = 0.85f
                scaleY = 0.85f
            }

            DeviceSize.LARGE -> {
                scaleX = 0.95f
                scaleY = 0.95f
            }
        }
    }

    /**
     * Draws a grid of evenly spaced lines across the editor canvas. The spacing is
     * controlled by [PreferencesManager.gridSize] (in dp) and is purely visual —
     * it helps the user align widgets by eye and serves as a reference for
     * snap-to-grid dimension values.
     */
    private fun drawGridOverlay(canvas: Canvas) {
        val gridSizePx = Utils.pxToDp(context, PreferencesManager.gridSize).toFloat()
        if (gridSizePx <= 0f) return

        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += gridSizePx
        }

        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += gridSizePx
        }
    }

    /**
     * Draws the alignment guide lines (center/edge snap indicators) that were
     * computed in [updateAlignmentGuides] while a widget is being dragged.
     */
    private fun drawAlignmentGuides(canvas: Canvas) {
        for (guide in alignmentGuides) {
            if (guide.vertical) {
                canvas.drawLine(guide.position, 0f, guide.position, height.toFloat(), guidePaint)
            } else {
                canvas.drawLine(0f, guide.position, width.toFloat(), guide.position, guidePaint)
            }
        }
    }


    private fun drawBlueprint(canvas: Canvas) {
        paint.color = Constants.BLUEPRINT_DASH_COLOR
        setBackgroundColor(Constants.BLUEPRINT_BACKGROUND_COLOR)
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    private fun drawDesign(canvas: Canvas) {
        paint.color = Constants.DESIGN_DASH_COLOR
        setBackgroundColor(Utils.getSurfaceColor(context))
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    fun previewLayout(deviceConfiguration: DeviceConfiguration?, apiLevel: APILevel?) {
        this.deviceConfiguration = deviceConfiguration
        this.apiLevel = apiLevel
    }

    fun resizeLayout(deviceConfiguration: DeviceConfiguration?) {
        this.deviceConfiguration = deviceConfiguration
        invalidate()
    }

    private fun setTransition(group: ViewGroup) {
        if (group is RecyclerView) return
        LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
            enableTransitionType(LayoutTransition.CHANGING)
            setDuration(150)
        }.also { group.layoutTransition = it }
    }

    private fun toggleStrokeWidgets() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                method.invoke(view, isShowStroke)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setBlueprintOnChildren() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                method.invoke(view, isBlueprint)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setDragListener(group: ViewGroup) {
        group.setOnDragListener(
            OnDragListener { host, event ->
                var parent = host as ViewGroup
                val draggedView =
                    if (event.localState is View) event.localState as View else null

                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED -> {
                        if (isEnableVibration) VibrateUtils.vibrate(100)
                        if ((draggedView != null
                                    && !(draggedView is AdapterView<*> && parent is AdapterView<*>))
                        ) parent.removeView(draggedView)
                    }

                    DragEvent.ACTION_DRAG_EXITED -> {
                        removeWidget(shadow)
                        clearAlignmentGuides()
                        updateUndoRedoHistory()
                    }

                    DragEvent.ACTION_DRAG_ENDED -> {
                        clearAlignmentGuides()
                        if (!event.result && draggedView != null) {
                            removeId(draggedView, draggedView is ViewGroup)
                            removeViewAttributes(draggedView)
                            viewAttributeMap.remove(draggedView)
                            updateStructure()
                        }
                    }

                    DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_ENTERED -> {
                        if (shadow.parent == null) addWidget(
                            shadow,
                            parent,
                            event
                        )
                        else {
                            if (parent is LinearLayout) {
                                val index = parent.indexOfChild(shadow)
                                val newIndex = getIndexForNewChildOfLinear(parent, event)

                                if (index != newIndex) {
                                    parent.removeView(shadow)
                                    try {
                                        parent.addView(shadow, newIndex)
                                    } catch (_: IllegalStateException) {
                                    }
                                }
                            } else {
                                if (shadow.parent !== parent) addWidget(shadow, parent, event)
                            }
                        }

                        if (PreferencesManager.isShowAlignmentGuides) {
                            updateAlignmentGuides(parent, event)
                        }
                    }

                    DragEvent.ACTION_DROP -> {
                        removeWidget(shadow)
                        clearAlignmentGuides()
                        if (childCount >= 1) {
                            if (getChildAt(0) !is ViewGroup) {
                                Toast.makeText(
                                    context,
                                    "Can\'t add more than one widget in the editor.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@OnDragListener true
                            } else {
                                if (parent is DesignEditor) parent = getChildAt(0) as ViewGroup
                            }
                        }
                        if (draggedView == null) {
                            @Suppress("UNCHECKED_CAST")
                            val data = event.localState as HashMap<String, Any>
                            val newView =
                                InvokeUtil.createView(
                                    data[Constants.KEY_CLASS_NAME].toString(), context
                                ) as View

                            newView.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            )
                            rearrangeListeners(newView)

                            if (newView is ViewGroup) {
                                setDragListener(newView)
                                setTransition(newView)
                            }
                            newView.minimumWidth = Utils.pxToDp(context, 20)
                            newView.minimumHeight = Utils.pxToDp(context, 20)

                            if (newView is EditText) newView.isFocusable = false

                            val map = AttributeMap()
                            val id = getIdForNewView(
                                newView.javaClass.superclass.simpleName
                                    .replace(" ".toRegex(), "_")
                                    .lowercase()
                            )
                            IdManager.addNewId(newView, id)
                            map.putValue("android:id", "@+id/$id")
                            map.putValue("android:layout_width", "wrap_content")
                            map.putValue("android:layout_height", "wrap_content")
                            viewAttributeMap[newView] = map

                            addWidget(newView, parent, event)

                            try {
                                val cls: Class<*> = newView.javaClass
                                val setStrokeEnabled =
                                    cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                                val setBlueprint = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                                setStrokeEnabled.invoke(newView, isShowStroke)
                                setBlueprint.invoke(newView, isBlueprint)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            if (data.containsKey(Constants.KEY_DEFAULT_ATTRS)) {
                                @Suppress("UNCHECKED_CAST")
                                initializer.applyDefaultAttributes(
                                    newView, data[Constants.KEY_DEFAULT_ATTRS] as MutableMap<String, String>
                                )
                            }
                        } else addWidget(draggedView, parent, event)
                        updateStructure()
                        updateUndoRedoHistory()
                    }
                }
                true
            })
    }

    private fun getIdForNewView(name: String): String {
        var id = name
        var n = 0
        var firstTime = true
        while (IdManager.containsId(id)) {
            n++
            id = if (firstTime) "$name$n" else id.replace(
                id.elementAt(id.lastIndex).toString().toRegex(), n.toString()
            )
            firstTime = false
        }
        return id
    }

    fun loadLayoutFromParser(xml: String) {
        clearAll()

        if (xml.isEmpty()) return

        val parser = XmlLayoutParser(context)
        parser.parseFromXml(xml, context)

        addView(parser.root)
        viewAttributeMap = parser.viewAttributeMap

        for (view in (viewAttributeMap as HashMap<View, *>?)!!.keys) {
            rearrangeListeners(view)

            if (view is ViewGroup) {
                setDragListener(view)
                setTransition(view)
            }
            view.minimumWidth = Utils.pxToDp(context, 20)
            view.minimumHeight = Utils.pxToDp(context, 20)
        }

        updateStructure()
        toggleStrokeWidgets()

        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    fun undo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isUndoEnabled) loadLayoutFromParser(undoRedoManager!!.undo())
    }

    fun redo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isRedoEnabled) loadLayoutFromParser(undoRedoManager!!.redo())
    }

    private fun clearAll() {
        removeAllViews()
        structureView!!.clear()
        viewAttributeMap.clear()
    }

    fun setStructureView(view: StructureView?) {
        structureView = view
    }

    fun bindUndoRedoManager(manager: UndoRedoManager?) {
        undoRedoManager = manager
    }

    private fun updateStructure() {
        if (this.isEmpty()) structureView!!.clear()
        else structureView!!.setView(getChildAt(0))
    }

    fun updateUndoRedoHistory() {
        if (undoRedoManager == null) return
        val result = XmlLayoutGenerator().generate(this, false)
        undoRedoManager!!.addToHistory(result)
    }

    private fun rearrangeListeners(view: View) {
        val gestureDetector =
            GestureDetector(
                context,
                object : SimpleOnGestureListener() {
                    override fun onLongPress(event: MotionEvent) {
                        view.startDragAndDrop(null, DragShadowBuilder(view), view, 0)
                    }
                })

        view.setOnTouchListener(
            object : OnTouchListener {
                var bClick: Boolean = true
                var startX: Float = 0f
                var startY: Float = 0f
                var endX: Float = 0f
                var endY: Float = 0f
                var diffX: Float = 0f
                var diffY: Float = 0f

                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.x
                            startY = event.y
                            bClick = true
                        }

                        MotionEvent.ACTION_UP -> {
                            endX = event.x
                            endY = event.y
                            diffX = abs((startX - endX).toDouble()).toFloat()
                            diffY = abs((startY - endY).toDouble()).toFloat()

                            if ((diffX <= 5) && (diffY <= 5) && bClick) showDefinedAttributes(v)

                            bClick = false
                        }
                    }
                    gestureDetector.onTouchEvent(event)
                    return true
                }
            })
    }

    private fun addWidget(view: View, newParent: ViewGroup, event: DragEvent) {
        removeWidget(view)
        if (newParent is LinearLayout) {
            val index = getIndexForNewChildOfLinear(newParent, event)
            newParent.addView(view, index)
        } else {
            try {
                newParent.addView(view, newParent.childCount)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun removeWidget(view: View) {
        (view.parent as ViewGroup?)?.removeView(view)
    }

    private fun getIndexForNewChildOfLinear(layout: LinearLayout, event: DragEvent): Int {
        val orientation = layout.orientation
        if (orientation == HORIZONTAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.right < event.x) index++
            }
            return index
        }
        if (orientation == VERTICAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.bottom < event.y) index++
            }
            return index
        }
        return -1
    }

    /**
     * Removes any active alignment guide lines and triggers a redraw. Called
     * whenever a drag operation leaves the canvas, ends, or completes.
     */
    private fun clearAlignmentGuides() {
        if (alignmentGuides.isEmpty()) return
        alignmentGuides.clear()
        invalidate()
    }

    /**
     * Computes alignment guide lines for the widget currently being dragged.
     *
     * While the user drags a widget over [parent], this checks the predicted
     * bounds of the dragged widget (using the [shadow] placeholder's current
     * size at the drag location) against the bounds of its sibling views.
     * When the dragged widget's center or edges line up closely with a
     * sibling's center or edges (within [ALIGNMENT_TOLERANCE_DP]), a guide
     * line is recorded so [drawAlignmentGuides] can render it on top of the
     * canvas, helping the user align widgets precisely.
     *
     * All coordinates are converted into this [DesignEditor]'s local
     * coordinate space, since [parent] may be a nested layout.
     */
    private fun updateAlignmentGuides(parent: ViewGroup, event: DragEvent) {
        val newGuides = ArrayList<GuideLine>()

        // Offset of `parent` relative to this editor view, so we can draw guides
        // that span the whole editor canvas regardless of nesting depth.
        val parentOffset = getOffsetFrom(parent)

        // Predicted bounds of the dragged widget within `parent`, using the
        // shadow placeholder's current size as a stand-in for the dragged view.
        val shadowWidth = if (shadow.width > 0) shadow.width else shadow.layoutParams?.width ?: 0
        val shadowHeight = if (shadow.height > 0) shadow.height else shadow.layoutParams?.height ?: 0

        val draggedLeft = event.x - shadowWidth / 2f
        val draggedTop = event.y - shadowHeight / 2f
        val draggedRight = draggedLeft + shadowWidth
        val draggedBottom = draggedTop + shadowHeight
        val draggedCenterX = (draggedLeft + draggedRight) / 2f
        val draggedCenterY = (draggedTop + draggedBottom) / 2f

        val tolerance = Utils.pxToDp(context, ALIGNMENT_TOLERANCE_DP).toFloat()

        for (i in 0 until parent.childCount) {
            val sibling = parent.getChildAt(i)
            if (sibling === shadow) continue

            val siblingLeft = sibling.left.toFloat()
            val siblingTop = sibling.top.toFloat()
            val siblingRight = sibling.right.toFloat()
            val siblingBottom = sibling.bottom.toFloat()
            val siblingCenterX = (siblingLeft + siblingRight) / 2f
            val siblingCenterY = (siblingTop + siblingBottom) / 2f

            // Vertical guide lines (compare x positions)
            addGuideIfClose(newGuides, true, draggedLeft, siblingLeft, tolerance, parentOffset.first)
            addGuideIfClose(newGuides, true, draggedRight, siblingRight, tolerance, parentOffset.first)
            addGuideIfClose(newGuides, true, draggedCenterX, siblingCenterX, tolerance, parentOffset.first)

            // Horizontal guide lines (compare y positions)
            addGuideIfClose(newGuides, false, draggedTop, siblingTop, tolerance, parentOffset.second)
            addGuideIfClose(newGuides, false, draggedBottom, siblingBottom, tolerance, parentOffset.second)
            addGuideIfClose(newGuides, false, draggedCenterY, siblingCenterY, tolerance, parentOffset.second)
        }

        if (newGuides != alignmentGuides) {
            alignmentGuides.clear()
            alignmentGuides.addAll(newGuides)
            invalidate()
        }
    }

    /**
     * If [draggedValue] is within [tolerance] of [siblingValue], adds a [GuideLine]
     * at the sibling's position (translated into this editor's coordinate space
     * via [offset]) to [guides].
     */
    private fun addGuideIfClose(
        guides: MutableList<GuideLine>,
        vertical: Boolean,
        draggedValue: Float,
        siblingValue: Float,
        tolerance: Float,
        offset: Float
    ) {
        if (abs(draggedValue - siblingValue) <= tolerance) {
            guides.add(GuideLine(vertical, siblingValue + offset))
        }
    }

    /**
     * Returns the (x, y) offset of [view] relative to this [DesignEditor], so that
     * coordinates local to a nested layout can be translated into this editor's
     * coordinate space for drawing guide lines that span the whole canvas.
     */
    private fun getOffsetFrom(view: View): Pair<Float, Float> {
        if (view === this) return 0f to 0f

        var dx = 0f
        var dy = 0f
        var current: View? = view
        while (current != null && current !== this) {
            dx += current.left.toFloat()
            dy += current.top.toFloat()
            current = current.parent as? View
        }
        return dx to dy
    }

    fun showDefinedAttributes(target: View) {
        val keys = viewAttributeMap[target]!!.keySet()
        val values = viewAttributeMap[target]!!.values()

        val attrs: MutableList<HashMap<String, Any>> = ArrayList()
        val allAttrs = initializer.getAllAttributesForView(target)

        val dialog = BottomSheetDialog(context)
        val binding =
            ShowAttributesDialogBinding.inflate(dialog.layoutInflater)

        dialog.setContentView(binding.root)
        TooltipCompat.setTooltipText(binding.btnAdd, "Add attribute")
        TooltipCompat.setTooltipText(binding.btnDelete, "Delete")

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        val appliedAttributesAdapter = AppliedAttributesAdapter(attrs, values)

        appliedAttributesAdapter.onClick = {
            showAttributeEdit(target, keys[it])
            dialog.dismiss()
        }

        appliedAttributesAdapter.onRemoveButtonClick = {
            dialog.dismiss()

            val view = removeAttribute(target, keys[it])
            showDefinedAttributes(view)
        }

        binding.attributesList.adapter = appliedAttributesAdapter
        binding.attributesList.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.viewName.text = target.javaClass.superclass.simpleName
        binding.viewFullName.text = target.javaClass.superclass.name
        binding.btnAdd.setOnClickListener {
            showAvailableAttributes(target)
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            MaterialAlertDialogBuilder(context)
                .setTitle(R.string.delete_view)
                .setMessage(R.string.msg_delete_view)
                .setNegativeButton(
                    R.string.no
                ) { d, _ ->
                    d.dismiss()
                }
                .setPositiveButton(
                    R.string.yes
                ) { _, _ ->
                    removeId(target, target is ViewGroup)
                    removeViewAttributes(target)
                    removeWidget(target)
                    updateStructure()
                    updateUndoRedoHistory()
                    dialog.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun showAvailableAttributes(target: View) {
        val availableAttrs =
            initializer.getAvailableAttributesForView(target)
        val names: MutableList<String> = ArrayList()

        for (attr: HashMap<String, Any> in availableAttrs) {
            names.add(attr["name"].toString())
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Available attributes")
            .setAdapter(
                ArrayAdapter(context, android.R.layout.simple_list_item_1, names)
            ) { _, w ->
                /*
                          if (getChildAt(0) instanceof ConstraintLayout) {
                            final List<String> keys = VIEW_ATTRIBUTE_MAP.get(target).keySet();

                            final List<HashMap<String, Object>> attrs = new ArrayList<>();
                            final List<HashMap<String, Object>> allAttrs =
                                INITIALIZER.getAllAttributesForView(target);

                            for (String key : keys) {
                              for (HashMap<String, Object> map : allAttrs) {
                                if (map.get(Constants.KEY_ATTRIBUTE_NAME).toString().equals(key)) {
                                  attrs.add(map);
                                  break;
                                }
                              }
                            }

                            for(HashMap<String, Object> attr : attrs) {

                            }
                          }
                    */
                showAttributeEdit(
                    target, availableAttrs[w][Constants.KEY_ATTRIBUTE_NAME].toString()
                )
            }
            .show()
    }

    private fun showAttributeEdit(target: View, attributeKey: String) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        val argumentTypes =
            currentAttr?.get(Constants.KEY_ARGUMENT_TYPE)?.toString()?.split("\\|".toRegex())
                ?.dropLastWhile { it.isEmpty() }
                ?.toTypedArray()

        if (argumentTypes != null) {
            if (argumentTypes.size > 1) {
                if (attributeMap!!.contains(attributeKey)) {
                    val argumentType =
                        parseType(attributeMap.getValue(attributeKey), argumentTypes)
                    showAttributeEdit(target, attributeKey, argumentType)
                    return
                }
                MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.select_arg_type)
                    .setAdapter(
                        ArrayAdapter(
                            context, android.R.layout.simple_list_item_1, argumentTypes
                        )
                    ) { _, w ->
                        showAttributeEdit(target, attributeKey, argumentTypes[w])
                    }
                    .show()

                return
            }
        }
        showAttributeEdit(target, attributeKey, argumentTypes?.get(0))
    }

    @Suppress("UNCHECKED_CAST")
    private fun showAttributeEdit(
        target: View, attributeKey: String, argumentType: String?
    ) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        var savedValue =
            if (attributeMap!!.contains(attributeKey)) attributeMap.getValue(attributeKey) else ""
        val defaultValue =
            if (currentAttr?.containsKey(Constants.KEY_DEFAULT_VALUE) == true)
                currentAttr[Constants.KEY_DEFAULT_VALUE].toString()
            else null
        val constant =
            if (currentAttr?.containsKey(Constants.KEY_CONSTANT) == true
            ) currentAttr[Constants.KEY_CONSTANT].toString()
            else null

        val context = context

        var dialog: AttributeDialog? = null

        when (argumentType) {
            Constants.ARGUMENT_TYPE_SIZE -> dialog = SizeDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DIMENSION -> dialog =
                DimensionDialog(context, savedValue, currentAttr?.get("dimensionUnit")?.toString())

            Constants.ARGUMENT_TYPE_ID -> dialog = IdDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_VIEW -> dialog = ViewDialog(context, savedValue, constant)
            Constants.ARGUMENT_TYPE_BOOLEAN -> dialog = BooleanDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DRAWABLE -> {
                if (savedValue.startsWith("@drawable/")) {
                    savedValue = savedValue.replace("@drawable/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_DRAWABLE)
            }

            Constants.ARGUMENT_TYPE_STRING -> {
                if (savedValue.startsWith("@string/")) {
                    savedValue = savedValue.replace("@string/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_STRING)
            }

            Constants.ARGUMENT_TYPE_TEXT -> dialog =
                StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_TEXT)

            Constants.ARGUMENT_TYPE_INT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_INT)

            Constants.ARGUMENT_TYPE_FLOAT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_FLOAT)

            Constants.ARGUMENT_TYPE_FLAG -> dialog =
                FlagDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_ENUM -> dialog =
                EnumDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_COLOR -> dialog = ColorDialog(context, savedValue)
        }
        if (dialog == null) return

        dialog.setTitle(currentAttr?.get("name")?.toString())
        dialog.setOnSaveValueListener {
            if (defaultValue != null && (defaultValue == it)) {
                if (attributeMap.contains(attributeKey)) removeAttribute(target, attributeKey)
            } else {
                if (currentAttr != null) {
                    initializer.applyAttribute(target, it!!, currentAttr)
                }
                showDefinedAttributes(target)
                updateUndoRedoHistory()
                updateStructure()
            }
        }

        dialog.show()
    }

    private fun removeViewAttributes(view: View) {
        viewAttributeMap.remove(view)
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                removeViewAttributes(view.getChildAt(i))
            }
        }
    }

    private fun removeAttribute(target: View, attributeKey: String): View {
        @Suppress("NAME_SHADOWING")
        var target = target
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)

        val attributeMap = viewAttributeMap[target]

        if (currentAttr != null) {
            if (currentAttr.containsKey(Constants.KEY_CAN_DELETE)) return target
        }

        val name =
            if (attributeMap!!.contains("android:id")) attributeMap.getValue("android:id") else null
        val id = if (name != null) getViewId(name.replace("@+id/", "")) else -1
        attributeMap.removeValue(attributeKey)

        if ((attributeKey == "android:id")) {
            removeId(target, false)
            target.id = -1
            target.requestLayout()

            // delete all id attributes for views
            for (view: View in viewAttributeMap.keys) {
                val map = viewAttributeMap[view]

                for (key: String in map!!.keySet()) {
                    val value = map.getValue(key)

                    if (value.startsWith("@id/") && (value == name!!.replace("+", ""))) map.removeValue(key)
                }
            }
            updateStructure()
            return target
        }

        viewAttributeMap.remove(target)

        val parent = target.parent as ViewGroup
        val indexOfView = parent.indexOfChild(target)

        parent.removeView(target)

        val childs: MutableList<View> = ArrayList()

        if (target is ViewGroup) {
            val group = target

            if (group.childCount > 0) {
                for (i in 0 until group.childCount) {
                    childs.add(group.getChildAt(i))
                }
            }

            group.removeAllViews()
        }

        if (name != null) removeId(target, false)

        target = InvokeUtil.createView(target.javaClass.name, context) as View
        rearrangeListeners(target)

        if (target is ViewGroup) {
            target.setMinimumWidth(Utils.pxToDp(context, 20))
            target.setMinimumHeight(Utils.pxToDp(context, 20))
            val group = target
            if (childs.size > 0) {
                for (i in childs.indices) {
                    group.addView(childs[i])
                }
            }
            setTransition(group)
        }

        parent.addView(target, indexOfView)
        viewAttributeMap[target] = attributeMap

        if (name != null) {
            addId(target, name, id)
            target.requestLayout()
        }

        val keys = attributeMap.keySet()
        val values = attributeMap.values()
        val attrs: MutableList<HashMap<String, Any>> = ArrayList()

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        for (i in keys.indices) {
            val key = keys[i]
            if ((key == "android:id")) continue
            initializer.applyAttribute(target, values[i], attrs[i])
        }

        try {
            val cls: Class<*> = target.javaClass
            val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
            method.invoke(target, isShowStroke)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        updateStructure()
        updateUndoRedoHistory()
        return target
    }

    private fun initAttributes() {
        attributes = convertJsonToJavaObject(Constants.ATTRIBUTES_FILE)
        parentAttributes = convertJsonToJavaObject(Constants.PARENT_ATTRIBUTES_FILE)
        viewAttributeMap = HashMap()
        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    private fun convertJsonToJavaObject(filePath: String): HashMap<String, List<HashMap<String, Any>>> {
        return Gson()
            .fromJson(
                FileUtil.readFromAsset(filePath, context),
                object : TypeToken<HashMap<String?, ArrayList<HashMap<String?, Any?>?>?>?>() {}.type
            )
    }

    /**
     * Refreshes the canvas after a design-tool setting (grid overlay, snap-to-grid,
     * alignment guides, grid size) has changed in [PreferencesManager]. Call this
     * after toggling any of those settings from the editor toolbar so the grid
     * overlay is redrawn immediately with the new state.
     */
    fun refreshDesignTools() {
        invalidate()
    }

    enum class ViewType {
        DESIGN,
        BLUEPRINT
    }

    companion object {
        /**
         * How close (in dp) the dragged widget's edges/center need to be to a
         * sibling's edges/center before an alignment guide line is shown.
         */
        private const val ALIGNMENT_TOLERANCE_DP = 4
    }
}
