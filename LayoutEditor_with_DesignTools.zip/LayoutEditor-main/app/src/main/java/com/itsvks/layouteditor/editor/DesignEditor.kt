package com.itsvks.layouteditor.editor

import android.animation.LayoutTransition
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.DragEvent
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.View
import android.view.View.OnDragListener
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.widget.TooltipCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.VibrateUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.adapters.AppliedAttributesAdapter
import com.itsvks.layouteditor.databinding.ShowAttributesDialogBinding
import com.itsvks.layouteditor.editor.dialogs.AttributeDialog
import com.itsvks.layouteditor.editor.dialogs.BooleanDialog
import com.itsvks.layouteditor.editor.dialogs.ColorDialog
import com.itsvks.layouteditor.editor.dialogs.DimensionDialog
import com.itsvks.layouteditor.editor.dialogs.EnumDialog
import com.itsvks.layouteditor.editor.dialogs.FlagDialog
import com.itsvks.layouteditor.editor.dialogs.IdDialog
import com.itsvks.layouteditor.editor.dialogs.NumberDialog
import com.itsvks.layouteditor.editor.dialogs.SizeDialog
import com.itsvks.layouteditor.editor.dialogs.StringDialog
import com.itsvks.layouteditor.editor.dialogs.ViewDialog
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager
import com.itsvks.layouteditor.managers.IdManager.addId
import com.itsvks.layouteditor.managers.IdManager.getViewId
import com.itsvks.layouteditor.managers.IdManager.removeId
import com.itsvks.layouteditor.managers.PreferencesManager
import com.itsvks.layouteditor.managers.PreferencesManager.isEnableVibration
import com.itsvks.layouteditor.managers.PreferencesManager.isShowStroke
import com.itsvks.layouteditor.managers.UndoRedoManager
import com.itsvks.layouteditor.tools.XmlLayoutGenerator
import com.itsvks.layouteditor.tools.XmlLayoutParser
import com.itsvks.layouteditor.utils.ArgumentUtil.parseType
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil
import com.itsvks.layouteditor.utils.Utils
import com.itsvks.layouteditor.views.StructureView
import kotlin.math.abs
import kotlin.math.sqrt
import androidx.core.view.isEmpty

class DesignEditor : LinearLayout {
    var viewType: ViewType? = null
        set(value) {
            isBlueprint = viewType == ViewType.BLUEPRINT
            setBlueprintOnChildren()
            invalidate()
            field = value
        }
    var deviceConfiguration: DeviceConfiguration? = null
    var apiLevel: APILevel? = null

    lateinit var viewAttributeMap: HashMap<View, AttributeMap>
        private set

    private lateinit var paint: Paint
    private lateinit var shadow: View

    private lateinit var attributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var parentAttributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var initializer: AttributeInitializer

    private var isBlueprint = false
    private var structureView: StructureView? = null
    private var undoRedoManager: UndoRedoManager? = null

    // ----- Design tools: grid overlay & alignment guides -----

    /** Paint used to draw the grid overlay dots/lines on the canvas. */
    private lateinit var gridPaint: Paint

    /** Paint used to draw alignment guide lines while dragging a widget. */
    private lateinit var guidePaint: Paint

    /** Active alignment guide lines computed during the current drag, in editor-local coordinates. */
    private val alignmentGuides: MutableList<GuideLine> = ArrayList()

    /**
     * Represents a single alignment guide line drawn on top of the canvas while
     * dragging a widget. [vertical] lines run along the y-axis (used for horizontal
     * center/edge alignment), horizontal lines run along the x-axis.
     */
    private data class GuideLine(val vertical: Boolean, val position: Float)

    // ----- Constraint connections (selection handles + connector lines) -----

    /** The currently selected widget, whose constraint handles are drawn on top of the canvas. */
    var selectedView: View? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Paint used to draw the selection bounding box around [selectedView]. */
    private lateinit var selectionPaint: Paint

    /** Paint used to fill the constraint handle circles. */
    private lateinit var handleFillPaint: Paint

    /** Paint used to draw the constraint handle circle outlines. */
    private lateinit var handleStrokePaint: Paint

    /** Paint used to draw constraint/margin connector lines between views. */
    private lateinit var connectorPaint: Paint

    /** Paint used to draw the live connector line while a handle is being dragged. */
    private lateinit var liveConnectorPaint: Paint

    /** The handle currently being dragged, or `null` if no handle drag is in progress. */
    private var draggedHandle: ConstraintHandle? = null

    /** The current finger position (in editor-local coordinates) while dragging a handle. */
    private var dragPointerX = 0f
    private var dragPointerY = 0f

    /** The view currently highlighted as the drop target while dragging a handle. */
    private var dropTargetView: View? = null

    /** Represents one of the 4 constraint handles (anchors) on a selected widget. */
    private enum class HandleSide { TOP, BOTTOM, START, END }

    /** A constraint handle belonging to [owner], positioned at ([x], [y]) in editor-local coordinates. */
    private data class ConstraintHandle(val owner: View, val side: HandleSide, val x: Float, val y: Float)

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context)
    }

    private fun init(context: Context) {
        viewType = ViewType.DESIGN
        isBlueprint = false
        deviceConfiguration = DeviceConfiguration(DeviceSize.LARGE)
        initAttributes()
        shadow = View(context)
        paint = Paint()

        shadow.setBackgroundColor(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutline)
        )
        shadow.layoutParams = ViewGroup.LayoutParams(
            Utils.pxToDp(context, 50),
            Utils.pxToDp(context, 35)
        )
        paint.strokeWidth = Utils.pxToDp(context, 3).toFloat()

        gridPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            color = MaterialColors.getColor(
                this@DesignEditor, com.google.android.material.R.attr.colorOutlineVariant
            )
            alpha = 90
        }

        guidePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            color = Color.parseColor("#FF4081")
        }

        selectionPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 2).toFloat()
            color = Color.parseColor("#1A73E8")
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(10f, 6f), 0f)
        }

        handleFillPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.FILL
            color = Color.parseColor("#1A73E8")
        }

        handleStrokePaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            color = Color.WHITE
        }

        connectorPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 2).toFloat()
            color = Color.parseColor("#4CAF50")
        }

        liveConnectorPaint = Paint().apply {
            isAntiAlias = true
            style = Paint.Style.STROKE
            strokeWidth = Utils.pxToDp(context, 2).toFloat()
            color = Color.parseColor("#1A73E8")
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 7f), 0f)
        }

        orientation = VERTICAL
        setTransition(this)
        setDragListener(this)

        toggleStrokeWidgets()
        setBlueprintOnChildren()

        // Tapping the editor background (no child hit) clears the selection
        setOnClickListener { selectedView = null }
    }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        when (viewType) {
            ViewType.BLUEPRINT -> drawBlueprint(canvas)
            ViewType.DESIGN -> drawDesign(canvas)
            else -> drawDesign(canvas)
        }
        if (PreferencesManager.isShowGrid) drawGridOverlay(canvas)
        if (alignmentGuides.isNotEmpty()) drawAlignmentGuides(canvas)

        // Draw existing constraint/margin connections — only when toggle is ON
        if (PreferencesManager.isShowConnectionLines) {
            drawAllConstraintConnections(canvas)
        }

        // Draw selection handles only for ConstraintLayout children
        val sv = selectedView
        if (sv != null && sv.parent is androidx.constraintlayout.widget.ConstraintLayout) {
            drawSelectionHandles(canvas, sv)
        }
        if (draggedHandle != null) drawLiveConnector(canvas)

        when (deviceConfiguration!!.size) {
            DeviceSize.SMALL -> {
                scaleX = 0.75f
                scaleY = 0.75f
            }

            DeviceSize.MEDIUM -> {
                scaleX = 0.85f
                scaleY = 0.85f
            }

            DeviceSize.LARGE -> {
                scaleX = 0.95f
                scaleY = 0.95f
            }
        }
    }

    /**
     * Draws a grid of evenly spaced lines across the editor canvas. The spacing is
     * controlled by [PreferencesManager.gridSize] (in dp) and is purely visual —
     * it helps the user align widgets by eye and serves as a reference for
     * snap-to-grid dimension values.
     */
    private fun drawGridOverlay(canvas: Canvas) {
        val gridSizePx = Utils.pxToDp(context, PreferencesManager.gridSize).toFloat()
        if (gridSizePx <= 0f) return

        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += gridSizePx
        }

        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += gridSizePx
        }
    }

    /**
     * Draws the alignment guide lines (center/edge snap indicators) that were
     * computed in [updateAlignmentGuides] while a widget is being dragged.
     */
    private fun drawAlignmentGuides(canvas: Canvas) {
        for (guide in alignmentGuides) {
            if (guide.vertical) {
                canvas.drawLine(guide.position, 0f, guide.position, height.toFloat(), guidePaint)
            } else {
                canvas.drawLine(0f, guide.position, width.toFloat(), guide.position, guidePaint)
            }
        }
    }


    private fun drawBlueprint(canvas: Canvas) {
        paint.color = Constants.BLUEPRINT_DASH_COLOR
        setBackgroundColor(Constants.BLUEPRINT_BACKGROUND_COLOR)
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    private fun drawDesign(canvas: Canvas) {
        paint.color = Constants.DESIGN_DASH_COLOR
        setBackgroundColor(Utils.getSurfaceColor(context))
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    fun previewLayout(deviceConfiguration: DeviceConfiguration?, apiLevel: APILevel?) {
        this.deviceConfiguration = deviceConfiguration
        this.apiLevel = apiLevel
    }

    fun resizeLayout(deviceConfiguration: DeviceConfiguration?) {
        this.deviceConfiguration = deviceConfiguration
        invalidate()
    }

    private fun setTransition(group: ViewGroup) {
        if (group is RecyclerView) return
        LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
            enableTransitionType(LayoutTransition.CHANGING)
            setDuration(150)
        }.also { group.layoutTransition = it }
    }

    private fun toggleStrokeWidgets() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                method.invoke(view, isShowStroke)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setBlueprintOnChildren() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                method.invoke(view, isBlueprint)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setDragListener(group: ViewGroup) {
        group.setOnDragListener(
            OnDragListener { host, event ->
                var parent = host as ViewGroup
                val draggedView =
                    if (event.localState is View) event.localState as View else null

                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED -> {
                        if (isEnableVibration) VibrateUtils.vibrate(100)
                        selectedView = null   // hide handles while dragging a widget
                        if ((draggedView != null
                                    && !(draggedView is AdapterView<*> && parent is AdapterView<*>))
                        ) parent.removeView(draggedView)
                    }

                    DragEvent.ACTION_DRAG_EXITED -> {
                        removeWidget(shadow)
                        clearAlignmentGuides()
                        updateUndoRedoHistory()
                    }

                    DragEvent.ACTION_DRAG_ENDED -> {
                        clearAlignmentGuides()
                        if (!event.result && draggedView != null) {
                            removeId(draggedView, draggedView is ViewGroup)
                            removeViewAttributes(draggedView)
                            viewAttributeMap.remove(draggedView)
                            updateStructure()
                        }
                    }

                    DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_ENTERED -> {
                        if (shadow.parent == null) addWidget(
                            shadow,
                            parent,
                            event
                        )
                        else {
                            if (parent is LinearLayout) {
                                val index = parent.indexOfChild(shadow)
                                val newIndex = getIndexForNewChildOfLinear(parent, event)

                                if (index != newIndex) {
                                    parent.removeView(shadow)
                                    try {
                                        parent.addView(shadow, newIndex)
                                    } catch (_: IllegalStateException) {
                                    }
                                }
                            } else {
                                if (shadow.parent !== parent) addWidget(shadow, parent, event)
                            }
                        }

                        if (PreferencesManager.isShowAlignmentGuides) {
                            updateAlignmentGuides(parent, event)
                        }
                    }

                    DragEvent.ACTION_DROP -> {
                        removeWidget(shadow)
                        clearAlignmentGuides()
                        if (childCount >= 1) {
                            if (getChildAt(0) !is ViewGroup) {
                                Toast.makeText(
                                    context,
                                    "Can\'t add more than one widget in the editor.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@OnDragListener true
                            } else {
                                if (parent is DesignEditor) parent = getChildAt(0) as ViewGroup
                            }
                        }
                        if (draggedView == null) {
                            @Suppress("UNCHECKED_CAST")
                            val data = event.localState as HashMap<String, Any>
                            val newView =
                                InvokeUtil.createView(
                                    data[Constants.KEY_CLASS_NAME].toString(), context
                                ) as View

                            newView.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            )
                            rearrangeListeners(newView)

                            if (newView is ViewGroup) {
                                setDragListener(newView)
                                setTransition(newView)
                            }
                            newView.minimumWidth = Utils.pxToDp(context, 20)
                            newView.minimumHeight = Utils.pxToDp(context, 20)

                            if (newView is EditText) newView.isFocusable = false

                            val map = AttributeMap()
                            val id = getIdForNewView(
                                newView.javaClass.superclass.simpleName
                                    .replace(" ".toRegex(), "_")
                                    .lowercase()
                            )
                            IdManager.addNewId(newView, id)
                            map.putValue("android:id", "@+id/$id")
                            map.putValue("android:layout_width", "wrap_content")
                            map.putValue("android:layout_height", "wrap_content")
                            viewAttributeMap[newView] = map

                            addWidget(newView, parent, event)

                            try {
                                val cls: Class<*> = newView.javaClass
                                val setStrokeEnabled =
                                    cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                                val setBlueprint = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                                setStrokeEnabled.invoke(newView, isShowStroke)
                                setBlueprint.invoke(newView, isBlueprint)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            if (data.containsKey(Constants.KEY_DEFAULT_ATTRS)) {
                                @Suppress("UNCHECKED_CAST")
                                initializer.applyDefaultAttributes(
                                    newView, data[Constants.KEY_DEFAULT_ATTRS] as MutableMap<String, String>
                                )
                            }
                        } else addWidget(draggedView, parent, event)
                        updateStructure()
                        updateUndoRedoHistory()
                    }
                }
                true
            })
    }

    private fun getIdForNewView(name: String): String {
        var id = name
        var n = 0
        var firstTime = true
        while (IdManager.containsId(id)) {
            n++
            id = if (firstTime) "$name$n" else id.replace(
                id.elementAt(id.lastIndex).toString().toRegex(), n.toString()
            )
            firstTime = false
        }
        return id
    }

    fun loadLayoutFromParser(xml: String) {
        clearAll()
        selectedView = null

        if (xml.isEmpty()) return

        val parser = XmlLayoutParser(context)
        parser.parseFromXml(xml, context)

        addView(parser.root)
        viewAttributeMap = parser.viewAttributeMap

        for (view in (viewAttributeMap as HashMap<View, *>?)!!.keys) {
            rearrangeListeners(view)

            if (view is ViewGroup) {
                setDragListener(view)
                setTransition(view)
            }
            view.minimumWidth = Utils.pxToDp(context, 20)
            view.minimumHeight = Utils.pxToDp(context, 20)
        }

        updateStructure()
        toggleStrokeWidgets()

        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    fun undo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isUndoEnabled) loadLayoutFromParser(undoRedoManager!!.undo())
    }

    fun redo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isRedoEnabled) loadLayoutFromParser(undoRedoManager!!.redo())
    }

    private fun clearAll() {
        removeAllViews()
        structureView!!.clear()
        viewAttributeMap.clear()
    }

    fun setStructureView(view: StructureView?) {
        structureView = view
    }

    fun bindUndoRedoManager(manager: UndoRedoManager?) {
        undoRedoManager = manager
    }

    private fun updateStructure() {
        if (this.isEmpty()) structureView!!.clear()
        else structureView!!.setView(getChildAt(0))
    }

    fun updateUndoRedoHistory() {
        if (undoRedoManager == null) return
        val result = XmlLayoutGenerator().generate(this, false)
        undoRedoManager!!.addToHistory(result)
    }

    private fun rearrangeListeners(view: View) {
        val gestureDetector =
            GestureDetector(
                context,
                object : SimpleOnGestureListener() {
                    override fun onLongPress(event: MotionEvent) {
                        view.startDragAndDrop(null, DragShadowBuilder(view), view, 0)
                    }
                })

        view.setOnTouchListener(
            object : OnTouchListener {
                var bClick: Boolean = true
                var startX: Float = 0f
                var startY: Float = 0f
                var endX: Float = 0f
                var endY: Float = 0f
                var diffX: Float = 0f
                var diffY: Float = 0f

                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.x
                            startY = event.y
                            bClick = true
                        }

                        MotionEvent.ACTION_UP -> {
                            endX = event.x
                            endY = event.y
                            diffX = abs((startX - endX).toDouble()).toFloat()
                            diffY = abs((startY - endY).toDouble()).toFloat()

                            if ((diffX <= 5) && (diffY <= 5) && bClick) {
                                // Select this view to show constraint handles
                                selectedView = v
                                showDefinedAttributes(v)
                            }

                            bClick = false
                        }
                    }
                    gestureDetector.onTouchEvent(event)
                    return true
                }
            })
    }

    private fun addWidget(view: View, newParent: ViewGroup, event: DragEvent) {
        removeWidget(view)
        if (newParent is LinearLayout) {
            val index = getIndexForNewChildOfLinear(newParent, event)
            newParent.addView(view, index)
        } else {
            try {
                newParent.addView(view, newParent.childCount)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun removeWidget(view: View) {
        (view.parent as ViewGroup?)?.removeView(view)
    }

    // =========================================================
    //  CONSTRAINT HANDLE — TOUCH INTERCEPTION
    // =========================================================

    /**
     * Intercepts touch events before children see them. When a touch-down lands
     * inside one of [selectedView]'s constraint handle circles, we capture the
     * entire gesture ourselves so the user can drag a connector to another view.
     */
    @SuppressLint("ClickableViewAccessibility")
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.action) {
            MotionEvent.ACTION_DOWN -> {
                val handle = hitTestHandles(ev.x, ev.y)
                if (handle != null) {
                    draggedHandle = handle
                    dragPointerX = ev.x
                    dragPointerY = ev.y
                    dropTargetView = null
                    invalidate()
                    return true          // consume — don't let children see this
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (draggedHandle != null) {
                    dragPointerX = ev.x
                    dragPointerY = ev.y
                    dropTargetView = findDropTarget(ev.x, ev.y)
                    invalidate()
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (draggedHandle != null) {
                    if (ev.action == MotionEvent.ACTION_UP) {
                        commitConstraint(draggedHandle!!, ev.x, ev.y)
                    }
                    draggedHandle = null
                    dropTargetView = null
                    invalidate()
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    /**
     * Checks whether ([x], [y]) in editor-local coordinates falls inside one of
     * the four constraint handle circles of [selectedView]. Returns the matching
     * [ConstraintHandle] if so, otherwise `null`.
     */
    private fun hitTestHandles(x: Float, y: Float): ConstraintHandle? {
        val sv = selectedView ?: return null
        if (sv.parent !is androidx.constraintlayout.widget.ConstraintLayout) return null

        val offset = getOffsetFrom(sv)
        val vl = sv.left.toFloat() + offset.first
        val vt = sv.top.toFloat() + offset.second
        val vr = vl + sv.width
        val vb = vt + sv.height
        val cx = (vl + vr) / 2f
        val cy = (vt + vb) / 2f

        val handles = listOf(
            ConstraintHandle(sv, HandleSide.TOP,    cx, vt),
            ConstraintHandle(sv, HandleSide.BOTTOM, cx, vb),
            ConstraintHandle(sv, HandleSide.START,  vl, cy),
            ConstraintHandle(sv, HandleSide.END,    vr, cy)
        )

        val hitRadius = Utils.pxToDp(context, HANDLE_RADIUS_DP + 6).toFloat()
        for (h in handles) {
            val dx = x - h.x
            val dy = y - h.y
            if (dx * dx + dy * dy <= hitRadius * hitRadius) return h
        }
        return null
    }


    /**
     * Finds a suitable constraint drop-target at ([x], [y]).
     *
     * Priority order:
     * 1. A sibling/child view whose bounds contain the point — the user is
     *    connecting to that specific view.
     * 2. Near a parent edge (within [PARENT_EDGE_TOLERANCE_DP] dp) — the user
     *    is connecting to "parent".
     *
     * Returns `null` (no valid target yet) when the pointer is somewhere in the
     * middle of the canvas with no meaningful anchor.
     */
    private fun findDropTarget(x: Float, y: Float): View? {
        val sv = selectedView ?: return null
        val parent = sv.parent as? ViewGroup ?: return null

        // Only allow constraints in ConstraintLayout
        if (parent !is androidx.constraintlayout.widget.ConstraintLayout) return null

        // 1. Check if pointer is over a sibling
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            if (child === sv) continue
            // getOffsetFrom gives parent-chain offset above child, child.left/top is relative to parent
            val off = getOffsetFrom(child)
            val cl = child.left + off.first
            val ct = child.top + off.second
            val cr = cl + child.width
            val cb = ct + child.height
            if (x in cl..cr && y in ct..cb) return child
        }

        // 2. Near parent edge → "parent" constraint
        val pOff = getOffsetFrom(parent)
        val pl = parent.left + pOff.first
        val pt = parent.top + pOff.second
        val pr = pl + parent.width
        val pb = pt + parent.height
        val tol = Utils.pxToDp(context, PARENT_EDGE_TOLERANCE_DP).toFloat()
        if (x <= pl + tol || x >= pr - tol || y <= pt + tol || y >= pb - tol) return parent

        return null
    }

    /**
     * Called on ACTION_UP after a handle drag. Determines the constraint type
     * (ConstraintLayout connection vs. margin), builds the attribute key + value,
     * then calls [AttributeInitializer.applyAttribute] exactly the same way the
     * existing attribute-dialog system does — so the XML is updated and the
     * live view is repositioned atomically.
     */
    private fun commitConstraint(handle: ConstraintHandle, x: Float, y: Float) {
        val target = handle.owner
        val parent = target.parent as? ViewGroup ?: return

        // Only ConstraintLayout supports handle-based connections
        if (parent !is androidx.constraintlayout.widget.ConstraintLayout) return

        val drop = findDropTarget(x, y) ?: return
        val allAttrs = initializer.getAllAttributesForView(target)

        val dropIsParent = (drop === parent)
        val value = if (dropIsParent) "parent" else {
            val dropId = viewAttributeMap[drop]?.getValue("android:id")
                ?.replace("@+id/", "") ?: return
            "@id/$dropId"
        }

        val attrKey = resolveConstraintAttrKey(handle.side, drop, dropIsParent, x, y, parent)
            ?: return
        val attrMap = initializer.getAttributeFromKey(attrKey, allAttrs) ?: return
        initializer.applyAttribute(target, value, attrMap)

        updateStructure()
        updateUndoRedoHistory()
        invalidate()
    }

    /**
     * For ConstraintLayout connections, chooses the best `app:layout_constraint*`
     * attribute name based on which [HandleSide] was dragged and which edge of
     * the drop target (or parent) the pointer is closest to.
     *
     * For example dragging the TOP handle of a widget and dropping it near the
     * BOTTOM edge of another widget → `app:layout_constraintTop_toBottomOf`.
     */
    private fun resolveConstraintAttrKey(
        side: HandleSide,
        drop: View,
        dropIsParent: Boolean,
        x: Float,
        y: Float,
        parent: ViewGroup
    ): String? {
        // Which edge of the drop target is closest to the pointer?
        val dropEdge = if (dropIsParent) {
            nearestParentEdge(x, y, parent)
        } else {
            nearestViewEdge(x, y, drop)
        }

        return when (side) {
            HandleSide.TOP -> when (dropEdge) {
                HandleSide.TOP -> "app:layout_constraintTop_toTopOf"
                HandleSide.BOTTOM -> "app:layout_constraintTop_toBottomOf"
                else -> "app:layout_constraintTop_toTopOf"
            }
            HandleSide.BOTTOM -> when (dropEdge) {
                HandleSide.TOP -> "app:layout_constraintBottom_toTopOf"
                HandleSide.BOTTOM -> "app:layout_constraintBottom_toBottomOf"
                else -> "app:layout_constraintBottom_toBottomOf"
            }
            HandleSide.START -> when (dropEdge) {
                HandleSide.START -> "app:layout_constraintLeft_toLeftOf"
                HandleSide.END -> "app:layout_constraintLeft_toRightOf"
                else -> "app:layout_constraintLeft_toLeftOf"
            }
            HandleSide.END -> when (dropEdge) {
                HandleSide.START -> "app:layout_constraintRight_toLeftOf"
                HandleSide.END -> "app:layout_constraintRight_toRightOf"
                else -> "app:layout_constraintRight_toRightOf"
            }
        }
    }

    /** Returns the [HandleSide] of [parent]'s edge that is nearest to ([x], [y]). */
    private fun nearestParentEdge(x: Float, y: Float, parent: ViewGroup): HandleSide {
        val off = getOffsetFrom(parent)
        val pl = parent.left + off.first; val pt = parent.top + off.second
        val pr = pl + parent.width; val pb = pt + parent.height
        val dists = mapOf(
            HandleSide.TOP to abs(y - pt),
            HandleSide.BOTTOM to abs(y - pb),
            HandleSide.START to abs(x - pl),
            HandleSide.END to abs(x - pr)
        )
        return dists.minByOrNull { it.value }!!.key
    }

    /** Returns the [HandleSide] of [view]'s edge that is nearest to ([x], [y]). */
    private fun nearestViewEdge(x: Float, y: Float, view: View): HandleSide {
        val off = getOffsetFrom(view)
        val vl = view.left + off.first; val vt = view.top + off.second
        val vr = vl + view.width; val vb = vt + view.height
        val dists = mapOf(
            HandleSide.TOP to abs(y - vt),
            HandleSide.BOTTOM to abs(y - vb),
            HandleSide.START to abs(x - vl),
            HandleSide.END to abs(x - vr)
        )
        return dists.minByOrNull { it.value }!!.key
    }

    // =========================================================
    //  CONSTRAINT HANDLE — DRAWING
    // =========================================================

    /**
     * Draws a dashed selection border and four constraint-handle circles around
     * [view] in editor-local canvas coordinates.
     */
    private fun drawSelectionHandles(canvas: Canvas, view: View) {
        val offset = getOffsetFrom(view)
        val vl = view.left.toFloat() + offset.first
        val vt = view.top.toFloat() + offset.second
        val vr = vl + view.width
        val vb = vt + view.height
        val cx = (vl + vr) / 2f
        val cy = (vt + vb) / 2f

        val r = Utils.pxToDp(context, HANDLE_RADIUS_DP).toFloat()

        // Handle positions: top-center, bottom-center, left-center, right-center
        val handlePositions = listOf(
            HandleSide.TOP    to (cx to vt),
            HandleSide.BOTTOM to (cx to vb),
            HandleSide.START  to (vl to cy),
            HandleSide.END    to (vr to cy)
        )

        for ((side, pos) in handlePositions) {
            val (hx, hy) = pos
            val isActive = draggedHandle?.side == side
            // Orange when dragging, white-outlined blue otherwise (like video)
            handleFillPaint.color = if (isActive) Color.parseColor("#FF5722")
                                    else Color.parseColor("#FF6D00")
            canvas.drawCircle(hx, hy, r, handleFillPaint)
            canvas.drawCircle(hx, hy, r, handleStrokePaint)
        }

        // Orange border on drop-target view
        dropTargetView?.let { dtv ->
            val dOff = getOffsetFrom(dtv)
            val dl = dtv.left.toFloat() + dOff.first
            val dt2 = dtv.top.toFloat() + dOff.second
            val dr = dl + dtv.width
            val db = dt2 + dtv.height
            val highlightPaint = Paint(selectionPaint).apply {
                color = Color.parseColor("#FF6D00")
                pathEffect = null
                strokeWidth = Utils.pxToDp(context, 2).toFloat()
            }
            canvas.drawRect(dl, dt2, dr, db, highlightPaint)
        }
    }

    /**
     * Draws the live dashed connector line from the dragged handle's anchor point
     * to the current finger position, while a handle drag is in progress.
     */
    private fun drawLiveConnector(canvas: Canvas) {
        val h = draggedHandle ?: return
        canvas.drawLine(h.x, h.y, dragPointerX, dragPointerY, liveConnectorPaint)
        // Draw a small circle at the finger tip
        canvas.drawCircle(dragPointerX, dragPointerY,
            Utils.pxToDp(context, 5).toFloat(), handleFillPaint)
    }

    /**
     * Iterates over every view that has constraint or margin attributes set in
     * [viewAttributeMap] and draws the corresponding green connector lines,
     * mirroring what Android Studio's layout editor shows (Image 1 in the request).
     *
     * — For ConstraintLayout anchors: a curved Bezier arc from the widget's anchor
     *   handle to the target edge, with a small arrowhead at the destination.
     * — For margin connections: a zigzag "spring" line, matching the style in
     *   Image 2 of the request.
     */
    private fun drawAllConstraintConnections(canvas: Canvas) {
        for ((view, attrMap) in viewAttributeMap) {
            if (view.parent == null) continue
            val parent = view.parent as? ViewGroup ?: continue
            // Only draw connections for ConstraintLayout children
            if (parent !is androidx.constraintlayout.widget.ConstraintLayout) continue

            val allKeys = attrMap.keySet()
            for (key in allKeys) {
                val value = attrMap.getValue(key)
                when {
                    key.startsWith("app:layout_constraint") ->
                        drawConstraintLine(canvas, view, key, value, parent)
                    key.startsWith("android:layout_margin") ->
                        drawMarginSpring(canvas, view, key, value, parent)
                }
            }
        }
    }

    /**
     * Draws a curved Bezier connector from [view]'s anchor-handle (determined by
     * [attrKey]) to the target view's or parent's corresponding edge.
     *
     * The line is green (#4CAF50) to match Android Studio's constraint arrows.
     * A small filled arrowhead is drawn at the destination edge.
     */
    private fun drawConstraintLine(
        canvas: Canvas, view: View, attrKey: String, value: String, parent: ViewGroup
    ) {
        val (srcSide, dstSide) = parseConstraintSides(attrKey) ?: return

        val off = getOffsetFrom(view)
        val vl = view.left + off.first; val vt = view.top + off.second
        val vr = vl + view.width;        val vb = vt + view.height
        val vcx = (vl + vr) / 2f;       val vcy = (vt + vb) / 2f

        // Source point: mid-point of this view's connecting edge
        val (sx, sy) = when (srcSide) {
            HandleSide.TOP    -> vcx to vt
            HandleSide.BOTTOM -> vcx to vb
            HandleSide.START  -> vl  to vcy
            HandleSide.END    -> vr  to vcy
        }

        // Target point: on target's edge, aligned with source so line is straight
        val (tx, ty) = resolveConstraintTarget(value, dstSide, parent, sx, sy) ?: return

        // Draw straight line from source edge to target edge
        canvas.drawLine(sx, sy, tx, ty, connectorPaint)

        // Arrowhead at destination
        drawArrowHead(canvas, sx, sy, tx, ty, connectorPaint)

        // Orange dot at the source handle anchor
        val dotR = Utils.pxToDp(context, 4).toFloat()
        handleFillPaint.color = Color.parseColor("#FF6D00")
        canvas.drawCircle(sx, sy, dotR, handleFillPaint)
    }

    /**
     * Draws a zigzag "spring" line from [view]'s margin-side edge to the parent
     * edge (or nearest boundary), matching the visual style seen in Image 2.
     */
    private fun drawMarginSpring(
        canvas: Canvas, view: View, attrKey: String, value: String, parent: ViewGroup
    ) {
        val side = when {
            attrKey.endsWith("Top")    || attrKey.endsWith("marginTop")    -> HandleSide.TOP
            attrKey.endsWith("Bottom") || attrKey.endsWith("marginBottom") -> HandleSide.BOTTOM
            attrKey.endsWith("Start")  || attrKey.endsWith("marginStart")  -> HandleSide.START
            attrKey.endsWith("End")    || attrKey.endsWith("marginEnd")    -> HandleSide.END
            attrKey.endsWith("Left")   || attrKey.endsWith("marginLeft")   -> HandleSide.START
            attrKey.endsWith("Right")  || attrKey.endsWith("marginRight")  -> HandleSide.END
            else -> return
        }

        val off = getOffsetFrom(view)
        val vl = view.left + off.first; val vt = view.top + off.second
        val vr = vl + view.width;       val vb = vt + view.height
        val vcx = (vl + vr) / 2f;      val vcy = (vt + vb) / 2f

        // Parent bounds in editor coords
        val pOff = getOffsetFrom(parent)
        val pl = parent.left + pOff.first; val pt = parent.top + pOff.second
        val pr = pl + parent.width; val pb = pt + parent.height

        // Source and destination of the spring
        val sx: Float; val sy: Float; val ex: Float; val ey: Float
        val vertical: Boolean
        when (side) {
            HandleSide.TOP    -> { sx = vcx; sy = vt; ex = vcx; ey = pt;  vertical = true  }
            HandleSide.BOTTOM -> { sx = vcx; sy = vb; ex = vcx; ey = pb;  vertical = true  }
            HandleSide.START  -> { sx = vl;  sy = vcy; ex = pl; ey = vcy; vertical = false }
            HandleSide.END    -> { sx = vr;  sy = vcy; ex = pr; ey = vcy; vertical = false }
        }

        drawZigzagSpring(canvas, sx, sy, ex, ey, vertical, connectorPaint)
    }

    /**
     * Draws a zigzag spring path between ([sx],[sy]) and ([ex],[ey]).
     * [vertical] = true means the spring runs top-to-bottom; false = left-to-right.
     */
    private fun drawZigzagSpring(
        canvas: Canvas, sx: Float, sy: Float, ex: Float, ey: Float,
        vertical: Boolean, paint: Paint
    ) {
        val path = android.graphics.Path()
        path.moveTo(sx, sy)

        val totalLen = if (vertical) abs(ey - sy) else abs(ex - sx)
        if (totalLen < 4f) return

        val zigZags = 5
        val amplitude = Utils.pxToDp(context, 5).toFloat()
        val segLen = totalLen / (zigZags * 2 + 2)

        var pos = 0f
        var flip = 1f

        // Short straight lead-in
        pos += segLen
        if (vertical) path.lineTo(sx, sy + (if (ey > sy) pos else -pos))
        else path.lineTo(sx + (if (ex > sx) pos else -pos), sy)

        // Zigzag teeth
        repeat(zigZags * 2) {
            pos += segLen
            val t = if (vertical) sy + (if (ey > sy) pos else -pos) else sy + amplitude * flip
            val l = if (vertical) sx + amplitude * flip else sx + (if (ex > sx) pos else -pos)
            path.lineTo(l, t)
            flip = -flip
        }

        // Short straight lead-out
        path.lineTo(ex, ey)
        canvas.drawPath(path, paint)

        // Endpoint dot
        val dotR = Utils.pxToDp(context, 4).toFloat()
        canvas.drawCircle(ex, ey, dotR, handleFillPaint)
    }

    /**
     * Parses a ConstraintLayout attribute key like
     * `"app:layout_constraintTop_toBottomOf"` into a (srcSide, dstSide) pair.
     */
    private fun parseConstraintSides(key: String): Pair<HandleSide, HandleSide>? {
        // key pattern: app:layout_constraint{SRC}_to{DST}Of
        val inner = key.removePrefix("app:layout_constraint")
            .removeSuffix("Of")          // → "Top_toBottom"
        val parts = inner.split("_to")   // → ["Top","Bottom"]
        if (parts.size != 2) return null
        fun parse(s: String): HandleSide? = when (s.lowercase()) {
            "top"      -> HandleSide.TOP
            "bottom"   -> HandleSide.BOTTOM
            "left", "start"  -> HandleSide.START
            "right","end"    -> HandleSide.END
            "baseline" -> HandleSide.BOTTOM
            else       -> null
        }
        val src = parse(parts[0]) ?: return null
        val dst = parse(parts[1]) ?: return null
        return src to dst
    }

    /**
     * Resolves the exact (x, y) on the target's edge where the constraint line
     * should terminate. The [srcX]/[srcY] are the source handle coordinates — we
     * keep the same axis so the line runs straight (e.g. TOP→TOP keeps the same
     * x, only y changes to the target's top edge).
     */
    private fun resolveConstraintTarget(
        value: String, dstSide: HandleSide, parent: ViewGroup,
        srcX: Float, srcY: Float
    ): Pair<Float, Float>? {
        val targetView: View = if (value == "parent") {
            parent
        } else {
            val idStr = value.replace("@id/", "")
            viewAttributeMap.keys.firstOrNull { v ->
                viewAttributeMap[v]?.getValue("android:id")
                    ?.replace("@+id/", "") == idStr
            } ?: return null
        }

        val off = getOffsetFrom(targetView)
        val tl = targetView.left + off.first
        val tt = targetView.top + off.second
        val tr = tl + targetView.width
        val tb = tt + targetView.height

        // Keep same axis as source so line is straight:
        // TOP/BOTTOM constraints → same x as source, y = target's top or bottom edge
        // START/END constraints  → same y as source, x = target's left or right edge
        return when (dstSide) {
            HandleSide.TOP    -> srcX to tt
            HandleSide.BOTTOM -> srcX to tb
            HandleSide.START  -> tl   to srcY
            HandleSide.END    -> tr   to srcY
        }
    }

    /**
     * Draws a small filled arrowhead at ([tx],[ty]) pointing away from ([fx],[fy]).
     */
    private fun drawArrowHead(
        canvas: Canvas, fx: Float, fy: Float, tx: Float, ty: Float, paint: Paint
    ) {
        val dx = tx - fx; val dy = ty - fy
        val len = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        if (len < 1f) return
        val ux = dx / len; val uy = dy / len
        val arrowLen = Utils.pxToDp(context, 8).toFloat()
        val arrowWidth = Utils.pxToDp(context, 5).toFloat()
        val path = android.graphics.Path()
        path.moveTo(tx, ty)
        path.lineTo(tx - ux * arrowLen + uy * arrowWidth,
                    ty - uy * arrowLen - ux * arrowWidth)
        path.lineTo(tx - ux * arrowLen - uy * arrowWidth,
                    ty - uy * arrowLen + ux * arrowWidth)
        path.close()
        val fillPaint = Paint(paint).apply { style = Paint.Style.FILL }
        canvas.drawPath(path, fillPaint)
    }

    private fun getIndexForNewChildOfLinear(layout: LinearLayout, event: DragEvent): Int {
        val orientation = layout.orientation
        if (orientation == HORIZONTAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.right < event.x) index++
            }
            return index
        }
        if (orientation == VERTICAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.bottom < event.y) index++
            }
            return index
        }
        return -1
    }

    /**
     * Removes any active alignment guide lines and triggers a redraw. Called
     * whenever a drag operation leaves the canvas, ends, or completes.
     */
    private fun clearAlignmentGuides() {
        if (alignmentGuides.isEmpty()) return
        alignmentGuides.clear()
        invalidate()
    }

    /**
     * Computes alignment guide lines for the widget currently being dragged.
     *
     * While the user drags a widget over [parent], this checks the predicted
     * bounds of the dragged widget (using the [shadow] placeholder's current
     * size at the drag location) against the bounds of its sibling views.
     * When the dragged widget's center or edges line up closely with a
     * sibling's center or edges (within [ALIGNMENT_TOLERANCE_DP]), a guide
     * line is recorded so [drawAlignmentGuides] can render it on top of the
     * canvas, helping the user align widgets precisely.
     *
     * All coordinates are converted into this [DesignEditor]'s local
     * coordinate space, since [parent] may be a nested layout.
     */
    private fun updateAlignmentGuides(parent: ViewGroup, event: DragEvent) {
        val newGuides = ArrayList<GuideLine>()

        // Offset of `parent` relative to this editor view, so we can draw guides
        // that span the whole editor canvas regardless of nesting depth.
        val parentOffset = getOffsetFrom(parent)

        // Predicted bounds of the dragged widget within `parent`, using the
        // shadow placeholder's current size as a stand-in for the dragged view.
        val shadowWidth = if (shadow.width > 0) shadow.width else shadow.layoutParams?.width ?: 0
        val shadowHeight = if (shadow.height > 0) shadow.height else shadow.layoutParams?.height ?: 0

        val draggedLeft = event.x - shadowWidth / 2f
        val draggedTop = event.y - shadowHeight / 2f
        val draggedRight = draggedLeft + shadowWidth
        val draggedBottom = draggedTop + shadowHeight
        val draggedCenterX = (draggedLeft + draggedRight) / 2f
        val draggedCenterY = (draggedTop + draggedBottom) / 2f

        val tolerance = Utils.pxToDp(context, ALIGNMENT_TOLERANCE_DP).toFloat()

        for (i in 0 until parent.childCount) {
            val sibling = parent.getChildAt(i)
            if (sibling === shadow) continue

            val siblingLeft = sibling.left.toFloat()
            val siblingTop = sibling.top.toFloat()
            val siblingRight = sibling.right.toFloat()
            val siblingBottom = sibling.bottom.toFloat()
            val siblingCenterX = (siblingLeft + siblingRight) / 2f
            val siblingCenterY = (siblingTop + siblingBottom) / 2f

            // Vertical guide lines (compare x positions)
            addGuideIfClose(newGuides, true, draggedLeft, siblingLeft, tolerance, parentOffset.first)
            addGuideIfClose(newGuides, true, draggedRight, siblingRight, tolerance, parentOffset.first)
            addGuideIfClose(newGuides, true, draggedCenterX, siblingCenterX, tolerance, parentOffset.first)

            // Horizontal guide lines (compare y positions)
            addGuideIfClose(newGuides, false, draggedTop, siblingTop, tolerance, parentOffset.second)
            addGuideIfClose(newGuides, false, draggedBottom, siblingBottom, tolerance, parentOffset.second)
            addGuideIfClose(newGuides, false, draggedCenterY, siblingCenterY, tolerance, parentOffset.second)
        }

        if (newGuides != alignmentGuides) {
            alignmentGuides.clear()
            alignmentGuides.addAll(newGuides)
            invalidate()
        }
    }

    /**
     * If [draggedValue] is within [tolerance] of [siblingValue], adds a [GuideLine]
     * at the sibling's position (translated into this editor's coordinate space
     * via [offset]) to [guides].
     */
    private fun addGuideIfClose(
        guides: MutableList<GuideLine>,
        vertical: Boolean,
        draggedValue: Float,
        siblingValue: Float,
        tolerance: Float,
        offset: Float
    ) {
        if (abs(draggedValue - siblingValue) <= tolerance) {
            guides.add(GuideLine(vertical, siblingValue + offset))
        }
    }

    /**
     * Returns the (x, y) offset of [view] relative to this [DesignEditor], so that
     * coordinates local to a nested layout can be translated into this editor's
     * coordinate space for drawing guide lines that span the whole canvas.
     */
    private fun getOffsetFrom(view: View): Pair<Float, Float> {
        if (view === this) return 0f to 0f

        var dx = 0f
        var dy = 0f
        // Start from view's PARENT (not view itself) to avoid double-counting
        // view.left/top when callers do: view.left + getOffsetFrom(view)
        var current: View? = view.parent as? View
        while (current != null && current !== this) {
            dx += current.left.toFloat()
            dy += current.top.toFloat()
            current = current.parent as? View
        }
        return dx to dy
    }

    fun showDefinedAttributes(target: View) {
        val keys = viewAttributeMap[target]!!.keySet()
        val values = viewAttributeMap[target]!!.values()

        val attrs: MutableList<HashMap<String, Any>> = ArrayList()
        val allAttrs = initializer.getAllAttributesForView(target)

        val dialog = BottomSheetDialog(context)
        val binding =
            ShowAttributesDialogBinding.inflate(dialog.layoutInflater)

        dialog.setContentView(binding.root)
        TooltipCompat.setTooltipText(binding.btnAdd, "Add attribute")
        TooltipCompat.setTooltipText(binding.btnDelete, "Delete")

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        val appliedAttributesAdapter = AppliedAttributesAdapter(attrs, values)

        appliedAttributesAdapter.onClick = {
            showAttributeEdit(target, keys[it])
            dialog.dismiss()
        }

        appliedAttributesAdapter.onRemoveButtonClick = {
            dialog.dismiss()

            val view = removeAttribute(target, keys[it])
            showDefinedAttributes(view)
        }

        binding.attributesList.adapter = appliedAttributesAdapter
        binding.attributesList.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.viewName.text = target.javaClass.superclass.simpleName
        binding.viewFullName.text = target.javaClass.superclass.name
        binding.btnAdd.setOnClickListener {
            showAvailableAttributes(target)
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            MaterialAlertDialogBuilder(context)
                .setTitle(R.string.delete_view)
                .setMessage(R.string.msg_delete_view)
                .setNegativeButton(
                    R.string.no
                ) { d, _ ->
                    d.dismiss()
                }
                .setPositiveButton(
                    R.string.yes
                ) { _, _ ->
                    removeId(target, target is ViewGroup)
                    removeViewAttributes(target)
                    removeWidget(target)
                    updateStructure()
                    updateUndoRedoHistory()
                    dialog.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun showAvailableAttributes(target: View) {
        val availableAttrs =
            initializer.getAvailableAttributesForView(target)
        val names: MutableList<String> = ArrayList()

        for (attr: HashMap<String, Any> in availableAttrs) {
            names.add(attr["name"].toString())
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Available attributes")
            .setAdapter(
                ArrayAdapter(context, android.R.layout.simple_list_item_1, names)
            ) { _, w ->
                /*
                          if (getChildAt(0) instanceof ConstraintLayout) {
                            final List<String> keys = VIEW_ATTRIBUTE_MAP.get(target).keySet();

                            final List<HashMap<String, Object>> attrs = new ArrayList<>();
                            final List<HashMap<String, Object>> allAttrs =
                                INITIALIZER.getAllAttributesForView(target);

                            for (String key : keys) {
                              for (HashMap<String, Object> map : allAttrs) {
                                if (map.get(Constants.KEY_ATTRIBUTE_NAME).toString().equals(key)) {
                                  attrs.add(map);
                                  break;
                                }
                              }
                            }

                            for(HashMap<String, Object> attr : attrs) {

                            }
                          }
                    */
                showAttributeEdit(
                    target, availableAttrs[w][Constants.KEY_ATTRIBUTE_NAME].toString()
                )
            }
            .show()
    }

    private fun showAttributeEdit(target: View, attributeKey: String) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        val argumentTypes =
            currentAttr?.get(Constants.KEY_ARGUMENT_TYPE)?.toString()?.split("\\|".toRegex())
                ?.dropLastWhile { it.isEmpty() }
                ?.toTypedArray()

        if (argumentTypes != null) {
            if (argumentTypes.size > 1) {
                if (attributeMap!!.contains(attributeKey)) {
                    val argumentType =
                        parseType(attributeMap.getValue(attributeKey), argumentTypes)
                    showAttributeEdit(target, attributeKey, argumentType)
                    return
                }
                MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.select_arg_type)
                    .setAdapter(
                        ArrayAdapter(
                            context, android.R.layout.simple_list_item_1, argumentTypes
                        )
                    ) { _, w ->
                        showAttributeEdit(target, attributeKey, argumentTypes[w])
                    }
                    .show()

                return
            }
        }
        showAttributeEdit(target, attributeKey, argumentTypes?.get(0))
    }

    @Suppress("UNCHECKED_CAST")
    private fun showAttributeEdit(
        target: View, attributeKey: String, argumentType: String?
    ) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        var savedValue =
            if (attributeMap!!.contains(attributeKey)) attributeMap.getValue(attributeKey) else ""
        val defaultValue =
            if (currentAttr?.containsKey(Constants.KEY_DEFAULT_VALUE) == true)
                currentAttr[Constants.KEY_DEFAULT_VALUE].toString()
            else null
        val constant =
            if (currentAttr?.containsKey(Constants.KEY_CONSTANT) == true
            ) currentAttr[Constants.KEY_CONSTANT].toString()
            else null

        val context = context

        var dialog: AttributeDialog? = null

        when (argumentType) {
            Constants.ARGUMENT_TYPE_SIZE -> dialog = SizeDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DIMENSION -> dialog =
                DimensionDialog(context, savedValue, currentAttr?.get("dimensionUnit")?.toString())

            Constants.ARGUMENT_TYPE_ID -> dialog = IdDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_VIEW -> dialog = ViewDialog(context, savedValue, constant)
            Constants.ARGUMENT_TYPE_BOOLEAN -> dialog = BooleanDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DRAWABLE -> {
                if (savedValue.startsWith("@drawable/")) {
                    savedValue = savedValue.replace("@drawable/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_DRAWABLE)
            }

            Constants.ARGUMENT_TYPE_STRING -> {
                if (savedValue.startsWith("@string/")) {
                    savedValue = savedValue.replace("@string/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_STRING)
            }

            Constants.ARGUMENT_TYPE_TEXT -> dialog =
                StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_TEXT)

            Constants.ARGUMENT_TYPE_INT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_INT)

            Constants.ARGUMENT_TYPE_FLOAT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_FLOAT)

            Constants.ARGUMENT_TYPE_FLAG -> dialog =
                FlagDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_ENUM -> dialog =
                EnumDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_COLOR -> dialog = ColorDialog(context, savedValue)
        }
        if (dialog == null) return

        dialog.setTitle(currentAttr?.get("name")?.toString())
        dialog.setOnSaveValueListener {
            if (defaultValue != null && (defaultValue == it)) {
                if (attributeMap.contains(attributeKey)) removeAttribute(target, attributeKey)
            } else {
                if (currentAttr != null) {
                    initializer.applyAttribute(target, it!!, currentAttr)
                }
                showDefinedAttributes(target)
                updateUndoRedoHistory()
                updateStructure()
            }
        }

        dialog.show()
    }

    private fun removeViewAttributes(view: View) {
        viewAttributeMap.remove(view)
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                removeViewAttributes(view.getChildAt(i))
            }
        }
    }

    private fun removeAttribute(target: View, attributeKey: String): View {
        @Suppress("NAME_SHADOWING")
        var target = target
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)

        val attributeMap = viewAttributeMap[target]

        if (currentAttr != null) {
            if (currentAttr.containsKey(Constants.KEY_CAN_DELETE)) return target
        }

        val name =
            if (attributeMap!!.contains("android:id")) attributeMap.getValue("android:id") else null
        val id = if (name != null) getViewId(name.replace("@+id/", "")) else -1
        attributeMap.removeValue(attributeKey)

        if ((attributeKey == "android:id")) {
            removeId(target, false)
            target.id = -1
            target.requestLayout()

            // delete all id attributes for views
            for (view: View in viewAttributeMap.keys) {
                val map = viewAttributeMap[view]

                for (key: String in map!!.keySet()) {
                    val value = map.getValue(key)

                    if (value.startsWith("@id/") && (value == name!!.replace("+", ""))) map.removeValue(key)
                }
            }
            updateStructure()
            return target
        }

        viewAttributeMap.remove(target)

        val parent = target.parent as ViewGroup
        val indexOfView = parent.indexOfChild(target)

        parent.removeView(target)

        val childs: MutableList<View> = ArrayList()

        if (target is ViewGroup) {
            val group = target

            if (group.childCount > 0) {
                for (i in 0 until group.childCount) {
                    childs.add(group.getChildAt(i))
                }
            }

            group.removeAllViews()
        }

        if (name != null) removeId(target, false)

        target = InvokeUtil.createView(target.javaClass.name, context) as View
        rearrangeListeners(target)

        if (target is ViewGroup) {
            target.setMinimumWidth(Utils.pxToDp(context, 20))
            target.setMinimumHeight(Utils.pxToDp(context, 20))
            val group = target
            if (childs.size > 0) {
                for (i in childs.indices) {
                    group.addView(childs[i])
                }
            }
            setTransition(group)
        }

        parent.addView(target, indexOfView)
        viewAttributeMap[target] = attributeMap

        if (name != null) {
            addId(target, name, id)
            target.requestLayout()
        }

        val keys = attributeMap.keySet()
        val values = attributeMap.values()
        val attrs: MutableList<HashMap<String, Any>> = ArrayList()

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        for (i in keys.indices) {
            val key = keys[i]
            if ((key == "android:id")) continue
            initializer.applyAttribute(target, values[i], attrs[i])
        }

        try {
            val cls: Class<*> = target.javaClass
            val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
            method.invoke(target, isShowStroke)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        updateStructure()
        updateUndoRedoHistory()
        return target
    }

    private fun initAttributes() {
        attributes = convertJsonToJavaObject(Constants.ATTRIBUTES_FILE)
        parentAttributes = convertJsonToJavaObject(Constants.PARENT_ATTRIBUTES_FILE)
        viewAttributeMap = HashMap()
        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    private fun convertJsonToJavaObject(filePath: String): HashMap<String, List<HashMap<String, Any>>> {
        return Gson()
            .fromJson(
                FileUtil.readFromAsset(filePath, context),
                object : TypeToken<HashMap<String?, ArrayList<HashMap<String?, Any?>?>?>?>() {}.type
            )
    }

    /**
     * Refreshes the canvas after a design-tool setting (grid overlay, snap-to-grid,
     * alignment guides, grid size) has changed in [PreferencesManager]. Call this
     * after toggling any of those settings from the editor toolbar so the grid
     * overlay is redrawn immediately with the new state.
     */
    fun refreshDesignTools() {
        invalidate()
    }

    enum class ViewType {
        DESIGN,
        BLUEPRINT
    }

    companion object {
        /**
         * How close (in dp) the dragged widget's edges/center need to be to a
         * sibling's edges/center before an alignment guide line is shown.
         */
        private const val ALIGNMENT_TOLERANCE_DP = 4

        /** Radius (in dp) of each constraint-handle circle drawn on a selected widget. */
        private const val HANDLE_RADIUS_DP = 7

        /**
         * How close (in dp) the pointer must be to a parent edge to snap the
         * drop target to "parent" during a constraint-handle drag.
         */
        private const val PARENT_EDGE_TOLERANCE_DP = 24
    }
}
