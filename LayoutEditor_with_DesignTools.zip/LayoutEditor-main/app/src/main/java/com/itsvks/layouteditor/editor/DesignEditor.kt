package com.itsvks.layouteditor.editor

import android.animation.LayoutTransition
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.util.AttributeSet
import android.view.DragEvent
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.View
import android.view.View.OnDragListener
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.widget.TooltipCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.VibrateUtils
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.R
import com.itsvks.layouteditor.adapters.AppliedAttributesAdapter
import com.itsvks.layouteditor.databinding.ShowAttributesDialogBinding
import com.itsvks.layouteditor.editor.dialogs.AttributeDialog
import com.itsvks.layouteditor.editor.dialogs.BooleanDialog
import com.itsvks.layouteditor.editor.dialogs.ColorDialog
import com.itsvks.layouteditor.editor.dialogs.DimensionDialog
import com.itsvks.layouteditor.editor.dialogs.EnumDialog
import com.itsvks.layouteditor.editor.dialogs.FlagDialog
import com.itsvks.layouteditor.editor.dialogs.IdDialog
import com.itsvks.layouteditor.editor.dialogs.NumberDialog
import com.itsvks.layouteditor.editor.dialogs.SizeDialog
import com.itsvks.layouteditor.editor.dialogs.StringDialog
import com.itsvks.layouteditor.editor.dialogs.ViewDialog
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager
import com.itsvks.layouteditor.managers.IdManager.addId
import com.itsvks.layouteditor.managers.IdManager.getViewId
import com.itsvks.layouteditor.managers.IdManager.removeId
import com.itsvks.layouteditor.managers.PreferencesManager.isEnableVibration
import com.itsvks.layouteditor.managers.PreferencesManager.isShowAlignmentGuides
import com.itsvks.layouteditor.managers.PreferencesManager.isShowGrid
import com.itsvks.layouteditor.managers.PreferencesManager.isShowStroke
import com.itsvks.layouteditor.managers.UndoRedoManager
import com.itsvks.layouteditor.tools.XmlLayoutGenerator
import com.itsvks.layouteditor.tools.XmlLayoutParser
import com.itsvks.layouteditor.utils.ArgumentUtil.parseType
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil
import com.itsvks.layouteditor.utils.Utils
import com.itsvks.layouteditor.views.StructureView
import kotlin.math.abs
import kotlin.math.round
import androidx.core.view.isEmpty

class DesignEditor : LinearLayout {
    var viewType: ViewType? = null
        set(value) {
            isBlueprint = viewType == ViewType.BLUEPRINT
            setBlueprintOnChildren()
            invalidate()
            field = value
        }
    var deviceConfiguration: DeviceConfiguration? = null
    var apiLevel: APILevel? = null

    lateinit var viewAttributeMap: HashMap<View, AttributeMap>
        private set

    private lateinit var paint: Paint
    private lateinit var shadow: View

    /** Paint used to draw the snap/alignment grid on the canvas.  */
    private lateinit var gridPaint: Paint

    /** Paint used to draw alignment guide lines between the dragged view and its siblings.  */
    private lateinit var guidePaint: Paint

    /** Paint used to draw grid-snap guide lines.  */
    private lateinit var gridSnapPaint: Paint

    /** Currently visible alignment/grid guide lines, recomputed while dragging.  */
    private val alignmentGuides = ArrayList<GuideLine>()

    /**
     * A single alignment/snap guide line drawn on top of the canvas.
     *
     * @param vertical `true` for a vertical line (constant x = [position]),
     *   `false` for a horizontal line (constant y = [position]).
     * @param position the coordinate, in px relative to this view, where the line is drawn.
     * @param isGrid `true` if this guide comes from grid-snap alignment rather than from
     *   aligning with a sibling view's edge/center.
     */
    private data class GuideLine(val vertical: Boolean, val position: Float, val isGrid: Boolean)

    private lateinit var attributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var parentAttributes: HashMap<String, List<HashMap<String, Any>>>
    private lateinit var initializer: AttributeInitializer

    private var isBlueprint = false
    private var structureView: StructureView? = null
    private var undoRedoManager: UndoRedoManager? = null

    constructor(context: Context) : super(context) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs) {
        init(context)
    }

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    ) {
        init(context)
    }

    private fun init(context: Context) {
        viewType = ViewType.DESIGN
        isBlueprint = false
        deviceConfiguration = DeviceConfiguration(DeviceSize.LARGE)
        initAttributes()
        shadow = View(context)
        paint = Paint()

        shadow.setBackgroundColor(
            MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutline)
        )
        shadow.layoutParams = ViewGroup.LayoutParams(
            Utils.pxToDp(context, 50),
            Utils.pxToDp(context, 35)
        )
        paint.strokeWidth = Utils.pxToDp(context, 3).toFloat()

        gridPaint = Paint().apply {
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        guidePaint = Paint().apply {
            color = Constants.ALIGNMENT_GUIDE_COLOR
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f, 4f), 0f)
        }
        gridSnapPaint = Paint().apply {
            color = Constants.GRID_SNAP_GUIDE_COLOR
            strokeWidth = Utils.pxToDp(context, 1).toFloat()
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(8f, 4f), 0f)
        }

        orientation = VERTICAL
        setTransition(this)
        setDragListener(this)

        toggleStrokeWidgets()
        setBlueprintOnChildren()
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (isShowGrid) drawGrid(canvas)
        super.dispatchDraw(canvas)
        when (viewType) {
            ViewType.BLUEPRINT -> drawBlueprint(canvas)
            ViewType.DESIGN -> drawDesign(canvas)
            else -> drawDesign(canvas)
        }
        if (alignmentGuides.isNotEmpty()) drawAlignmentGuides(canvas)
        when (deviceConfiguration!!.size) {
            DeviceSize.SMALL -> {
                scaleX = 0.75f
                scaleY = 0.75f
            }

            DeviceSize.MEDIUM -> {
                scaleX = 0.85f
                scaleY = 0.85f
            }

            DeviceSize.LARGE -> {
                scaleX = 0.95f
                scaleY = 0.95f
            }
        }
    }

    private fun drawBlueprint(canvas: Canvas) {
        paint.color = Constants.BLUEPRINT_DASH_COLOR
        setBackgroundColor(Constants.BLUEPRINT_BACKGROUND_COLOR)
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    private fun drawDesign(canvas: Canvas) {
        paint.color = Constants.DESIGN_DASH_COLOR
        setBackgroundColor(Utils.getSurfaceColor(context))
        Utils.drawDashPathStroke(this, canvas, (paint))
    }

    /**
     * Draws a faint reference grid across the whole editor canvas. The grid size is
     * [Constants.GRID_SIZE_DP] and is shown behind every view so it acts purely as a visual
     * alignment aid (the "snap to grid" feature also snaps the edges of the dragged view to
     * these lines, see [updateAlignmentGuides]).
     */
    private fun drawGrid(canvas: Canvas) {
        val gridSize = Utils.pxToDp(context, Constants.GRID_SIZE_DP).toFloat()
        if (gridSize <= 0f || width <= 0 || height <= 0) return

        gridPaint.color = if (isBlueprint) Constants.BLUEPRINT_DASH_COLOR else Constants.DESIGN_DASH_COLOR
        gridPaint.alpha = Constants.GRID_LINE_ALPHA

        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += gridSize
        }

        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += gridSize
        }
    }

    /** Draws every guide line currently stored in [alignmentGuides] on top of the editor.  */
    private fun drawAlignmentGuides(canvas: Canvas) {
        for (guide in alignmentGuides) {
            val guidePaintToUse = if (guide.isGrid) gridSnapPaint else guidePaint
            if (guide.vertical) {
                canvas.drawLine(guide.position, 0f, guide.position, height.toFloat(), guidePaintToUse)
            } else {
                canvas.drawLine(0f, guide.position, width.toFloat(), guide.position, guidePaintToUse)
            }
        }
    }

    /**
     * Recomputes the alignment/grid guide lines for the [shadow] view, which represents the
     * position the dragged widget will be dropped at inside [parent].
     *
     * For every sibling view inside [parent], the shadow's left/right/top/bottom edges and
     * its center are compared against the sibling's edges/center; if any pair is within
     * [Constants.ALIGNMENT_THRESHOLD_DP] of each other, a guide line is drawn at that position
     * (Alignment Guides). Separately, the shadow's edges are compared against the editor's
     * grid lines, highlighting any near-grid edge with a snap guide (Snap to Grid).
     *
     * This function only draws visual feedback - it never changes where the widget is
     * actually inserted, so the existing index-based drop logic is left untouched.
     */
    private fun updateAlignmentGuides(parent: ViewGroup) {
        if (shadow.parent == null) {
            clearAlignmentGuides()
            return
        }

        val newGuides = ArrayList<GuideLine>()

        if (isShowAlignmentGuides || isShowGrid) {
            val offset = getOffsetFromRoot(parent)
            val threshold = Utils.pxToDp(context, Constants.ALIGNMENT_THRESHOLD_DP).toFloat()

            val shadowLeft = (shadow.left + offset[0]).toFloat()
            val shadowRight = (shadow.right + offset[0]).toFloat()
            val shadowTop = (shadow.top + offset[1]).toFloat()
            val shadowBottom = (shadow.bottom + offset[1]).toFloat()
            val shadowCenterX = (shadowLeft + shadowRight) / 2f
            val shadowCenterY = (shadowTop + shadowBottom) / 2f

            val seenX = HashSet<Int>()
            val seenY = HashSet<Int>()

            if (isShowAlignmentGuides) {
                for (i in 0 until parent.childCount) {
                    val child = parent.getChildAt(i)
                    if (child === shadow) continue

                    val childLeft = (child.left + offset[0]).toFloat()
                    val childRight = (child.right + offset[0]).toFloat()
                    val childTop = (child.top + offset[1]).toFloat()
                    val childBottom = (child.bottom + offset[1]).toFloat()
                    val childCenterX = (childLeft + childRight) / 2f
                    val childCenterY = (childTop + childBottom) / 2f

                    addGuideIfClose(newGuides, seenX, true, false, shadowLeft, childLeft, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowRight, childRight, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowLeft, childRight, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowRight, childLeft, threshold)
                    addGuideIfClose(newGuides, seenX, true, false, shadowCenterX, childCenterX, threshold)

                    addGuideIfClose(newGuides, seenY, false, false, shadowTop, childTop, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowBottom, childBottom, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowTop, childBottom, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowBottom, childTop, threshold)
                    addGuideIfClose(newGuides, seenY, false, false, shadowCenterY, childCenterY, threshold)
                }
            }

            if (isShowGrid) {
                val gridSize = Utils.pxToDp(context, Constants.GRID_SIZE_DP).toFloat()
                if (gridSize > 0f) {
                    addGridGuideIfClose(newGuides, seenX, true, shadowLeft, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenX, true, shadowRight, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenY, false, shadowTop, gridSize, threshold)
                    addGridGuideIfClose(newGuides, seenY, false, shadowBottom, gridSize, threshold)
                }
            }
        }

        if (newGuides != alignmentGuides) {
            alignmentGuides.clear()
            alignmentGuides.addAll(newGuides)
            invalidate()
        }
    }

    /**
     * If [a] and [b] are within [threshold] of each other, adds a guide line at position
     * [b] to [target] (deduplicated via [seen] so multiple sibling edges at the same
     * position only draw a single line).
     */
    private fun addGuideIfClose(
        target: MutableList<GuideLine>,
        seen: MutableSet<Int>,
        vertical: Boolean,
        isGrid: Boolean,
        a: Float,
        b: Float,
        threshold: Float
    ) {
        if (abs(a - b) <= threshold) {
            val key = round(b).toInt()
            if (seen.add(key)) target.add(GuideLine(vertical, b, isGrid))
        }
    }

    /** Snaps [value] to the nearest multiple of [gridSize] and, if close enough, adds a grid guide.  */
    private fun addGridGuideIfClose(
        target: MutableList<GuideLine>,
        seen: MutableSet<Int>,
        vertical: Boolean,
        value: Float,
        gridSize: Float,
        threshold: Float
    ) {
        val nearest = round(value / gridSize) * gridSize
        addGuideIfClose(target, seen, vertical, true, value, nearest, threshold)
    }

    /** Clears any currently displayed alignment/grid guides and redraws if needed.  */
    private fun clearAlignmentGuides() {
        if (alignmentGuides.isNotEmpty()) {
            alignmentGuides.clear()
            invalidate()
        }
    }

    /**
     * Walks up the view hierarchy from [view] to this [DesignEditor], accumulating left/top
     * offsets. Child coordinates such as `view.left`/`view.top` are always relative to their
     * immediate parent, so this lets us convert a descendant's coordinates into coordinates
     * relative to this editor's own canvas (which is what [dispatchDraw] draws on).
     */
    private fun getOffsetFromRoot(view: View): IntArray {
        var x = 0
        var y = 0
        var current: View = view
        while (current !== this) {
            x += current.left
            y += current.top
            val p = current.parent
            if (p !is View) break
            current = p
        }
        return intArrayOf(x, y)
    }

    fun previewLayout(deviceConfiguration: DeviceConfiguration?, apiLevel: APILevel?) {
        this.deviceConfiguration = deviceConfiguration
        this.apiLevel = apiLevel
    }

    fun resizeLayout(deviceConfiguration: DeviceConfiguration?) {
        this.deviceConfiguration = deviceConfiguration
        invalidate()
    }

    private fun setTransition(group: ViewGroup) {
        if (group is RecyclerView) return
        LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGE_DISAPPEARING)
            enableTransitionType(LayoutTransition.CHANGING)
            setDuration(150)
        }.also { group.layoutTransition = it }
    }

    private fun toggleStrokeWidgets() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                method.invoke(view, isShowStroke)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setBlueprintOnChildren() {
        try {
            for (view in viewAttributeMap.keys) {
                val cls = view.javaClass
                val method = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                method.invoke(view, isBlueprint)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setDragListener(group: ViewGroup) {
        group.setOnDragListener(
            OnDragListener { host, event ->
                var parent = host as ViewGroup
                val draggedView =
                    if (event.localState is View) event.localState as View else null

                when (event.action) {
                    DragEvent.ACTION_DRAG_STARTED -> {
                        if (isEnableVibration) VibrateUtils.vibrate(100)
                        if ((draggedView != null
                                    && !(draggedView is AdapterView<*> && parent is AdapterView<*>))
                        ) parent.removeView(draggedView)
                    }

                    DragEvent.ACTION_DRAG_EXITED -> {
                        removeWidget(shadow)
                        updateUndoRedoHistory()
                        clearAlignmentGuides()
                    }

                    DragEvent.ACTION_DRAG_ENDED -> {
                        clearAlignmentGuides()
                        if (!event.result && draggedView != null) {
                            removeId(draggedView, draggedView is ViewGroup)
                            removeViewAttributes(draggedView)
                            viewAttributeMap.remove(draggedView)
                            updateStructure()
                        }
                    }

                    DragEvent.ACTION_DRAG_LOCATION, DragEvent.ACTION_DRAG_ENTERED -> if (shadow.parent == null) addWidget(
                        shadow,
                        parent,
                        event
                    )
                    else {
                        if (parent is LinearLayout) {
                            val index = parent.indexOfChild(shadow)
                            val newIndex = getIndexForNewChildOfLinear(parent, event)

                            if (index != newIndex) {
                                parent.removeView(shadow)
                                try {
                                    parent.addView(shadow, newIndex)
                                } catch (_: IllegalStateException) {
                                }
                            }
                        } else {
                            if (shadow.parent !== parent) addWidget(shadow, parent, event)
                        }
                        updateAlignmentGuides(parent)
                    }

                    DragEvent.ACTION_DROP -> {
                        clearAlignmentGuides()
                        removeWidget(shadow)
                        if (childCount >= 1) {
                            if (getChildAt(0) !is ViewGroup) {
                                Toast.makeText(
                                    context,
                                    "Can\'t add more than one widget in the editor.",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@OnDragListener true
                            } else {
                                if (parent is DesignEditor) parent = getChildAt(0) as ViewGroup
                            }
                        }
                        if (draggedView == null) {
                            @Suppress("UNCHECKED_CAST")
                            val data = event.localState as HashMap<String, Any>
                            val newView =
                                InvokeUtil.createView(
                                    data[Constants.KEY_CLASS_NAME].toString(), context
                                ) as View

                            newView.layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT
                            )
                            rearrangeListeners(newView)

                            if (newView is ViewGroup) {
                                setDragListener(newView)
                                setTransition(newView)
                            }
                            newView.minimumWidth = Utils.pxToDp(context, 20)
                            newView.minimumHeight = Utils.pxToDp(context, 20)

                            if (newView is EditText) newView.isFocusable = false

                            val map = AttributeMap()
                            val id = getIdForNewView(
                                newView.javaClass.superclass.simpleName
                                    .replace(" ".toRegex(), "_")
                                    .lowercase()
                            )
                            IdManager.addNewId(newView, id)
                            map.putValue("android:id", "@+id/$id")
                            map.putValue("android:layout_width", "wrap_content")
                            map.putValue("android:layout_height", "wrap_content")
                            viewAttributeMap[newView] = map

                            addWidget(newView, parent, event)

                            try {
                                val cls: Class<*> = newView.javaClass
                                val setStrokeEnabled =
                                    cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
                                val setBlueprint = cls.getMethod("setBlueprint", Boolean::class.javaPrimitiveType)
                                setStrokeEnabled.invoke(newView, isShowStroke)
                                setBlueprint.invoke(newView, isBlueprint)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            if (data.containsKey(Constants.KEY_DEFAULT_ATTRS)) {
                                @Suppress("UNCHECKED_CAST")
                                initializer.applyDefaultAttributes(
                                    newView, data[Constants.KEY_DEFAULT_ATTRS] as MutableMap<String, String>
                                )
                            }
                        } else addWidget(draggedView, parent, event)
                        updateStructure()
                        updateUndoRedoHistory()
                    }
                }
                true
            })
    }

    private fun getIdForNewView(name: String): String {
        var id = name
        var n = 0
        var firstTime = true
        while (IdManager.containsId(id)) {
            n++
            id = if (firstTime) "$name$n" else id.replace(
                id.elementAt(id.lastIndex).toString().toRegex(), n.toString()
            )
            firstTime = false
        }
        return id
    }

    fun loadLayoutFromParser(xml: String) {
        clearAll()

        if (xml.isEmpty()) return

        val parser = XmlLayoutParser(context)
        parser.parseFromXml(xml, context)

        addView(parser.root)
        viewAttributeMap = parser.viewAttributeMap

        for (view in (viewAttributeMap as HashMap<View, *>?)!!.keys) {
            rearrangeListeners(view)

            if (view is ViewGroup) {
                setDragListener(view)
                setTransition(view)
            }
            view.minimumWidth = Utils.pxToDp(context, 20)
            view.minimumHeight = Utils.pxToDp(context, 20)
        }

        updateStructure()
        toggleStrokeWidgets()

        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    fun undo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isUndoEnabled) loadLayoutFromParser(undoRedoManager!!.undo())
    }

    fun redo() {
        if (undoRedoManager == null) return
        if (undoRedoManager!!.isRedoEnabled) loadLayoutFromParser(undoRedoManager!!.redo())
    }

    private fun clearAll() {
        removeAllViews()
        structureView!!.clear()
        viewAttributeMap.clear()
    }

    fun setStructureView(view: StructureView?) {
        structureView = view
    }

    fun bindUndoRedoManager(manager: UndoRedoManager?) {
        undoRedoManager = manager
    }

    private fun updateStructure() {
        if (this.isEmpty()) structureView!!.clear()
        else structureView!!.setView(getChildAt(0))
    }

    fun updateUndoRedoHistory() {
        if (undoRedoManager == null) return
        val result = XmlLayoutGenerator().generate(this, false)
        undoRedoManager!!.addToHistory(result)
    }

    private fun rearrangeListeners(view: View) {
        val gestureDetector =
            GestureDetector(
                context,
                object : SimpleOnGestureListener() {
                    override fun onLongPress(event: MotionEvent) {
                        view.startDragAndDrop(null, DragShadowBuilder(view), view, 0)
                    }
                })

        view.setOnTouchListener(
            object : OnTouchListener {
                var bClick: Boolean = true
                var startX: Float = 0f
                var startY: Float = 0f
                var endX: Float = 0f
                var endY: Float = 0f
                var diffX: Float = 0f
                var diffY: Float = 0f

                @SuppressLint("ClickableViewAccessibility")
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startX = event.x
                            startY = event.y
                            bClick = true
                        }

                        MotionEvent.ACTION_UP -> {
                            endX = event.x
                            endY = event.y
                            diffX = abs((startX - endX).toDouble()).toFloat()
                            diffY = abs((startY - endY).toDouble()).toFloat()

                            if ((diffX <= 5) && (diffY <= 5) && bClick) showDefinedAttributes(v)

                            bClick = false
                        }
                    }
                    gestureDetector.onTouchEvent(event)
                    return true
                }
            })
    }

    private fun addWidget(view: View, newParent: ViewGroup, event: DragEvent) {
        removeWidget(view)
        if (newParent is LinearLayout) {
            val index = getIndexForNewChildOfLinear(newParent, event)
            newParent.addView(view, index)
        } else {
            try {
                newParent.addView(view, newParent.childCount)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun removeWidget(view: View) {
        (view.parent as ViewGroup?)?.removeView(view)
    }

    private fun getIndexForNewChildOfLinear(layout: LinearLayout, event: DragEvent): Int {
        val orientation = layout.orientation
        if (orientation == HORIZONTAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.right < event.x) index++
            }
            return index
        }
        if (orientation == VERTICAL) {
            var index = 0
            for (i in 0 until layout.childCount) {
                val child = layout.getChildAt(i)
                if (child === shadow) continue
                if (child.bottom < event.y) index++
            }
            return index
        }
        return -1
    }

    fun showDefinedAttributes(target: View) {
        val keys = viewAttributeMap[target]!!.keySet()
        val values = viewAttributeMap[target]!!.values()

        val attrs: MutableList<HashMap<String, Any>> = ArrayList()
        val allAttrs = initializer.getAllAttributesForView(target)

        val dialog = BottomSheetDialog(context)
        val binding =
            ShowAttributesDialogBinding.inflate(dialog.layoutInflater)

        dialog.setContentView(binding.root)
        TooltipCompat.setTooltipText(binding.btnAdd, "Add attribute")
        TooltipCompat.setTooltipText(binding.btnDelete, "Delete")

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        val appliedAttributesAdapter = AppliedAttributesAdapter(attrs, values)

        appliedAttributesAdapter.onClick = {
            showAttributeEdit(target, keys[it])
            dialog.dismiss()
        }

        appliedAttributesAdapter.onRemoveButtonClick = {
            dialog.dismiss()

            val view = removeAttribute(target, keys[it])
            showDefinedAttributes(view)
        }

        binding.attributesList.adapter = appliedAttributesAdapter
        binding.attributesList.layoutManager =
            LinearLayoutManager(context, RecyclerView.VERTICAL, false)
        binding.viewName.text = target.javaClass.superclass.simpleName
        binding.viewFullName.text = target.javaClass.superclass.name
        binding.btnAdd.setOnClickListener {
            showAvailableAttributes(target)
            dialog.dismiss()
        }

        binding.btnDelete.setOnClickListener {
            MaterialAlertDialogBuilder(context)
                .setTitle(R.string.delete_view)
                .setMessage(R.string.msg_delete_view)
                .setNegativeButton(
                    R.string.no
                ) { d, _ ->
                    d.dismiss()
                }
                .setPositiveButton(
                    R.string.yes
                ) { _, _ ->
                    removeId(target, target is ViewGroup)
                    removeViewAttributes(target)
                    removeWidget(target)
                    updateStructure()
                    updateUndoRedoHistory()
                    dialog.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun showAvailableAttributes(target: View) {
        val availableAttrs =
            initializer.getAvailableAttributesForView(target)
        val names: MutableList<String> = ArrayList()

        for (attr: HashMap<String, Any> in availableAttrs) {
            names.add(attr["name"].toString())
        }

        MaterialAlertDialogBuilder(context)
            .setTitle("Available attributes")
            .setAdapter(
                ArrayAdapter(context, android.R.layout.simple_list_item_1, names)
            ) { _, w ->
                /*
                          if (getChildAt(0) instanceof ConstraintLayout) {
                            final List<String> keys = VIEW_ATTRIBUTE_MAP.get(target).keySet();

                            final List<HashMap<String, Object>> attrs = new ArrayList<>();
                            final List<HashMap<String, Object>> allAttrs =
                                INITIALIZER.getAllAttributesForView(target);

                            for (String key : keys) {
                              for (HashMap<String, Object> map : allAttrs) {
                                if (map.get(Constants.KEY_ATTRIBUTE_NAME).toString().equals(key)) {
                                  attrs.add(map);
                                  break;
                                }
                              }
                            }

                            for(HashMap<String, Object> attr : attrs) {

                            }
                          }
                    */
                showAttributeEdit(
                    target, availableAttrs[w][Constants.KEY_ATTRIBUTE_NAME].toString()
                )
            }
            .show()
    }

    private fun showAttributeEdit(target: View, attributeKey: String) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        val argumentTypes =
            currentAttr?.get(Constants.KEY_ARGUMENT_TYPE)?.toString()?.split("\\|".toRegex())
                ?.dropLastWhile { it.isEmpty() }
                ?.toTypedArray()

        if (argumentTypes != null) {
            if (argumentTypes.size > 1) {
                if (attributeMap!!.contains(attributeKey)) {
                    val argumentType =
                        parseType(attributeMap.getValue(attributeKey), argumentTypes)
                    showAttributeEdit(target, attributeKey, argumentType)
                    return
                }
                MaterialAlertDialogBuilder(context)
                    .setTitle(R.string.select_arg_type)
                    .setAdapter(
                        ArrayAdapter(
                            context, android.R.layout.simple_list_item_1, argumentTypes
                        )
                    ) { _, w ->
                        showAttributeEdit(target, attributeKey, argumentTypes[w])
                    }
                    .show()

                return
            }
        }
        showAttributeEdit(target, attributeKey, argumentTypes?.get(0))
    }

    @Suppress("UNCHECKED_CAST")
    private fun showAttributeEdit(
        target: View, attributeKey: String, argumentType: String?
    ) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)
        val attributeMap = viewAttributeMap[target]

        var savedValue =
            if (attributeMap!!.contains(attributeKey)) attributeMap.getValue(attributeKey) else ""
        val defaultValue =
            if (currentAttr?.containsKey(Constants.KEY_DEFAULT_VALUE) == true)
                currentAttr[Constants.KEY_DEFAULT_VALUE].toString()
            else null
        val constant =
            if (currentAttr?.containsKey(Constants.KEY_CONSTANT) == true
            ) currentAttr[Constants.KEY_CONSTANT].toString()
            else null

        val context = context

        var dialog: AttributeDialog? = null

        when (argumentType) {
            Constants.ARGUMENT_TYPE_SIZE -> dialog = SizeDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DIMENSION -> dialog =
                DimensionDialog(context, savedValue, currentAttr?.get("dimensionUnit")?.toString())

            Constants.ARGUMENT_TYPE_ID -> dialog = IdDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_VIEW -> dialog = ViewDialog(context, savedValue, constant)
            Constants.ARGUMENT_TYPE_BOOLEAN -> dialog = BooleanDialog(context, savedValue)
            Constants.ARGUMENT_TYPE_DRAWABLE -> {
                if (savedValue.startsWith("@drawable/")) {
                    savedValue = savedValue.replace("@drawable/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_DRAWABLE)
            }

            Constants.ARGUMENT_TYPE_STRING -> {
                if (savedValue.startsWith("@string/")) {
                    savedValue = savedValue.replace("@string/", "")
                }
                dialog = StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_STRING)
            }

            Constants.ARGUMENT_TYPE_TEXT -> dialog =
                StringDialog(context, savedValue, Constants.ARGUMENT_TYPE_TEXT)

            Constants.ARGUMENT_TYPE_INT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_INT)

            Constants.ARGUMENT_TYPE_FLOAT -> dialog =
                NumberDialog(context, savedValue, Constants.ARGUMENT_TYPE_FLOAT)

            Constants.ARGUMENT_TYPE_FLAG -> dialog =
                FlagDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_ENUM -> dialog =
                EnumDialog(context, savedValue, currentAttr?.get("arguments") as ArrayList<String>?)

            Constants.ARGUMENT_TYPE_COLOR -> dialog = ColorDialog(context, savedValue)
        }
        if (dialog == null) return

        dialog.setTitle(currentAttr?.get("name")?.toString())
        dialog.setOnSaveValueListener {
            if (defaultValue != null && (defaultValue == it)) {
                if (attributeMap.contains(attributeKey)) removeAttribute(target, attributeKey)
            } else {
                if (currentAttr != null) {
                    initializer.applyAttribute(target, it!!, currentAttr)
                }
                showDefinedAttributes(target)
                updateUndoRedoHistory()
                updateStructure()
            }
        }

        dialog.show()
    }

    private fun removeViewAttributes(view: View) {
        viewAttributeMap.remove(view)
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                removeViewAttributes(view.getChildAt(i))
            }
        }
    }

    private fun removeAttribute(target: View, attributeKey: String): View {
        @Suppress("NAME_SHADOWING")
        var target = target
        val allAttrs = initializer.getAllAttributesForView(target)
        val currentAttr =
            initializer.getAttributeFromKey(attributeKey, allAttrs)

        val attributeMap = viewAttributeMap[target]

        if (currentAttr != null) {
            if (currentAttr.containsKey(Constants.KEY_CAN_DELETE)) return target
        }

        val name =
            if (attributeMap!!.contains("android:id")) attributeMap.getValue("android:id") else null
        val id = if (name != null) getViewId(name.replace("@+id/", "")) else -1
        attributeMap.removeValue(attributeKey)

        if ((attributeKey == "android:id")) {
            removeId(target, false)
            target.id = -1
            target.requestLayout()

            // delete all id attributes for views
            for (view: View in viewAttributeMap.keys) {
                val map = viewAttributeMap[view]

                for (key: String in map!!.keySet()) {
                    val value = map.getValue(key)

                    if (value.startsWith("@id/") && (value == name!!.replace("+", ""))) map.removeValue(key)
                }
            }
            updateStructure()
            return target
        }

        viewAttributeMap.remove(target)

        val parent = target.parent as ViewGroup
        val indexOfView = parent.indexOfChild(target)

        parent.removeView(target)

        val childs: MutableList<View> = ArrayList()

        if (target is ViewGroup) {
            val group = target

            if (group.childCount > 0) {
                for (i in 0 until group.childCount) {
                    childs.add(group.getChildAt(i))
                }
            }

            group.removeAllViews()
        }

        if (name != null) removeId(target, false)

        target = InvokeUtil.createView(target.javaClass.name, context) as View
        rearrangeListeners(target)

        if (target is ViewGroup) {
            target.setMinimumWidth(Utils.pxToDp(context, 20))
            target.setMinimumHeight(Utils.pxToDp(context, 20))
            val group = target
            if (childs.size > 0) {
                for (i in childs.indices) {
                    group.addView(childs[i])
                }
            }
            setTransition(group)
        }

        parent.addView(target, indexOfView)
        viewAttributeMap[target] = attributeMap

        if (name != null) {
            addId(target, name, id)
            target.requestLayout()
        }

        val keys = attributeMap.keySet()
        val values = attributeMap.values()
        val attrs: MutableList<HashMap<String, Any>> = ArrayList()

        for (key: String in keys) {
            for (map: HashMap<String, Any> in allAttrs) {
                if ((map[Constants.KEY_ATTRIBUTE_NAME].toString() == key)) {
                    attrs.add(map)
                    break
                }
            }
        }

        for (i in keys.indices) {
            val key = keys[i]
            if ((key == "android:id")) continue
            initializer.applyAttribute(target, values[i], attrs[i])
        }

        try {
            val cls: Class<*> = target.javaClass
            val method = cls.getMethod("setStrokeEnabled", Boolean::class.javaPrimitiveType)
            method.invoke(target, isShowStroke)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        updateStructure()
        updateUndoRedoHistory()
        return target
    }

    private fun initAttributes() {
        attributes = convertJsonToJavaObject(Constants.ATTRIBUTES_FILE)
        parentAttributes = convertJsonToJavaObject(Constants.PARENT_ATTRIBUTES_FILE)
        viewAttributeMap = HashMap()
        initializer =
            AttributeInitializer(context, viewAttributeMap, attributes, parentAttributes)
    }

    private fun convertJsonToJavaObject(filePath: String): HashMap<String, List<HashMap<String, Any>>> {
        return Gson()
            .fromJson(
                FileUtil.readFromAsset(filePath, context),
                object : TypeToken<HashMap<String?, ArrayList<HashMap<String?, Any?>?>?>?>() {}.type
            )
    }

    enum class ViewType {
        DESIGN,
        BLUEPRINT
    }
}
