package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.textfield.TextInputLayout;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link TextInputLayout}. */
public class TextInputLayoutCaller {

    public static void setHint(View target, String value, Context context) {
        if (target instanceof TextInputLayout) {
            ((TextInputLayout) target).setHint(value);
        }
    }

    public static void setHelperText(View target, String value, Context context) {
        if (target instanceof TextInputLayout) {
            ((TextInputLayout) target).setHelperText(value);
        }
    }

    public static void setErrorEnabled(View target, String value, Context context) {
        if (target instanceof TextInputLayout) {
            ((TextInputLayout) target).setErrorEnabled(value.equals("true"));
        }
    }

    public static void setBoxBackgroundMode(View target, String value, Context context) {
        if (!(target instanceof TextInputLayout)) return;
        int mode;
        switch (value) {
            case "outline": mode = TextInputLayout.BOX_BACKGROUND_OUTLINE; break;
            case "filled":  mode = TextInputLayout.BOX_BACKGROUND_FILLED; break;
            default:        mode = TextInputLayout.BOX_BACKGROUND_NONE; break;
        }
        ((TextInputLayout) target).setBoxBackgroundMode(mode);
    }

    public static void setBoxStrokeColor(View target, String value, Context context) {
        if (target instanceof TextInputLayout) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((TextInputLayout) target).setBoxStrokeColor(color);
        }
    }
}
