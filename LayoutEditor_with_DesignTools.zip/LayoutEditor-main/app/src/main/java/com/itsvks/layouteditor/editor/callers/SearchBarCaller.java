package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.search.SearchBar;

/** Attribute caller for {@link SearchBar}. */
public class SearchBarCaller {

    public static void setHint(View target, String value, Context context) {
        if (target instanceof SearchBar) {
            ((SearchBar) target).setHint(value);
        }
    }

    public static void setText(View target, String value, Context context) {
        if (target instanceof SearchBar) {
            ((SearchBar) target).setText(value);
        }
    }
}
