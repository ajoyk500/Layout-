package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;
import android.widget.ProgressBar;

/** Attribute caller for {@link ProgressBar}. */
public class ProgressBarCaller {

    public static void setProgress(View target, String value, Context context) {
        if (target instanceof ProgressBar) {
            try { ((ProgressBar) target).setProgress(Integer.parseInt(value)); } catch (Exception ignored) {}
        }
    }

    public static void setMax(View target, String value, Context context) {
        if (target instanceof ProgressBar) {
            try { ((ProgressBar) target).setMax(Integer.parseInt(value)); } catch (Exception ignored) {}
        }
    }

    public static void setIndeterminate(View target, String value, Context context) {
        if (target instanceof ProgressBar) {
            ((ProgressBar) target).setIndeterminate(value.equals("true"));
        }
    }
}
