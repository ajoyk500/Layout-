package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;
import android.widget.Checkable;

/**
 * Attribute caller for MaterialSwitch (and any other Checkable that doesn't
 * have its own dedicated caller). android:text is handled by ViewCaller.
 */
public class MaterialSwitchCaller {

    public static void setText(View target, String value, Context context) {
        ViewCaller.setText(target, value, context);
    }

    public static void setChecked(View target, String value, Context context) {
        if (target instanceof Checkable) {
            ((Checkable) target).setChecked(value.equals("true"));
        }
    }
}
