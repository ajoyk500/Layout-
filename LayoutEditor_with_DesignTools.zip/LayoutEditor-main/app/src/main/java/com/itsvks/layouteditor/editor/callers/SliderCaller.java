package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.slider.Slider;

/** Attribute caller for {@link Slider}. */
public class SliderCaller {

    public static void setValueFrom(View target, String value, Context context) {
        if (target instanceof Slider) {
            try { ((Slider) target).setValueFrom(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }

    public static void setValueTo(View target, String value, Context context) {
        if (target instanceof Slider) {
            try { ((Slider) target).setValueTo(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }

    public static void setValue(View target, String value, Context context) {
        if (target instanceof Slider) {
            try { ((Slider) target).setValue(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }

    public static void setStepSize(View target, String value, Context context) {
        if (target instanceof Slider) {
            try { ((Slider) target).setStepSize(Float.parseFloat(value)); } catch (Exception ignored) {}
        }
    }
}
