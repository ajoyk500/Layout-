package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.card.MaterialCardView;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link MaterialCardView}. */
public class MaterialCardViewCaller {

    public static void setCardElevation(View target, String value, Context context) {
        if (target instanceof MaterialCardView) {
            try {
                ((MaterialCardView) target).setCardElevation(DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }

    public static void setCardCornerRadius(View target, String value, Context context) {
        if (target instanceof MaterialCardView) {
            try {
                ((MaterialCardView) target).setRadius(DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }

    public static void setCardBackgroundColor(View target, String value, Context context) {
        if (target instanceof MaterialCardView) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((MaterialCardView) target).setCardBackgroundColor(color);
        }
    }

    public static void setStrokeColor(View target, String value, Context context) {
        if (target instanceof MaterialCardView) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((MaterialCardView) target).setStrokeColor(color);
        }
    }

    public static void setStrokeWidth(View target, String value, Context context) {
        if (target instanceof MaterialCardView) {
            try {
                ((MaterialCardView) target).setStrokeWidth((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }
}
