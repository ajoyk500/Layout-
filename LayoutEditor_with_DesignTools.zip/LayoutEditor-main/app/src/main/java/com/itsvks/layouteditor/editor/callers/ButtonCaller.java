package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;
import android.widget.Button;

import com.google.android.material.button.MaterialButton;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/**
 * Handles Button / MaterialButton specific attributes that aren't covered by
 * the generic View or TextView callers — background tint, corner radius,
 * icon, icon tint, and stroke (Material outlined-button style).
 *
 * Uses {@link View#setBackgroundTintList} which works on both a plain
 * {@link Button} and a {@link MaterialButton}, so the "SIGN IN" style button
 * renders correctly regardless of which concrete class was used in the XML.
 */
public class ButtonCaller {

    public static void setBackgroundTint(View target, String value, Context context) {
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) target.setBackgroundTintList(ColorStateList.valueOf(color));
    }

    public static void setCornerRadius(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int radius = (int) DimensionUtil.parse(value, context);
                ((MaterialButton) target).setCornerRadius(radius);
            } catch (Exception ignored) {}
        }
    }

    public static void setIcon(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                android.graphics.drawable.Drawable d = ResourceResolver.resolveDrawable(context, value);
                if (d != null) ((MaterialButton) target).setIcon(d);
            } catch (Exception ignored) {}
        }
    }

    public static void setIconTint(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((MaterialButton) target).setIconTint(ColorStateList.valueOf(color));
        }
    }

    public static void setStrokeColor(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((MaterialButton) target).setStrokeColor(ColorStateList.valueOf(color));
        }
    }

    public static void setStrokeWidth(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int width = (int) DimensionUtil.parse(value, context);
                ((MaterialButton) target).setStrokeWidth(width);
            } catch (Exception ignored) {}
        }
    }
}
