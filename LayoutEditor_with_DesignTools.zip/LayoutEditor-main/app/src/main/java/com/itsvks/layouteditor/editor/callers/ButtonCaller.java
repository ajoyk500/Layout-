package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;

import com.google.android.material.button.MaterialButton;
import com.itsvks.layouteditor.managers.DrawableManager;
import com.itsvks.layouteditor.utils.DimensionUtil;

/**
 * Handles Button / MaterialButton specific attributes that aren't covered by
 * the generic View or TextView callers — background tint, corner radius,
 * icon, icon tint, and stroke (Material outlined-button style).
 *
 * Uses {@link View#setBackgroundTintList} which works on both a plain
 * {@link Button} and a {@link MaterialButton}, so the "SIGN IN" style button
 * renders correctly regardless of which concrete class was used in the XML.
 */
public class ButtonCaller {

    public static void setBackgroundTint(View target, String value, Context context) {
        try {
            int color = Color.parseColor(value);
            target.setBackgroundTintList(ColorStateList.valueOf(color));
        } catch (Exception ignored) {}
    }

    public static void setCornerRadius(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int radius = (int) DimensionUtil.parse(value, context);
                ((MaterialButton) target).setCornerRadius(radius);
            } catch (Exception ignored) {}
        }
    }

    public static void setIcon(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                String name = value.replace("@drawable/", "");
                ((MaterialButton) target).setIcon(DrawableManager.getDrawable(context, name));
            } catch (Exception ignored) {}
        }
    }

    public static void setIconTint(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int color = Color.parseColor(value);
                ((MaterialButton) target).setIconTint(ColorStateList.valueOf(color));
            } catch (Exception ignored) {}
        }
    }

    public static void setStrokeColor(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int color = Color.parseColor(value);
                ((MaterialButton) target).setStrokeColor(ColorStateList.valueOf(color));
            } catch (Exception ignored) {}
        }
    }

    public static void setStrokeWidth(View target, String value, Context context) {
        if (target instanceof MaterialButton) {
            try {
                int width = (int) DimensionUtil.parse(value, context);
                ((MaterialButton) target).setStrokeWidth(width);
            } catch (Exception ignored) {}
        }
    }
}
