package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

import java.util.HashMap;

public class ImageViewCaller {

    private static final HashMap<String, ImageView.ScaleType> scaleTypes = new HashMap<>();

    static {
        scaleTypes.put("fitXY", ImageView.ScaleType.FIT_XY);
        scaleTypes.put("fitStart", ImageView.ScaleType.FIT_START);
        scaleTypes.put("fitCenter", ImageView.ScaleType.FIT_CENTER);
        scaleTypes.put("fitEnd", ImageView.ScaleType.FIT_END);
        scaleTypes.put("center", ImageView.ScaleType.CENTER);
        scaleTypes.put("centerCrop", ImageView.ScaleType.CENTER_CROP);
        scaleTypes.put("centerInside", ImageView.ScaleType.CENTER_INSIDE);
    }

    public static void setImage(View target, String value, Context context) {
        // Handles "@drawable/...", "@mipmap/...", AND "@android:drawable/..."
        // (framework resources like ic_lock_idle_lock) — never crashes on an
        // unknown reference, just leaves the ImageView's current image as-is.
        Drawable d = ResourceResolver.resolveDrawable(context, value);
        if (d != null) {
            ((ImageView) target).setImageDrawable(d);
        }
    }

    public static void setScaleType(View target, String value, Context context) {
        ImageView.ScaleType type = scaleTypes.get(value);
        if (type != null) ((ImageView) target).setScaleType(type);
    }

    public static void setTint(View target, String value, Context context) {
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) ((ImageView) target).setColorFilter(color);
    }

    public static void setAdjustViewBounds(View target, String value, Context context) {
        ((ImageView) target).setAdjustViewBounds(value.equals("true"));
    }

    public static void setMaxWidth(View target, String value, Context context) {
        ((ImageView) target).setMaxWidth((int) DimensionUtil.parse(value, context));
    }

    public static void setMaxHeight(View target, String value, Context context) {
        ((ImageView) target).setMaxHeight((int) DimensionUtil.parse(value, context));
    }

    public static void setCropToPadding(View target, String value, Context context) {
        ((ImageView) target).setCropToPadding(value.equals("true"));
    }
}
