package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;

import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/** Attribute caller for {@link CircularProgressIndicator}. */
public class CircularProgressCaller {

    public static void setProgressCompat(View target, String value, Context context) {
        if (target instanceof CircularProgressIndicator) {
            try {
                ((CircularProgressIndicator) target).setProgressCompat(Integer.parseInt(value), true);
            } catch (Exception ignored) {}
        }
    }

    public static void setIndeterminate(View target, String value, Context context) {
        if (target instanceof CircularProgressIndicator) {
            ((CircularProgressIndicator) target).setIndeterminate(value.equals("true"));
        }
    }

    public static void setIndicatorColor(View target, String value, Context context) {
        if (target instanceof CircularProgressIndicator) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((CircularProgressIndicator) target).setIndicatorColor(color);
        }
    }

    public static void setTrackColor(View target, String value, Context context) {
        if (target instanceof CircularProgressIndicator) {
            Integer color = ResourceResolver.resolveColor(context, value);
            if (color != null) ((CircularProgressIndicator) target).setTrackColor(color);
        }
    }

    public static void setIndicatorSize(View target, String value, Context context) {
        if (target instanceof CircularProgressIndicator) {
            try {
                ((CircularProgressIndicator) target).setIndicatorSize((int) DimensionUtil.parse(value, context));
            } catch (Exception ignored) {}
        }
    }
}
