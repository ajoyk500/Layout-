package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

import com.google.android.material.button.MaterialButton;
import com.itsvks.layouteditor.utils.DimensionUtil;
import com.itsvks.layouteditor.utils.ResourceResolver;

/**
 * Attribute caller for {@link MaterialButton}. android:text/android:enabled
 * are handled by the universal {@link ViewCaller}; this class only covers
 * Material-specific styling (corner radius, ripple, tint, stroke).
 */
public class MaterialButtonCaller {

    public static void setCornerRadius(View target, String value, Context context) {
        if (!(target instanceof MaterialButton)) return;
        try {
            ((MaterialButton) target).setCornerRadius((int) DimensionUtil.parse(value, context));
        } catch (Exception ignored) {}
    }

    public static void setRippleColor(View target, String value, Context context) {
        if (!(target instanceof MaterialButton)) return;
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) ((MaterialButton) target).setRippleColor(ColorStateList.valueOf(color));
    }

    public static void setBackgroundTintList(View target, String value, Context context) {
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) target.setBackgroundTintList(ColorStateList.valueOf(color));
    }

    public static void setStrokeColor(View target, String value, Context context) {
        if (!(target instanceof MaterialButton)) return;
        Integer color = ResourceResolver.resolveColor(context, value);
        if (color != null) ((MaterialButton) target).setStrokeColor(ColorStateList.valueOf(color));
    }

    public static void setStrokeWidth(View target, String value, Context context) {
        if (!(target instanceof MaterialButton)) return;
        try {
            ((MaterialButton) target).setStrokeWidth((int) DimensionUtil.parse(value, context));
        } catch (Exception ignored) {}
    }
}
