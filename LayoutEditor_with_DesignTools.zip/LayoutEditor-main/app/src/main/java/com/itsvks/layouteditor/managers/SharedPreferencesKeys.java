package com.itsvks.layouteditor.managers;

public class SharedPreferencesKeys {
    public static final String KEY_APP_THEME = "app_theme";
    public static final String KEY_DYNAMIC_COLORS = "dynamic_colors";
    public static final String KEY_VIBRATION = "vibration";
    public static final String KEY_TOGGLE_STROKE = "toggle_stroke";

    // Design tools
    public static final String KEY_SHOW_GRID = "show_grid";
    public static final String KEY_SNAP_TO_GRID = "snap_to_grid";
    public static final String KEY_SHOW_ALIGNMENT_GUIDES = "show_alignment_guides";
    public static final String KEY_GRID_SIZE = "grid_size";
}
