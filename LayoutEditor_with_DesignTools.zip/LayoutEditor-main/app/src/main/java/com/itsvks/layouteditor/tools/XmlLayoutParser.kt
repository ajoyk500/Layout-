package com.itsvks.layouteditor.tools

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.LinearLayoutCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager.addNewId
import com.itsvks.layouteditor.managers.IdManager.clear
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil.createView
import com.itsvks.layouteditor.utils.InvokeUtil.invokeMethod
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader

class XmlLayoutParser(context: Context) {

    val viewAttributeMap: HashMap<View, AttributeMap> = HashMap()

    private val initializer: AttributeInitializer
    private val container: LinearLayoutCompat

    /**
     * Maps every known tag name variant to its Design class name.
     * Covers short names ("ScrollView"), superclass names
     * ("android.widget.ScrollView"), and full Material/AndroidX package names.
     */
    private val tagToDesignClass: HashMap<String, String> = HashMap()

    init {
        val attributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {}.type
            )
        val parentAttributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.PARENT_ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {}.type
            )

        initializer = AttributeInitializer(context, attributes, parentAttributes)

        container = LinearLayoutCompat(context)
        container.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        buildTagLookup(context)
    }

    // ── Tag resolution ────────────────────────────────────────────────────────

    private fun buildTagLookup(context: Context) {
        try {
            val json = JSONObject(FileUtil.readFromAsset("widgetclasses.json", context))
            val keys = json.keys()
            while (keys.hasNext()) {
                val shortName = keys.next()
                val designClass = json.getString(shortName)

                // 1. Short name (e.g. "ScrollView")
                tagToDesignClass[shortName] = designClass

                // 2. Superclass name — what XmlLayoutGenerator writes when useSuperclasses=true
                try {
                    val superName = Class.forName(designClass).superclass?.name
                    if (superName != null && superName != "java.lang.Object") {
                        tagToDesignClass[superName] = designClass
                    }
                } catch (_: Exception) {}

                // 3. Well-known full package names users may write directly
                when (shortName) {
                    "CardView" -> {
                        tagToDesignClass["androidx.cardview.widget.CardView"] = designClass
                        tagToDesignClass["android.support.v7.widget.CardView"] = designClass
                    }
                    "RecyclerView" -> {
                        tagToDesignClass["androidx.recyclerview.widget.RecyclerView"] = designClass
                    }
                    "ConstraintLayout" -> {
                        tagToDesignClass["androidx.constraintlayout.widget.ConstraintLayout"] = designClass
                    }
                    "NestedScrollView" -> {
                        tagToDesignClass["androidx.core.widget.NestedScrollView"] = designClass
                    }
                    "AppBarLayout" -> {
                        tagToDesignClass["com.google.android.material.appbar.AppBarLayout"] = designClass
                    }
                    "MaterialToolbar" -> {
                        tagToDesignClass["com.google.android.material.appbar.MaterialToolbar"] = designClass
                    }
                    "BottomAppBar" -> {
                        tagToDesignClass["com.google.android.material.bottomappbar.BottomAppBar"] = designClass
                    }
                    "FloatingActionButton" -> {
                        tagToDesignClass["com.google.android.material.floatingactionbutton.FloatingActionButton"] = designClass
                    }
                    "Chip" -> {
                        tagToDesignClass["com.google.android.material.chip.Chip"] = designClass
                    }
                    "ChipGroup" -> {
                        tagToDesignClass["com.google.android.material.chip.ChipGroup"] = designClass
                    }
                    "TabLayout" -> {
                        tagToDesignClass["com.google.android.material.tabs.TabLayout"] = designClass
                    }
                    "BottomNavigationView" -> {
                        tagToDesignClass["com.google.android.material.bottomnavigation.BottomNavigationView"] = designClass
                    }
                    "NavigationView" -> {
                        tagToDesignClass["com.google.android.material.navigation.NavigationView"] = designClass
                    }
                    "ViewPager" -> {
                        tagToDesignClass["androidx.viewpager.widget.ViewPager"] = designClass
                    }
                    "Switch" -> {
                        tagToDesignClass["androidx.appcompat.widget.SwitchCompat"] = designClass
                    }
                    "EditText" -> {
                        tagToDesignClass["androidx.appcompat.widget.AppCompatEditText"] = designClass
                    }
                    "DrawerLayout" -> {
                        tagToDesignClass["androidx.drawerlayout.widget.DrawerLayout"] = designClass
                    }
                    "LinearLayoutCompat" -> {
                        tagToDesignClass["androidx.appcompat.widget.LinearLayoutCompat"] = designClass
                    }
                    "MaterialCardView" -> {
                        tagToDesignClass["com.google.android.material.card.MaterialCardView"] = designClass
                    }
                    "TextInputLayout" -> {
                        tagToDesignClass["com.google.android.material.textfield.TextInputLayout"] = designClass
                    }
                    "MaterialButton" -> {
                        tagToDesignClass["com.google.android.material.button.MaterialButton"] = designClass
                    }
                    "MaterialTextView" -> {
                        tagToDesignClass["com.google.android.material.textview.MaterialTextView"] = designClass
                    }
                    "MaterialSwitch" -> {
                        tagToDesignClass["com.google.android.material.materialswitch.MaterialSwitch"] = designClass
                    }
                    "SwitchMaterial" -> {
                        tagToDesignClass["com.google.android.material.switchmaterial.SwitchMaterial"] = designClass
                    }
                    "Slider" -> {
                        tagToDesignClass["com.google.android.material.slider.Slider"] = designClass
                    }
                    "RangeSlider" -> {
                        tagToDesignClass["com.google.android.material.slider.RangeSlider"] = designClass
                    }
                    "ExtendedFloatingActionButton" -> {
                        tagToDesignClass["com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton"] = designClass
                    }
                    "MaterialDivider" -> {
                        tagToDesignClass["com.google.android.material.divider.MaterialDivider"] = designClass
                    }
                    "SearchBar" -> {
                        tagToDesignClass["com.google.android.material.search.SearchBar"] = designClass
                    }
                    "LinearProgressIndicator" -> {
                        tagToDesignClass["com.google.android.material.progressindicator.LinearProgressIndicator"] = designClass
                    }
                    "CircularProgressIndicator" -> {
                        tagToDesignClass["com.google.android.material.progressindicator.CircularProgressIndicator"] = designClass
                    }
                    "MaterialCheckBox" -> {
                        tagToDesignClass["com.google.android.material.checkbox.MaterialCheckBox"] = designClass
                    }
                    "MaterialRadioButton" -> {
                        tagToDesignClass["com.google.android.material.radiobutton.MaterialRadioButton"] = designClass
                    }
                    "MaterialAutoCompleteTextView" -> {
                        tagToDesignClass["com.google.android.material.textfield.MaterialAutoCompleteTextView"] = designClass
                    }
                    "CollapsingToolbarLayout" -> {
                        tagToDesignClass["com.google.android.material.appbar.CollapsingToolbarLayout"] = designClass
                    }
                    "TextInputEditText" -> {
                        tagToDesignClass["com.google.android.material.textfield.TextInputEditText"] = designClass
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Resolves an XML tag to a Design class name, or null if unknown. */
    private fun resolveTag(tagName: String): String? {
        tagToDesignClass[tagName]?.let { return it }
        // Fallback: try last segment of a dotted name (e.g. "CardView" from full path)
        val simpleName = tagName.substringAfterLast('.')
        return tagToDesignClass[simpleName]
    }

    // ── Public API ────────────────────────────────────────────────────────────

    val root: View
        get() {
            val view = container.getChildAt(0)
            container.removeView(view)
            return view
        }

    fun parseFromXml(xml: String, context: Context) {
        val listViews: MutableList<View> = ArrayList()
        listViews.add(container)

        try {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xml))

            while (parser.eventType != XmlPullParser.END_DOCUMENT) {
                when (parser.eventType) {
                    XmlPullParser.START_TAG -> {
                        val designClass = resolveTag(parser.name)

                        // Unknown or uninstantiable tag → plain View placeholder so
                        // depth tracking (listViews indices) stays correct.
                        val view: View = if (designClass != null) {
                            (createView(designClass, context) as? View) ?: View(context)
                        } else {
                            View(context)
                        }

                        listViews.add(view)

                        val map = AttributeMap()
                        var i = 0
                        while (i < parser.attributeCount) {
                            if (!parser.getAttributeName(i).startsWith("xmlns")) {
                                map.putValue(
                                    parser.getAttributeName(i),
                                    parser.getAttributeValue(i)
                                )
                            }
                            i++
                        }
                        viewAttributeMap[view] = map
                    }

                    XmlPullParser.END_TAG -> {
                        val index = parser.depth
                        val child = listViews[index]
                        val parent = listViews[index - 1]
                        if (parent is ViewGroup) {
                            parent.addView(child)
                        }
                        listViews.removeAt(index)
                    }
                }
                parser.next()
            }
        } catch (e: XmlPullParserException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        clear()

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!
            for (key in map.keySet()) {
                if (key == "android:id") {
                    addNewId(view, map.getValue("android:id"))
                }
            }
        }

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!
            applyAttributes(view, map)
        }
    }

    private fun applyAttributes(target: View, attributeMap: AttributeMap) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val keys = attributeMap.keySet()

        for (i in keys.indices.reversed()) {
            val key = keys[i]

            // Fix: was `?: return` (exits whole function); now `?: continue` (skips one attr)
            val attr = initializer.getAttributeFromKey(key, allAttrs) ?: continue

            val methodName = attr[Constants.KEY_METHOD_NAME].toString()
            val className  = attr[Constants.KEY_CLASS_NAME].toString()
            val value      = attributeMap.getValue(key)

            if (key == "android:id") continue

            invokeMethod(methodName, className, target, value, target.context)
        }
    }
}
