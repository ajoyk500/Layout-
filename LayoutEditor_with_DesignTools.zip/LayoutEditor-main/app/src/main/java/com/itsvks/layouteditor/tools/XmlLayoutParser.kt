package com.itsvks.layouteditor.tools

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.LinearLayoutCompat
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.itsvks.layouteditor.editor.initializer.AttributeInitializer
import com.itsvks.layouteditor.editor.initializer.AttributeMap
import com.itsvks.layouteditor.managers.IdManager.addNewId
import com.itsvks.layouteditor.managers.IdManager.clear
import com.itsvks.layouteditor.utils.Constants
import com.itsvks.layouteditor.utils.FileUtil
import com.itsvks.layouteditor.utils.InvokeUtil.createView
import com.itsvks.layouteditor.utils.InvokeUtil.invokeMethod
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.IOException
import java.io.StringReader

class XmlLayoutParser(context: Context) {

    val viewAttributeMap: HashMap<View, AttributeMap> = HashMap()

    private val initializer: AttributeInitializer
    private val container: LinearLayoutCompat

    /**
     * Maps every known short tag name (e.g. "ScrollView") AND every known
     * superclass / full package name (e.g. "android.widget.ScrollView") to the
     * corresponding Design-class name stored in widgetclasses.json.
     *
     * This allows [parseFromXml] to accept XML produced by [XmlLayoutGenerator]
     * (which uses superclass names like "android.widget.LinearLayout") as well as
     * XML written by the user with simple tag names like "LinearLayout".
     */
    private val tagToDesignClass: HashMap<String, String> = HashMap()

    init {
        val attributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {}.type
            )
        val parentAttributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.PARENT_ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {}.type
            )

        initializer = AttributeInitializer(context, attributes, parentAttributes)

        container = LinearLayoutCompat(context)
        container.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )

        // Build tag → Design class lookup from widgetclasses.json
        buildTagLookup(context)
    }

    /**
     * Reads widgetclasses.json and populates [tagToDesignClass] with:
     *  • short tag name          → Design class  (e.g. "ScrollView"  → "…ScrollViewDesign")
     *  • superclass name         → Design class  (e.g. "android.widget.ScrollView" → same)
     *  • full package tag name   → Design class  (e.g. "androidx.cardview…CardView" → same)
     *
     * This covers every format a user might write in the XML editor.
     */
    private fun buildTagLookup(context: Context) {
        try {
            val json = JSONObject(FileUtil.readFromAsset("widgetclasses.json", context))
            val keys = json.keys()
            while (keys.hasNext()) {
                val shortName = keys.next()          // e.g. "ScrollView"
                val designClass = json.getString(shortName)   // e.g. "…ScrollViewDesign"

                // 1. Short name  →  design class
                tagToDesignClass[shortName] = designClass

                // 2. Superclass name  →  design class  (what XmlLayoutGenerator outputs)
                try {
                    val superClass = Class.forName(designClass).superclass?.name
                    if (superClass != null && superClass != "java.lang.Object") {
                        tagToDesignClass[superClass] = designClass
                    }
                } catch (_: Exception) {}

                // 3. A few well-known full-package tag names that users write directly
                //    and that won't be caught by the superclass walk above.
                when (shortName) {
                    "CardView" -> {
                        tagToDesignClass["androidx.cardview.widget.CardView"] = designClass
                        tagToDesignClass["android.support.v7.widget.CardView"] = designClass
                    }
                    "RecyclerView" -> {
                        tagToDesignClass["androidx.recyclerview.widget.RecyclerView"] = designClass
                    }
                    "ConstraintLayout" -> {
                        tagToDesignClass["androidx.constraintlayout.widget.ConstraintLayout"] = designClass
                    }
                    "NestedScrollView" -> {
                        tagToDesignClass["androidx.core.widget.NestedScrollView"] = designClass
                    }
                    "AppBarLayout" -> {
                        tagToDesignClass["com.google.android.material.appbar.AppBarLayout"] = designClass
                    }
                    "MaterialToolbar" -> {
                        tagToDesignClass["com.google.android.material.appbar.MaterialToolbar"] = designClass
                    }
                    "BottomAppBar" -> {
                        tagToDesignClass["com.google.android.material.bottomappbar.BottomAppBar"] = designClass
                    }
                    "FloatingActionButton" -> {
                        tagToDesignClass["com.google.android.material.floatingactionbutton.FloatingActionButton"] = designClass
                    }
                    "Chip" -> {
                        tagToDesignClass["com.google.android.material.chip.Chip"] = designClass
                    }
                    "ChipGroup" -> {
                        tagToDesignClass["com.google.android.material.chip.ChipGroup"] = designClass
                    }
                    "TabLayout" -> {
                        tagToDesignClass["com.google.android.material.tabs.TabLayout"] = designClass
                    }
                    "BottomNavigationView" -> {
                        tagToDesignClass["com.google.android.material.bottomnavigation.BottomNavigationView"] = designClass
                    }
                    "NavigationView" -> {
                        tagToDesignClass["com.google.android.material.navigation.NavigationView"] = designClass
                    }
                    "ViewPager" -> {
                        tagToDesignClass["androidx.viewpager.widget.ViewPager"] = designClass
                        tagToDesignClass["androidx.viewpager2.widget.ViewPager2"] = designClass
                    }
                    "Switch" -> {
                        tagToDesignClass["com.google.android.material.switchmaterial.SwitchMaterial"] = designClass
                        tagToDesignClass["androidx.appcompat.widget.SwitchCompat"] = designClass
                    }
                    "Button" -> {
                        // MaterialButton maps to ButtonDesign
                        tagToDesignClass["com.google.android.material.button.MaterialButton"] = designClass
                    }
                    "EditText" -> {
                        tagToDesignClass["com.google.android.material.textfield.TextInputEditText"] = designClass
                        tagToDesignClass["androidx.appcompat.widget.AppCompatEditText"] = designClass
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Resolves an XML tag name to the full Design class name.
     * Returns null if the tag is unknown (caller should skip that element).
     */
    private fun resolveTag(tagName: String): String? {
        // Direct lookup (short name or full package name)
        tagToDesignClass[tagName]?.let { return it }

        // Try the simple class name (last segment of a dotted name)
        val simpleName = tagName.substringAfterLast('.')
        tagToDesignClass[simpleName]?.let { return it }

        return null
    }

    val root: View
        get() {
            val view = container.getChildAt(0)
            container.removeView(view)
            return view
        }

    fun parseFromXml(xml: String, context: Context) {
        val listViews: MutableList<View> = ArrayList()
        listViews.add(container)

        try {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xml))

            while (parser.eventType != XmlPullParser.END_DOCUMENT) {
                when (parser.eventType) {
                    XmlPullParser.START_TAG -> {
                        val designClass = resolveTag(parser.name)
                        if (designClass == null) {
                            // Unknown tag — push a plain View placeholder so
                            // depth tracking (listViews indices) stays correct.
                            val placeholder = View(context)
                            listViews.add(placeholder)
                            parser.next()
                            continue
                        }

                        val view = createView(designClass, context)
                        if (view == null) {
                            // Design class exists in JSON but couldn't be instantiated.
                            val placeholder = View(context)
                            listViews.add(placeholder)
                            parser.next()
                            continue
                        }

                        listViews.add(view as View)

                        val map = AttributeMap()
                        var i = 0
                        while (i < parser.attributeCount) {
                            if (!parser.getAttributeName(i).startsWith("xmlns")) {
                                val attrName = parser.getAttributeName(i)
                                val attrValue = parser.getAttributeValue(i)
                                // Normalize attribute names: strip namespace prefix if present
                                // (e.g. "android:text" stays as-is; bare "text" is left as-is)
                                map.putValue(attrName, attrValue)
                            }
                            i++
                        }

                        viewAttributeMap[view] = map
                    }

                    XmlPullParser.END_TAG -> {
                        val index = parser.depth
                        val child = listViews[index]
                        val parent = listViews[index - 1]
                        if (parent is ViewGroup) {
                            parent.addView(child)
                        }
                        listViews.removeAt(index)
                    }
                }
                parser.next()
            }
        } catch (e: XmlPullParserException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        clear()

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!
            for (key in map.keySet()) {
                if (key == "android:id") {
                    addNewId(view, map.getValue("android:id"))
                }
            }
        }

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!
            applyAttributes(view, map)
        }
    }

    private fun applyAttributes(target: View, attributeMap: AttributeMap) {
        val allAttrs = initializer.getAllAttributesForView(target)
        val keys = attributeMap.keySet()

        for (i in keys.indices.reversed()) {
            val key = keys[i]

            // Bug fix: was `?: return` which exited the whole function.
            // Should be `?: continue` to skip only the unknown attribute.
            val attr = initializer.getAttributeFromKey(key, allAttrs) ?: continue

            val methodName = attr[Constants.KEY_METHOD_NAME].toString()
            val className = attr[Constants.KEY_CLASS_NAME].toString()
            val value = attributeMap.getValue(key)

            if (key == "android:id") continue

            invokeMethod(methodName, className, target, value, target.context)
        }
    }
}


class XmlLayoutParser(context: Context) {

    val viewAttributeMap: HashMap<View, AttributeMap> = HashMap()

    private val initializer: AttributeInitializer
    private val container: LinearLayoutCompat

    init {
        val attributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {
                }.type
            )
        val parentAttributes = Gson()
            .fromJson<HashMap<String, List<HashMap<String, Any>>>>(
                FileUtil.readFromAsset(Constants.PARENT_ATTRIBUTES_FILE, context),
                object : TypeToken<HashMap<String, List<HashMap<String, Any>>>>() {
                }.type
            )

        initializer = AttributeInitializer(context, attributes, parentAttributes)

        container = LinearLayoutCompat(context)
        container.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    val root: View
        get() {
            val view = container.getChildAt(0)
            container.removeView(view)
            return view
        }

    fun parseFromXml(xml: String, context: Context) {
        val listViews: MutableList<View> = ArrayList()
        listViews.add(container)

        try {
            val factory = XmlPullParserFactory.newInstance()
            val parser = factory.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(StringReader(xml))

            while (parser.eventType != XmlPullParser.END_DOCUMENT) {
                when (parser.eventType) {
                    XmlPullParser.START_TAG -> {
                        val view = createView(parser.name, context) as View
                        listViews.add(view)

                        val map = AttributeMap()

                        var i = 0
                        while (i < parser.attributeCount) {
                            if (!parser.getAttributeName(i).startsWith("xmlns")) {
                                map.putValue(parser.getAttributeName(i), parser.getAttributeValue(i))
                            }
                            i++
                        }

                        viewAttributeMap[view] = map
                    }

                    XmlPullParser.END_TAG -> {
                        val index = parser.depth
                        (listViews[index - 1] as ViewGroup).addView(listViews[index])
                        listViews.removeAt(index)
                    }
                }
                parser.next()
            }
        } catch (e: XmlPullParserException) {
            e.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }

        clear()

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!

            for (key in map.keySet()) {
                if (key == "android:id") {
                    addNewId(view, map.getValue("android:id"))
                }
            }
        }

        for (view in viewAttributeMap.keys) {
            val map = viewAttributeMap[view]!!
            applyAttributes(view, map)
        }
    }

    private fun applyAttributes(target: View, attributeMap: AttributeMap) {
        val allAttrs = initializer.getAllAttributesForView(target)

        val keys = attributeMap.keySet()

        for (i in keys.indices.reversed()) {
            val key = keys[i]

            val attr = initializer.getAttributeFromKey(key, allAttrs) ?: return
            val methodName = attr[Constants.KEY_METHOD_NAME].toString()
            val className = attr[Constants.KEY_CLASS_NAME].toString()
            val value = attributeMap.getValue(key)

            if (key == "android:id") {
                continue
            }

            invokeMethod(methodName, className, target, value, target.context)
        }
    }
}
