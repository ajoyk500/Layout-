package com.itsvks.layouteditor.editor.callers;

import android.content.Context;
import android.view.View;
import android.widget.Checkable;

/** Attribute caller for SwitchMaterial. */
public class SwitchMaterialCaller {

    public static void setText(View target, String value, Context context) {
        ViewCaller.setText(target, value, context);
    }

    public static void setChecked(View target, String value, Context context) {
        if (target instanceof Checkable) {
            ((Checkable) target).setChecked(value.equals("true"));
        }
    }
}
