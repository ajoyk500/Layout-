package com.itsvks.layouteditor.editor.callers.layouts;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import com.itsvks.layouteditor.utils.DimensionUtil;

public class LinearLayoutCaller {
    public static void setWeightSum(View target, String value, Context context) {
        if (target instanceof LinearLayout)
            ((LinearLayout) target).setWeightSum(Float.valueOf(value));
    }

    public static void setShowDividers(View target, String value, Context context) {
        if (!(target instanceof LinearLayout)) return;
        int mask = LinearLayout.SHOW_DIVIDER_NONE;
        for (String flag : value.split("\\|")) {
            switch (flag.trim()) {
                case "beginning": mask |= LinearLayout.SHOW_DIVIDER_BEGINNING; break;
                case "middle":    mask |= LinearLayout.SHOW_DIVIDER_MIDDLE; break;
                case "end":       mask |= LinearLayout.SHOW_DIVIDER_END; break;
            }
        }
        ((LinearLayout) target).setShowDividers(mask);
    }

    public static void setBaselineAligned(View target, String value, Context context) {
        if (target instanceof LinearLayout)
            ((LinearLayout) target).setBaselineAligned(value.equals("true"));
    }

    public static void setDividerPadding(View target, String value, Context context) {
        if (target instanceof LinearLayout)
            ((LinearLayout) target).setDividerPadding((int) DimensionUtil.parse(value, context));
    }
}
