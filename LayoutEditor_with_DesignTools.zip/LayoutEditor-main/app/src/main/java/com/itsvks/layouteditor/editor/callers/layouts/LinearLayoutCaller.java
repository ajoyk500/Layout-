package com.itsvks.layouteditor.editor.callers.layouts;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;

import androidx.appcompat.widget.LinearLayoutCompat;

import com.itsvks.layouteditor.utils.DimensionUtil;

public class LinearLayoutCaller {
    public static void setWeightSum(View target, String value, Context context) {
        try {
            float weightSum = Float.parseFloat(value);
            if (target instanceof LinearLayout) ((LinearLayout) target).setWeightSum(weightSum);
            else if (target instanceof LinearLayoutCompat) ((LinearLayoutCompat) target).setWeightSum(weightSum);
        } catch (Exception ignored) {}
    }

    public static void setOrientation(View target, String value, Context context) {
        int orientation = value.equals("horizontal") ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL;
        if (target instanceof LinearLayout) ((LinearLayout) target).setOrientation(orientation);
        else if (target instanceof LinearLayoutCompat) ((LinearLayoutCompat) target).setOrientation(orientation);
    }

    public static void setGravity(View target, String value, Context context) {
        int result = 0;
        for (String flag : value.split("\\|")) {
            Integer g = com.itsvks.layouteditor.utils.Constants.gravityMap.get(flag.trim());
            if (g != null) result |= g;
        }
        if (result == 0) return;
        if (target instanceof LinearLayout) ((LinearLayout) target).setGravity(result);
        else if (target instanceof LinearLayoutCompat) ((LinearLayoutCompat) target).setGravity(result);
    }

    public static void setShowDividers(View target, String value, Context context) {
        if (!(target instanceof LinearLayout)) return;
        int mask = LinearLayout.SHOW_DIVIDER_NONE;
        for (String flag : value.split("\\|")) {
            switch (flag.trim()) {
                case "beginning": mask |= LinearLayout.SHOW_DIVIDER_BEGINNING; break;
                case "middle":    mask |= LinearLayout.SHOW_DIVIDER_MIDDLE; break;
                case "end":       mask |= LinearLayout.SHOW_DIVIDER_END; break;
            }
        }
        ((LinearLayout) target).setShowDividers(mask);
    }

    public static void setBaselineAligned(View target, String value, Context context) {
        if (target instanceof LinearLayout)
            ((LinearLayout) target).setBaselineAligned(value.equals("true"));
    }

    public static void setDividerPadding(View target, String value, Context context) {
        if (target instanceof LinearLayout)
            ((LinearLayout) target).setDividerPadding((int) DimensionUtil.parse(value, context));
    }
}
