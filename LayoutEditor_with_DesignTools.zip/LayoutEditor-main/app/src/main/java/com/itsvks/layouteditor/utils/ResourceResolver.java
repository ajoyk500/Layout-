package com.itsvks.layouteditor.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.itsvks.layouteditor.managers.DrawableManager;

import java.io.File;

/**
 * Centralized resource reference resolver — the single place that turns any
 * "@something/name" string written in the XML editor into a real Android
 * resource, no matter where it actually lives.
 *
 * Without this, every caller (ImageViewCaller, TextViewCaller, ViewCaller,
 * ButtonCaller, ...) had to know how to strip "@drawable/" by hand, which
 * meant references like "@android:drawable/ic_lock_idle_lock" (a system
 * resource, not a project resource) silently failed and produced blank
 * views — exactly what happened with the logo ImageView.
 *
 * Supported reference formats:
 *  • "@drawable/name"          → project drawable (user-imported / generated)
 *  • "@mipmap/name"            → project mipmap (treated same as drawable here)
 *  • "@android:drawable/name"  → framework (system) drawable, e.g. ic_lock_idle_lock
 *  • "@android:mipmap/name"    → framework mipmap
 *  • "@color/name"             → project color (not yet stored separately — falls
 *                                 back to framework color, kept here for forward-compat)
 *  • "@android:color/name"     → framework color, e.g. @android:color/holo_blue_dark
 *  • plain hex string          → not handled here (callers already do direct
 *                                 Color.parseColor for those)
 *
 * Every lookup is wrapped so a missing/unknown resource NEVER throws — it
 * just returns null, and callers should already check for null before using
 * the result. This keeps the editor crash-free even for typoed or
 * not-yet-imported resource names, which is the same "be forgiving, never
 * hard-fail" philosophy a browser's DOM/CSS resolver uses for unknown
 * properties or missing assets.
 */
public final class ResourceResolver {

    private static final String TAG = "ResourceResolver";

    private ResourceResolver() {}

    /**
     * Resolves a drawable reference of any supported format to a {@link Drawable}.
     * Returns null if nothing could be resolved (never throws).
     */
    @Nullable
    public static Drawable resolveDrawable(Context context, String rawValue) {
        if (rawValue == null || rawValue.isEmpty()) return null;

        try {
            if (rawValue.startsWith("@android:drawable/")) {
                return resolveFrameworkDrawable(context, rawValue.substring("@android:drawable/".length()));
            }
            if (rawValue.startsWith("@android:mipmap/")) {
                return resolveFrameworkDrawable(context, rawValue.substring("@android:mipmap/".length()));
            }
            if (rawValue.startsWith("@drawable/")) {
                return resolveProjectDrawable(context, rawValue.substring("@drawable/".length()));
            }
            if (rawValue.startsWith("@mipmap/")) {
                return resolveProjectDrawable(context, rawValue.substring("@mipmap/".length()));
            }
            // Bare name with no prefix — try project drawable as a last resort
            // (keeps backward compatibility with old XML that omitted the prefix)
            return resolveProjectDrawable(context, rawValue);
        } catch (Exception e) {
            Log.w(TAG, "resolveDrawable: failed for '" + rawValue + "'", e);
            return null;
        }
    }

    /**
     * Resolves a color reference. Accepts plain hex ("#RRGGBB"/"#AARRGGBB"),
     * "@android:color/name", and "@color/name". Returns null if unresolvable.
     */
    @Nullable
    public static Integer resolveColor(Context context, String rawValue) {
        if (rawValue == null || rawValue.isEmpty()) return null;

        try {
            if (rawValue.startsWith("#")) {
                return Color.parseColor(rawValue);
            }
            if (rawValue.startsWith("@android:color/")) {
                String name = rawValue.substring("@android:color/".length());
                int resId = Resources.getSystem().getIdentifier(name, "color", "android");
                if (resId != 0) {
                    return ContextCompat.getColor(context, resId);
                }
                return null;
            }
            if (rawValue.startsWith("@color/")) {
                // Project-level colors.xml isn't indexed separately yet; fall back
                // to treating the remainder as a framework color name so common
                // references like "@color/black" still resolve instead of crashing.
                String name = rawValue.substring("@color/".length());
                int resId = Resources.getSystem().getIdentifier(name, "color", "android");
                if (resId != 0) {
                    return ContextCompat.getColor(context, resId);
                }
                return null;
            }
            // Last resort: maybe it's a named color Android understands directly
            return Color.parseColor(rawValue);
        } catch (Exception e) {
            Log.w(TAG, "resolveColor: failed for '" + rawValue + "'", e);
            return null;
        }
    }

    // ── internal helpers ─────────────────────────────────────────────────────

    @Nullable
    private static Drawable resolveFrameworkDrawable(Context context, String name) {
        if (name.isEmpty()) return null;
        int resId = Resources.getSystem().getIdentifier(name, "drawable", "android");
        if (resId == 0) {
            // Some framework icons live under "mipmap" instead of "drawable"
            resId = Resources.getSystem().getIdentifier(name, "mipmap", "android");
        }
        if (resId == 0) return null;
        return ContextCompat.getDrawable(context, resId);
    }

    @Nullable
    private static Drawable resolveProjectDrawable(Context context, String name) {
        if (name.isEmpty()) return null;
        if (!DrawableManager.contains(name)) return null;
        return DrawableManager.getDrawable(context, name);
    }
}
